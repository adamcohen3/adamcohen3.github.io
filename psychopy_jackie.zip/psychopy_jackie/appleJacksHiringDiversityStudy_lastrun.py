#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v3.0.2),
    on Mon 28 Jan 2019 12:06:54 PM HST
If you publish work using this script please cite the PsychoPy publications:
    Peirce, JW (2007) PsychoPy - Psychophysics software in Python.
        Journal of Neuroscience Methods, 162(1-2), 8-13.
    Peirce, JW (2009) Generating stimuli for neuroscience using PsychoPy.
        Frontiers in Neuroinformatics, 2:10. doi: 10.3389/neuro.11.010.2008
"""

from __future__ import absolute_import, division
from psychopy import locale_setup, sound, gui, visual, core, data, event, logging, clock
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)
import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions
import sys  # to get file system encoding


# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '3.0.2'
expName = 'appleJacksRaceHiringStudy'  # from the Builder filename that created this script
expInfo = {'participant': '', 'session': '1'}
dlg = gui.DlgFromDict(dictionary=expInfo, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + 'data/%s_%s_%s' %(expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='/home/adam/Desktop/sharedWindows10/psychopy_jackie/appleJacksHiringDiversityStudy_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp

# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(
    size=[1920, 1080], fullscr=True, screen=0,
    allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True,
    units='pix')
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# Initialize components for Routine "instructions"
instructionsClock = core.Clock()
import random

#----------------------------------------------
#initialize a counter for candidates
#----------------------------------------------
candidateCounter = 0

#----------------------------------------------
#initialize instructions
#----------------------------------------------
msgInstructions = "Welcome!\n\n\
In this experiment, all you have to do is [PLACEHOLDER].\n\n\
Press the spacebar to begin..."
#----------------------------------------------
#initialize and randomize profile resumes
#----------------------------------------------
resume1 = "BLURB 1"
resume2 = "BLURB 2"
resume3 = "BLURB 3"
resume4 = "BLURB 4"
resume5 = "BLURB 5"
resume6 = "BLURB 6"
resume7 = "BLURB 7"
resume8 = "BLURB 8"

resumeList = [resume1,resume2,resume3,resume4,resume5,resume6,resume7,resume8]
resumeScrambler = random.sample(resumeList, 8)
#----------------------------------------------
#select and randomize profile pictures
#----------------------------------------------
wm = "images/whiteMale%i.png"%(random.sample(range(1,6),1)[0])
wf = "images/whiteFemale%i.png"%(random.sample(range(1,6),1)[0])
bm = "images/blackMale%i.png"%(random.sample(range(1,6),1)[0])
bf = "images/blackFemale%i.png"%(random.sample(range(1,6),1)[0])
hm = "images/hispanicMale%i.png"%(random.sample(range(1,6),1)[0])
hf = "images/hispanicFemale%i.png"%(random.sample(range(1,6),1)[0])
am = "images/asianMale%i.png"%(random.sample(range(1,6),1)[0])
af = "images/asianFemale%i.png"%(random.sample(range(1,6),1)[0])

picList = [wm,wf,bm,bf,hm,hf,am,af]
picScrambler = random.sample(picList, 8)

#----------------------------------------------
#initialize and randomize question order
#----------------------------------------------
#competence, experience, friendliness, overall qualification
questionCounter = 0

compQuestion = "competence question PLACEHOLDER"
expQuestion = "experience question PLACEHOLDER"
friendlyQuestion = "friendliness question PLACEHOLDER"
qualQuestion = "overall qualification question PLACEHOLDER"

questionList = [compQuestion,expQuestion,friendlyQuestion,qualQuestion]
questionScrambler = random.sample(questionList, 4)
text = visual.TextStim(win=win, name='text',
    text='default text',
    font='Arial',
    pos=[0, 0], height=50, wrapWidth=1600, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "profile"
profileClock = core.Clock()
win.color = [-1,-1,-1]

profilePicture = visual.ImageStim(
    win=win, name='profilePicture',
    image='sin', mask=None,
    ori=0, pos=[0, 0], size=[400, 350],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
profileResume = visual.TextStim(win=win, name='profileResume',
    text='default text',
    font='Arial',
    pos=(0, -300), height=24, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);

# Initialize components for Routine "question1"
question1Clock = core.Clock()

questionText1 = visual.TextStim(win=win, name='questionText1',
    text='default text',
    font='Arial',
    pos=[0, 0], height=50, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "question2"
question2Clock = core.Clock()

questionText2 = visual.TextStim(win=win, name='questionText2',
    text='default text',
    font='Arial',
    pos=[0, 0], height=50, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "question3"
question3Clock = core.Clock()

questionText3 = visual.TextStim(win=win, name='questionText3',
    text='default text',
    font='Arial',
    pos=[0, 0], height=50, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "question4"
question4Clock = core.Clock()

questionText4 = visual.TextStim(win=win, name='questionText4',
    text='default text',
    font='Arial',
    pos=[0, 0], height=50, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "ranking"
rankingClock = core.Clock()
win.color = [-1,-1,-1]


profilePic1 = visual.ImageStim(
    win=win, name='profilePic1',
    image='sin', mask=None,
    ori=0, pos=[-600, 400], size=[320,280],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
profilePic2 = visual.ImageStim(
    win=win, name='profilePic2',
    image='sin', mask=None,
    ori=0, pos=[-200, 400], size=[320, 280],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-2.0)
profilePic3 = visual.ImageStim(
    win=win, name='profilePic3',
    image='sin', mask=None,
    ori=0, pos=[200,400], size=[320, 280],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-3.0)
profilePic4 = visual.ImageStim(
    win=win, name='profilePic4',
    image='sin', mask=None,
    ori=0, pos=[600,400], size=[320, 280],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-4.0)
profilePic5 = visual.ImageStim(
    win=win, name='profilePic5',
    image='sin', mask=None,
    ori=0, pos=[-600, -100], size=[320, 280],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-5.0)
profileResume3 = visual.TextStim(win=win, name='profileResume3',
    text='default text',
    font='Arial',
    pos=[-600, 200], height=24, wrapWidth=None, ori=0, 
    color=[0.506,0.506,0.506], colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-6.0);

# Initialize components for Routine "Goodbye"
GoodbyeClock = core.Clock()
text_3 = visual.TextStim(win=win, name='text_3',
    text='"Done!"',
    font='Arial',
    pos=[0, 0], height=100, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "instructions"-------
t = 0
instructionsClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat

text.setText(msgInstructions)
key_resp_instructionScreen = event.BuilderKeyResponse()
# keep track of which components have finished
instructionsComponents = [text, key_resp_instructionScreen]
for thisComponent in instructionsComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "instructions"-------
while continueRoutine:
    # get current time
    t = instructionsClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    
    # *text* updates
    if t >= 0.0 and text.status == NOT_STARTED:
        # keep track of start time/frame for later
        text.tStart = t
        text.frameNStart = frameN  # exact frame index
        text.setAutoDraw(True)
    
    # *key_resp_instructionScreen* updates
    if t >= 0.0 and key_resp_instructionScreen.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_instructionScreen.tStart = t
        key_resp_instructionScreen.frameNStart = frameN  # exact frame index
        key_resp_instructionScreen.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(key_resp_instructionScreen.clock.reset)  # t=0 on next screen flip
        event.clearEvents(eventType='keyboard')
    if key_resp_instructionScreen.status == STARTED:
        theseKeys = event.getKeys(keyList=['space'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            key_resp_instructionScreen.keys = theseKeys[-1]  # just the last key pressed
            key_resp_instructionScreen.rt = key_resp_instructionScreen.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instructionsComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "instructions"-------
for thisComponent in instructionsComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)

# check responses
if key_resp_instructionScreen.keys in ['', [], None]:  # No response was made
    key_resp_instructionScreen.keys=None
thisExp.addData('key_resp_instructionScreen.keys',key_resp_instructionScreen.keys)
if key_resp_instructionScreen.keys != None:  # we had a response
    thisExp.addData('key_resp_instructionScreen.rt', key_resp_instructionScreen.rt)
thisExp.nextEntry()
# the Routine "instructions" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
profileLoop = data.TrialHandler(nReps=8, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=[None],
    seed=None, name='profileLoop')
thisExp.addLoop(profileLoop)  # add the loop to the experiment
thisProfileLoop = profileLoop.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisProfileLoop.rgb)
if thisProfileLoop != None:
    for paramName in thisProfileLoop:
        exec('{} = thisProfileLoop[paramName]'.format(paramName))

for thisProfileLoop in profileLoop:
    currentLoop = profileLoop
    # abbreviate parameter names if possible (e.g. rgb = thisProfileLoop.rgb)
    if thisProfileLoop != None:
        for paramName in thisProfileLoop:
            exec('{} = thisProfileLoop[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "profile"-------
    t = 0
    profileClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    
    profilePicture.setImage(picScrambler[candidateCounter])
    profileResume.setText(resumeScrambler[candidateCounter])
    key_resp_profile = event.BuilderKeyResponse()
    # keep track of which components have finished
    profileComponents = [profilePicture, profileResume, key_resp_profile]
    for thisComponent in profileComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "profile"-------
    while continueRoutine:
        # get current time
        t = profileClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        
        
        # *profilePicture* updates
        if t >= 0.0 and profilePicture.status == NOT_STARTED:
            # keep track of start time/frame for later
            profilePicture.tStart = t
            profilePicture.frameNStart = frameN  # exact frame index
            profilePicture.setAutoDraw(True)
        
        # *profileResume* updates
        if t >= 0.0 and profileResume.status == NOT_STARTED:
            # keep track of start time/frame for later
            profileResume.tStart = t
            profileResume.frameNStart = frameN  # exact frame index
            profileResume.setAutoDraw(True)
        
        # *key_resp_profile* updates
        if t >= 0.0 and key_resp_profile.status == NOT_STARTED:
            # keep track of start time/frame for later
            key_resp_profile.tStart = t
            key_resp_profile.frameNStart = frameN  # exact frame index
            key_resp_profile.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(key_resp_profile.clock.reset)  # t=0 on next screen flip
            event.clearEvents(eventType='keyboard')
        if key_resp_profile.status == STARTED:
            theseKeys = event.getKeys(keyList=['space'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                key_resp_profile.keys = theseKeys[-1]  # just the last key pressed
                key_resp_profile.rt = key_resp_profile.clock.getTime()
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in profileComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "profile"-------
    for thisComponent in profileComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    candidateCounter = candidateCounter + 1
    # check responses
    if key_resp_profile.keys in ['', [], None]:  # No response was made
        key_resp_profile.keys=None
    profileLoop.addData('key_resp_profile.keys',key_resp_profile.keys)
    if key_resp_profile.keys != None:  # we had a response
        profileLoop.addData('key_resp_profile.rt', key_resp_profile.rt)
    # the Routine "profile" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "question1"-------
    t = 0
    question1Clock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    
    questionText1.setText(questionScrambler[questionCounter])
    key_resp_question = event.BuilderKeyResponse()
    # keep track of which components have finished
    question1Components = [questionText1, key_resp_question]
    for thisComponent in question1Components:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "question1"-------
    while continueRoutine:
        # get current time
        t = question1Clock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        
        # *questionText1* updates
        if t >= 0.0 and questionText1.status == NOT_STARTED:
            # keep track of start time/frame for later
            questionText1.tStart = t
            questionText1.frameNStart = frameN  # exact frame index
            questionText1.setAutoDraw(True)
        
        # *key_resp_question* updates
        if t >= 0.0 and key_resp_question.status == NOT_STARTED:
            # keep track of start time/frame for later
            key_resp_question.tStart = t
            key_resp_question.frameNStart = frameN  # exact frame index
            key_resp_question.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(key_resp_question.clock.reset)  # t=0 on next screen flip
            event.clearEvents(eventType='keyboard')
        if key_resp_question.status == STARTED:
            theseKeys = event.getKeys(keyList=['space', 'y', 'n', '1', '2', '3', '4', '5'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                key_resp_question.keys = theseKeys[-1]  # just the last key pressed
                key_resp_question.rt = key_resp_question.clock.getTime()
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in question1Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "question1"-------
    for thisComponent in question1Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    questionCounter = questionCounter + 1
    # check responses
    if key_resp_question.keys in ['', [], None]:  # No response was made
        key_resp_question.keys=None
    profileLoop.addData('key_resp_question.keys',key_resp_question.keys)
    if key_resp_question.keys != None:  # we had a response
        profileLoop.addData('key_resp_question.rt', key_resp_question.rt)
    # the Routine "question1" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "question2"-------
    t = 0
    question2Clock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    
    questionText2.setText(questionScrambler[questionCounter])
    key_resp_question_2 = event.BuilderKeyResponse()
    # keep track of which components have finished
    question2Components = [questionText2, key_resp_question_2]
    for thisComponent in question2Components:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "question2"-------
    while continueRoutine:
        # get current time
        t = question2Clock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        
        # *questionText2* updates
        if t >= 0.0 and questionText2.status == NOT_STARTED:
            # keep track of start time/frame for later
            questionText2.tStart = t
            questionText2.frameNStart = frameN  # exact frame index
            questionText2.setAutoDraw(True)
        
        # *key_resp_question_2* updates
        if t >= 0.0 and key_resp_question_2.status == NOT_STARTED:
            # keep track of start time/frame for later
            key_resp_question_2.tStart = t
            key_resp_question_2.frameNStart = frameN  # exact frame index
            key_resp_question_2.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(key_resp_question_2.clock.reset)  # t=0 on next screen flip
            event.clearEvents(eventType='keyboard')
        if key_resp_question_2.status == STARTED:
            theseKeys = event.getKeys(keyList=['space', 'y', 'n', '1', '2', '3', '4', '5'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                key_resp_question_2.keys = theseKeys[-1]  # just the last key pressed
                key_resp_question_2.rt = key_resp_question_2.clock.getTime()
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in question2Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "question2"-------
    for thisComponent in question2Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    questionCounter = questionCounter + 1
    # check responses
    if key_resp_question_2.keys in ['', [], None]:  # No response was made
        key_resp_question_2.keys=None
    profileLoop.addData('key_resp_question_2.keys',key_resp_question_2.keys)
    if key_resp_question_2.keys != None:  # we had a response
        profileLoop.addData('key_resp_question_2.rt', key_resp_question_2.rt)
    # the Routine "question2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "question3"-------
    t = 0
    question3Clock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    
    questionText3.setText(questionScrambler[questionCounter])
    key_resp_question_3 = event.BuilderKeyResponse()
    # keep track of which components have finished
    question3Components = [questionText3, key_resp_question_3]
    for thisComponent in question3Components:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "question3"-------
    while continueRoutine:
        # get current time
        t = question3Clock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        
        # *questionText3* updates
        if t >= 0.0 and questionText3.status == NOT_STARTED:
            # keep track of start time/frame for later
            questionText3.tStart = t
            questionText3.frameNStart = frameN  # exact frame index
            questionText3.setAutoDraw(True)
        
        # *key_resp_question_3* updates
        if t >= 0.0 and key_resp_question_3.status == NOT_STARTED:
            # keep track of start time/frame for later
            key_resp_question_3.tStart = t
            key_resp_question_3.frameNStart = frameN  # exact frame index
            key_resp_question_3.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(key_resp_question_3.clock.reset)  # t=0 on next screen flip
            event.clearEvents(eventType='keyboard')
        if key_resp_question_3.status == STARTED:
            theseKeys = event.getKeys(keyList=['space', 'y', 'n', '1', '2', '3', '4', '5'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                key_resp_question_3.keys = theseKeys[-1]  # just the last key pressed
                key_resp_question_3.rt = key_resp_question_3.clock.getTime()
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in question3Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "question3"-------
    for thisComponent in question3Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    questionCounter = questionCounter + 1
    # check responses
    if key_resp_question_3.keys in ['', [], None]:  # No response was made
        key_resp_question_3.keys=None
    profileLoop.addData('key_resp_question_3.keys',key_resp_question_3.keys)
    if key_resp_question_3.keys != None:  # we had a response
        profileLoop.addData('key_resp_question_3.rt', key_resp_question_3.rt)
    # the Routine "question3" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "question4"-------
    t = 0
    question4Clock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    
    questionText4.setText(questionScrambler[questionCounter])
    key_resp_question_4 = event.BuilderKeyResponse()
    # keep track of which components have finished
    question4Components = [questionText4, key_resp_question_4]
    for thisComponent in question4Components:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "question4"-------
    while continueRoutine:
        # get current time
        t = question4Clock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        
        # *questionText4* updates
        if t >= 0.0 and questionText4.status == NOT_STARTED:
            # keep track of start time/frame for later
            questionText4.tStart = t
            questionText4.frameNStart = frameN  # exact frame index
            questionText4.setAutoDraw(True)
        
        # *key_resp_question_4* updates
        if t >= 0.0 and key_resp_question_4.status == NOT_STARTED:
            # keep track of start time/frame for later
            key_resp_question_4.tStart = t
            key_resp_question_4.frameNStart = frameN  # exact frame index
            key_resp_question_4.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(key_resp_question_4.clock.reset)  # t=0 on next screen flip
            event.clearEvents(eventType='keyboard')
        if key_resp_question_4.status == STARTED:
            theseKeys = event.getKeys(keyList=['space', 'y', 'n', '1', '2', '3', '4', '5'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                key_resp_question_4.keys = theseKeys[-1]  # just the last key pressed
                key_resp_question_4.rt = key_resp_question_4.clock.getTime()
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in question4Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "question4"-------
    for thisComponent in question4Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    questionCounter = 0
    # check responses
    if key_resp_question_4.keys in ['', [], None]:  # No response was made
        key_resp_question_4.keys=None
    profileLoop.addData('key_resp_question_4.keys',key_resp_question_4.keys)
    if key_resp_question_4.keys != None:  # we had a response
        profileLoop.addData('key_resp_question_4.rt', key_resp_question_4.rt)
    # the Routine "question4" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 8 repeats of 'profileLoop'


# ------Prepare to start Routine "ranking"-------
t = 0
rankingClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat


profilePic1.setImage(picScrambler[0])
profilePic2.setImage(picScrambler[1])
profilePic3.setImage(picScrambler[2])
profilePic4.setImage(picScrambler[3])
profilePic5.setImage(picScrambler[4])
profileResume3.setText('resumeScrambler[2]')
key_resp_ranking = event.BuilderKeyResponse()
# keep track of which components have finished
rankingComponents = [profilePic1, profilePic2, profilePic3, profilePic4, profilePic5, profileResume3, key_resp_ranking]
for thisComponent in rankingComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "ranking"-------
while continueRoutine:
    # get current time
    t = rankingClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    
    
    
    # *profilePic1* updates
    if t >= 0.0 and profilePic1.status == NOT_STARTED:
        # keep track of start time/frame for later
        profilePic1.tStart = t
        profilePic1.frameNStart = frameN  # exact frame index
        profilePic1.setAutoDraw(True)
    
    # *profilePic2* updates
    if t >= 0.0 and profilePic2.status == NOT_STARTED:
        # keep track of start time/frame for later
        profilePic2.tStart = t
        profilePic2.frameNStart = frameN  # exact frame index
        profilePic2.setAutoDraw(True)
    
    # *profilePic3* updates
    if t >= 0.0 and profilePic3.status == NOT_STARTED:
        # keep track of start time/frame for later
        profilePic3.tStart = t
        profilePic3.frameNStart = frameN  # exact frame index
        profilePic3.setAutoDraw(True)
    
    # *profilePic4* updates
    if t >= 0.0 and profilePic4.status == NOT_STARTED:
        # keep track of start time/frame for later
        profilePic4.tStart = t
        profilePic4.frameNStart = frameN  # exact frame index
        profilePic4.setAutoDraw(True)
    
    # *profilePic5* updates
    if t >= 0.0 and profilePic5.status == NOT_STARTED:
        # keep track of start time/frame for later
        profilePic5.tStart = t
        profilePic5.frameNStart = frameN  # exact frame index
        profilePic5.setAutoDraw(True)
    
    # *profileResume3* updates
    if t >= 0.0 and profileResume3.status == NOT_STARTED:
        # keep track of start time/frame for later
        profileResume3.tStart = t
        profileResume3.frameNStart = frameN  # exact frame index
        profileResume3.setAutoDraw(True)
    
    # *key_resp_ranking* updates
    if t >= 0.0 and key_resp_ranking.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_ranking.tStart = t
        key_resp_ranking.frameNStart = frameN  # exact frame index
        key_resp_ranking.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(key_resp_ranking.clock.reset)  # t=0 on next screen flip
        event.clearEvents(eventType='keyboard')
    if key_resp_ranking.status == STARTED:
        theseKeys = event.getKeys(keyList=['space'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            key_resp_ranking.keys = theseKeys[-1]  # just the last key pressed
            key_resp_ranking.rt = key_resp_ranking.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in rankingComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "ranking"-------
for thisComponent in rankingComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)

# check responses
if key_resp_ranking.keys in ['', [], None]:  # No response was made
    key_resp_ranking.keys=None
thisExp.addData('key_resp_ranking.keys',key_resp_ranking.keys)
if key_resp_ranking.keys != None:  # we had a response
    thisExp.addData('key_resp_ranking.rt', key_resp_ranking.rt)
thisExp.nextEntry()
# the Routine "ranking" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Goodbye"-------
t = 0
GoodbyeClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
key_resp_4 = event.BuilderKeyResponse()
# keep track of which components have finished
GoodbyeComponents = [text_3, key_resp_4]
for thisComponent in GoodbyeComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "Goodbye"-------
while continueRoutine:
    # get current time
    t = GoodbyeClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text_3* updates
    if t >= 0.0 and text_3.status == NOT_STARTED:
        # keep track of start time/frame for later
        text_3.tStart = t
        text_3.frameNStart = frameN  # exact frame index
        text_3.setAutoDraw(True)
    
    # *key_resp_4* updates
    if t >= 0.0 and key_resp_4.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_4.tStart = t
        key_resp_4.frameNStart = frameN  # exact frame index
        key_resp_4.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(key_resp_4.clock.reset)  # t=0 on next screen flip
        event.clearEvents(eventType='keyboard')
    if key_resp_4.status == STARTED:
        theseKeys = event.getKeys(keyList=['y', 'n', 'left', 'right', 'space'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            key_resp_4.keys = theseKeys[-1]  # just the last key pressed
            key_resp_4.rt = key_resp_4.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in GoodbyeComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Goodbye"-------
for thisComponent in GoodbyeComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if key_resp_4.keys in ['', [], None]:  # No response was made
    key_resp_4.keys=None
thisExp.addData('key_resp_4.keys',key_resp_4.keys)
if key_resp_4.keys != None:  # we had a response
    thisExp.addData('key_resp_4.rt', key_resp_4.rt)
thisExp.nextEntry()
# the Routine "Goodbye" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()







# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
