/********************************** 
 * Applejacksracehiringstudy Test *
 **********************************/

import { PsychoJS } from './lib/core-3.0.2.js';
import * as core from './lib/core-3.0.2.js';
import { TrialHandler } from './lib/data-3.0.2.js';
import { Scheduler } from './lib/util-3.0.2.js';
import * as util from './lib/util-3.0.2.js';
import * as visual from './lib/visual-3.0.2.js';
import { Sound } from './lib/sound-3.0.2.js';

// init psychoJS:
var psychoJS = new PsychoJS({
  debug: true
});

// open window:
psychoJS.openWindow({
  fullscr: true,
  color: new util.Color([0, 0, 0]),
  units: 'pix'
});

// store info about the experiment session:
let expName = 'appleJacksRaceHiringStudy';  // from the Builder filename that created this script
let expInfo = {
    'participant': '',
    'session': '1',
};

// schedule the experiment:
psychoJS.schedule(psychoJS.gui.DlgFromDict({
  dictionary: expInfo,
  title: expName
}));

const flowScheduler = new Scheduler(psychoJS);
const dialogCancelScheduler = new Scheduler(psychoJS);
psychoJS.scheduleCondition(function() { return (psychoJS.gui.dialogComponent.button === 'OK'); }, flowScheduler, dialogCancelScheduler);

// flowScheduler gets run if the participants presses OK
flowScheduler.add(updateInfo); // add timeStamp
flowScheduler.add(experimentInit);
flowScheduler.add(instructionsRoutineBegin);
flowScheduler.add(instructionsRoutineEachFrame);
flowScheduler.add(instructionsRoutineEnd);
const profileLoopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(profileLoopLoopBegin, profileLoopLoopScheduler);
flowScheduler.add(profileLoopLoopScheduler);
flowScheduler.add(profileLoopLoopEnd);
flowScheduler.add(rankingRoutineBegin);
flowScheduler.add(rankingRoutineEachFrame);
flowScheduler.add(rankingRoutineEnd);
flowScheduler.add(GoodbyeRoutineBegin);
flowScheduler.add(GoodbyeRoutineEachFrame);
flowScheduler.add(GoodbyeRoutineEnd);
flowScheduler.add(quitPsychoJS, '', true);

// quit if user presses Cancel in dialog box:
dialogCancelScheduler.add(quitPsychoJS, '', false);

psychoJS.start({configURL: 'config.json', expInfo: expInfo});

var frameDur;
function updateInfo() {
  expInfo['date'] = util.MonotonicClock.getDateStr();  // add a simple timestamp
  expInfo['expName'] = expName;
  expInfo['psychopyVersion'] = '3.0.2';

  // store frame rate of monitor if we can measure it successfully
  expInfo['frameRate'] = psychoJS.window.getActualFrameRate();
  if (typeof expInfo['frameRate'] !== 'undefined')
    frameDur = 1.0/Math.round(expInfo['frameRate']);
  else
    frameDur = 1.0/60.0; // couldn't get a reliable measure so guess

  // add info from the URL:
  util.addInfoFromUrl(expInfo);
  
  return Scheduler.Event.NEXT;
}

var instructionsClock;
var text;
var profileClock;
var profilePicture;
var profileResume;
var question1Clock;
var questionText1;
var question2Clock;
var questionText2;
var question3Clock;
var questionText3;
var question4Clock;
var questionText4;
var rankingClock;
var profilePic1;
var profilePic2;
var profilePic3;
var profilePic4;
var profilePic5;
var profileResume3;
var GoodbyeClock;
var text_3;
var globalClock;
var routineTimer;
function experimentInit() {
  // Initialize components for Routine "instructions"
  instructionsClock = new util.Clock();
  
  text = new visual.TextStim({
    win: psychoJS.window,
    name: 'text',
    text: 'default text',
    font: 'Arial',
    pos: [0, 0], height: 50,  wrapWidth: 1600, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0 
  });
  
  // Initialize components for Routine "profile"
  profileClock = new util.Clock();
  
  profilePicture = new visual.ImageStim({
    win : psychoJS.window,
    name : 'profilePicture', 
    image : undefined, mask : undefined,
    ori : 0, pos : [0, 0], size : [400, 350],
    color : new util.Color([1, 1, 1]), opacity : 1,
    flipHoriz : false, flipVert : false,
    texRes : 128, interpolate : true, depth : -1.0 
  });
  profileResume = new visual.TextStim({
    win: psychoJS.window,
    name: 'profileResume',
    text: 'default text',
    font: 'Arial',
    pos: [0, (- 300)], height: 24,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -2.0 
  });
  
  // Initialize components for Routine "question1"
  question1Clock = new util.Clock();
  
  questionText1 = new visual.TextStim({
    win: psychoJS.window,
    name: 'questionText1',
    text: 'default text',
    font: 'Arial',
    pos: [0, 0], height: 50,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0 
  });
  
  // Initialize components for Routine "question2"
  question2Clock = new util.Clock();
  
  questionText2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'questionText2',
    text: 'default text',
    font: 'Arial',
    pos: [0, 0], height: 50,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0 
  });
  
  // Initialize components for Routine "question3"
  question3Clock = new util.Clock();
  
  questionText3 = new visual.TextStim({
    win: psychoJS.window,
    name: 'questionText3',
    text: 'default text',
    font: 'Arial',
    pos: [0, 0], height: 50,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0 
  });
  
  // Initialize components for Routine "question4"
  question4Clock = new util.Clock();
  
  questionText4 = new visual.TextStim({
    win: psychoJS.window,
    name: 'questionText4',
    text: 'default text',
    font: 'Arial',
    pos: [0, 0], height: 50,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0 
  });
  
  // Initialize components for Routine "ranking"
  rankingClock = new util.Clock();
  
  profilePic1 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'profilePic1', 
    image : undefined, mask : undefined,
    ori : 0, pos : [(- 600), 400], size : [320, 280],
    color : new util.Color([1, 1, 1]), opacity : 1,
    flipHoriz : false, flipVert : false,
    texRes : 128, interpolate : true, depth : -1.0 
  });
  profilePic2 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'profilePic2', 
    image : undefined, mask : undefined,
    ori : 0, pos : [(- 200), 400], size : [320, 280],
    color : new util.Color([1, 1, 1]), opacity : 1,
    flipHoriz : false, flipVert : false,
    texRes : 128, interpolate : true, depth : -2.0 
  });
  profilePic3 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'profilePic3', 
    image : undefined, mask : undefined,
    ori : 0, pos : [200, 400], size : [320, 280],
    color : new util.Color([1, 1, 1]), opacity : 1,
    flipHoriz : false, flipVert : false,
    texRes : 128, interpolate : true, depth : -3.0 
  });
  profilePic4 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'profilePic4', 
    image : undefined, mask : undefined,
    ori : 0, pos : [600, 400], size : [320, 280],
    color : new util.Color([1, 1, 1]), opacity : 1,
    flipHoriz : false, flipVert : false,
    texRes : 128, interpolate : true, depth : -4.0 
  });
  profilePic5 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'profilePic5', 
    image : undefined, mask : undefined,
    ori : 0, pos : [(- 600), (- 100)], size : [320, 280],
    color : new util.Color([1, 1, 1]), opacity : 1,
    flipHoriz : false, flipVert : false,
    texRes : 128, interpolate : true, depth : -5.0 
  });
  profileResume3 = new visual.TextStim({
    win: psychoJS.window,
    name: 'profileResume3',
    text: 'default text',
    font: 'Arial',
    pos: [(- 600), 200], height: 24,  wrapWidth: undefined, ori: 0,
    color: new util.Color([0.506, 0.506, 0.506]),  opacity: 1,
    depth: -6.0 
  });
  
  // Initialize components for Routine "Goodbye"
  GoodbyeClock = new util.Clock();
  text_3 = new visual.TextStim({
    win: psychoJS.window,
    name: 'text_3',
    text: '"Done!"',
    font: 'Arial',
    pos: [0, 0], height: 100,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  // Create some handy timers
  globalClock = new util.Clock();  // to track the time since experiment started
  routineTimer = new util.CountdownTimer();  // to track time remaining of each (non-slip) routine
  
  return Scheduler.Event.NEXT;
}

var t;
var frameN;
var key_resp_instructionScreen;
var instructionsComponents;
function instructionsRoutineBegin() {
  //------Prepare to start Routine 'instructions'-------
  t = 0;
  instructionsClock.reset(); // clock
  frameN = -1;
  // update component parameters for each repeat
  
  text.setText(msgInstructions);
  key_resp_instructionScreen = new core.BuilderKeyResponse(psychoJS);
  // keep track of which components have finished
  instructionsComponents = [];
  instructionsComponents.push(text);
  instructionsComponents.push(key_resp_instructionScreen);
  
  for (const thisComponent of instructionsComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;
  
  return Scheduler.Event.NEXT;
}

var continueRoutine;
function instructionsRoutineEachFrame() {
  //------Loop for each frame of Routine 'instructions'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = instructionsClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame
  
  
  // *text* updates
  if (t >= 0.0 && text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    text.tStart = t;  // (not accounting for frame time here)
    text.frameNStart = frameN;  // exact frame index
    text.setAutoDraw(true);
  }

  
  // *key_resp_instructionScreen* updates
  if (t >= 0.0 && key_resp_instructionScreen.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    key_resp_instructionScreen.tStart = t;  // (not accounting for frame time here)
    key_resp_instructionScreen.frameNStart = frameN;  // exact frame index
    key_resp_instructionScreen.status = PsychoJS.Status.STARTED;
    // keyboard checking is just starting
    psychoJS.window.callOnFlip(function() { key_resp_instructionScreen.clock.reset(); }); // t = 0 on screen flip
    psychoJS.eventManager.clearEvents({eventType:'keyboard'});
  }

  if (key_resp_instructionScreen.status === PsychoJS.Status.STARTED) {
    let theseKeys = psychoJS.eventManager.getKeys({keyList:['space']});
    
    // check for quit:
    if (theseKeys.indexOf('escape') > -1) {
        psychoJS.experiment.experimentEnded = true;
    }
    if (theseKeys.length > 0) {  // at least one key was pressed
      key_resp_instructionScreen.keys = theseKeys[theseKeys.length-1];  // just the last key pressed
      key_resp_instructionScreen.rt = key_resp_instructionScreen.clock.getTime();
      // a response ends the routine
      continueRoutine = false;
    }
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }
  
  continueRoutine = false;// reverts to True if at least one component still running
  for (const thisComponent of instructionsComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }
  
  // check for quit (the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // refresh the screen if continuing
  if (continueRoutine) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function instructionsRoutineEnd() {
  //------Ending Routine 'instructions'-------
  for (const thisComponent of instructionsComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  
  
  // check responses
  if (['', [], undefined].indexOf(key_resp_instructionScreen.keys) >= 0) {    // No response was made
      key_resp_instructionScreen.keys = undefined;
  }
  
  psychoJS.experiment.addData('key_resp_instructionScreen.keys', key_resp_instructionScreen.keys);
  if (typeof key_resp_instructionScreen.keys !== 'undefined') {  // we had a response
      psychoJS.experiment.addData('key_resp_instructionScreen.rt', key_resp_instructionScreen.rt);
      routineTimer.reset();
      }
  
  // the Routine "instructions" was not non-slip safe, so reset the non-slip timer
  routineTimer.reset();
  
  return Scheduler.Event.NEXT;
}

var profileLoop;
function profileLoopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  profileLoop = new TrialHandler({
    psychoJS,
    nReps: 8, method: TrialHandler.Method.RANDOM,
    extraInfo: expInfo, originPath: undefined,
    trialList: undefined,
    seed: undefined, name: 'profileLoop'});
  psychoJS.experiment.addLoop(profileLoop); // add the loop to the experiment

  // Schedule all the trials in the trialList:
  for (const thisProfileLoop of profileLoop) {
    thisScheduler.add(importConditions(profileLoop));
    thisScheduler.add(profileRoutineBegin);
    thisScheduler.add(profileRoutineEachFrame);
    thisScheduler.add(profileRoutineEnd);
    thisScheduler.add(question1RoutineBegin);
    thisScheduler.add(question1RoutineEachFrame);
    thisScheduler.add(question1RoutineEnd);
    thisScheduler.add(question2RoutineBegin);
    thisScheduler.add(question2RoutineEachFrame);
    thisScheduler.add(question2RoutineEnd);
    thisScheduler.add(question3RoutineBegin);
    thisScheduler.add(question3RoutineEachFrame);
    thisScheduler.add(question3RoutineEnd);
    thisScheduler.add(question4RoutineBegin);
    thisScheduler.add(question4RoutineEachFrame);
    thisScheduler.add(question4RoutineEnd);
    thisScheduler.add(endLoopIteration(thisProfileLoop));
  }

  return Scheduler.Event.NEXT;
}


function profileLoopLoopEnd() {
  psychoJS.experiment.removeLoop(profileLoop);

  return Scheduler.Event.NEXT;
}

var key_resp_profile;
var profileComponents;
function profileRoutineBegin() {
  //------Prepare to start Routine 'profile'-------
  t = 0;
  profileClock.reset(); // clock
  frameN = -1;
  // update component parameters for each repeat
  
  profilePicture.setImage(picScrambler[candidateCounter]);
  profileResume.setText(resumeScrambler[candidateCounter]);
  key_resp_profile = new core.BuilderKeyResponse(psychoJS);
  // keep track of which components have finished
  profileComponents = [];
  profileComponents.push(profilePicture);
  profileComponents.push(profileResume);
  profileComponents.push(key_resp_profile);
  
  for (const thisComponent of profileComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;
  
  return Scheduler.Event.NEXT;
}


function profileRoutineEachFrame() {
  //------Loop for each frame of Routine 'profile'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = profileClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame
  
  
  // *profilePicture* updates
  if (t >= 0.0 && profilePicture.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    profilePicture.tStart = t;  // (not accounting for frame time here)
    profilePicture.frameNStart = frameN;  // exact frame index
    profilePicture.setAutoDraw(true);
  }

  
  // *profileResume* updates
  if (t >= 0.0 && profileResume.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    profileResume.tStart = t;  // (not accounting for frame time here)
    profileResume.frameNStart = frameN;  // exact frame index
    profileResume.setAutoDraw(true);
  }

  
  // *key_resp_profile* updates
  if (t >= 0.0 && key_resp_profile.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    key_resp_profile.tStart = t;  // (not accounting for frame time here)
    key_resp_profile.frameNStart = frameN;  // exact frame index
    key_resp_profile.status = PsychoJS.Status.STARTED;
    // keyboard checking is just starting
    psychoJS.window.callOnFlip(function() { key_resp_profile.clock.reset(); }); // t = 0 on screen flip
    psychoJS.eventManager.clearEvents({eventType:'keyboard'});
  }

  if (key_resp_profile.status === PsychoJS.Status.STARTED) {
    let theseKeys = psychoJS.eventManager.getKeys({keyList:['space']});
    
    // check for quit:
    if (theseKeys.indexOf('escape') > -1) {
        psychoJS.experiment.experimentEnded = true;
    }
    if (theseKeys.length > 0) {  // at least one key was pressed
      key_resp_profile.keys = theseKeys[theseKeys.length-1];  // just the last key pressed
      key_resp_profile.rt = key_resp_profile.clock.getTime();
      // a response ends the routine
      continueRoutine = false;
    }
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }
  
  continueRoutine = false;// reverts to True if at least one component still running
  for (const thisComponent of profileComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }
  
  // check for quit (the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // refresh the screen if continuing
  if (continueRoutine) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function profileRoutineEnd() {
  //------Ending Routine 'profile'-------
  for (const thisComponent of profileComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  
  
  // check responses
  if (['', [], undefined].indexOf(key_resp_profile.keys) >= 0) {    // No response was made
      key_resp_profile.keys = undefined;
  }
  
  psychoJS.experiment.addData('key_resp_profile.keys', key_resp_profile.keys);
  if (typeof key_resp_profile.keys !== 'undefined') {  // we had a response
      psychoJS.experiment.addData('key_resp_profile.rt', key_resp_profile.rt);
      routineTimer.reset();
      }
  
  // the Routine "profile" was not non-slip safe, so reset the non-slip timer
  routineTimer.reset();
  
  return Scheduler.Event.NEXT;
}

var key_resp_question;
var question1Components;
function question1RoutineBegin() {
  //------Prepare to start Routine 'question1'-------
  t = 0;
  question1Clock.reset(); // clock
  frameN = -1;
  // update component parameters for each repeat
  
  questionText1.setText(questionScrambler[questionCounter]);
  key_resp_question = new core.BuilderKeyResponse(psychoJS);
  // keep track of which components have finished
  question1Components = [];
  question1Components.push(questionText1);
  question1Components.push(key_resp_question);
  
  for (const thisComponent of question1Components)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;
  
  return Scheduler.Event.NEXT;
}


function question1RoutineEachFrame() {
  //------Loop for each frame of Routine 'question1'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = question1Clock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame
  
  
  // *questionText1* updates
  if (t >= 0.0 && questionText1.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    questionText1.tStart = t;  // (not accounting for frame time here)
    questionText1.frameNStart = frameN;  // exact frame index
    questionText1.setAutoDraw(true);
  }

  
  // *key_resp_question* updates
  if (t >= 0.0 && key_resp_question.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    key_resp_question.tStart = t;  // (not accounting for frame time here)
    key_resp_question.frameNStart = frameN;  // exact frame index
    key_resp_question.status = PsychoJS.Status.STARTED;
    // keyboard checking is just starting
    psychoJS.window.callOnFlip(function() { key_resp_question.clock.reset(); }); // t = 0 on screen flip
    psychoJS.eventManager.clearEvents({eventType:'keyboard'});
  }

  if (key_resp_question.status === PsychoJS.Status.STARTED) {
    let theseKeys = psychoJS.eventManager.getKeys({keyList:['space', 'y', 'n', '1', '2', '3', '4', '5']});
    
    // check for quit:
    if (theseKeys.indexOf('escape') > -1) {
        psychoJS.experiment.experimentEnded = true;
    }
    if (theseKeys.length > 0) {  // at least one key was pressed
      key_resp_question.keys = theseKeys[theseKeys.length-1];  // just the last key pressed
      key_resp_question.rt = key_resp_question.clock.getTime();
      // a response ends the routine
      continueRoutine = false;
    }
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }
  
  continueRoutine = false;// reverts to True if at least one component still running
  for (const thisComponent of question1Components)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }
  
  // check for quit (the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // refresh the screen if continuing
  if (continueRoutine) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function question1RoutineEnd() {
  //------Ending Routine 'question1'-------
  for (const thisComponent of question1Components) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  
  
  // check responses
  if (['', [], undefined].indexOf(key_resp_question.keys) >= 0) {    // No response was made
      key_resp_question.keys = undefined;
  }
  
  psychoJS.experiment.addData('key_resp_question.keys', key_resp_question.keys);
  if (typeof key_resp_question.keys !== 'undefined') {  // we had a response
      psychoJS.experiment.addData('key_resp_question.rt', key_resp_question.rt);
      routineTimer.reset();
      }
  
  // the Routine "question1" was not non-slip safe, so reset the non-slip timer
  routineTimer.reset();
  
  return Scheduler.Event.NEXT;
}

var key_resp_question_2;
var question2Components;
function question2RoutineBegin() {
  //------Prepare to start Routine 'question2'-------
  t = 0;
  question2Clock.reset(); // clock
  frameN = -1;
  // update component parameters for each repeat
  
  questionText2.setText(questionScrambler[questionCounter]);
  key_resp_question_2 = new core.BuilderKeyResponse(psychoJS);
  // keep track of which components have finished
  question2Components = [];
  question2Components.push(questionText2);
  question2Components.push(key_resp_question_2);
  
  for (const thisComponent of question2Components)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;
  
  return Scheduler.Event.NEXT;
}


function question2RoutineEachFrame() {
  //------Loop for each frame of Routine 'question2'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = question2Clock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame
  
  
  // *questionText2* updates
  if (t >= 0.0 && questionText2.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    questionText2.tStart = t;  // (not accounting for frame time here)
    questionText2.frameNStart = frameN;  // exact frame index
    questionText2.setAutoDraw(true);
  }

  
  // *key_resp_question_2* updates
  if (t >= 0.0 && key_resp_question_2.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    key_resp_question_2.tStart = t;  // (not accounting for frame time here)
    key_resp_question_2.frameNStart = frameN;  // exact frame index
    key_resp_question_2.status = PsychoJS.Status.STARTED;
    // keyboard checking is just starting
    psychoJS.window.callOnFlip(function() { key_resp_question_2.clock.reset(); }); // t = 0 on screen flip
    psychoJS.eventManager.clearEvents({eventType:'keyboard'});
  }

  if (key_resp_question_2.status === PsychoJS.Status.STARTED) {
    let theseKeys = psychoJS.eventManager.getKeys({keyList:['space', 'y', 'n', '1', '2', '3', '4', '5']});
    
    // check for quit:
    if (theseKeys.indexOf('escape') > -1) {
        psychoJS.experiment.experimentEnded = true;
    }
    if (theseKeys.length > 0) {  // at least one key was pressed
      key_resp_question_2.keys = theseKeys[theseKeys.length-1];  // just the last key pressed
      key_resp_question_2.rt = key_resp_question_2.clock.getTime();
      // a response ends the routine
      continueRoutine = false;
    }
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }
  
  continueRoutine = false;// reverts to True if at least one component still running
  for (const thisComponent of question2Components)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }
  
  // check for quit (the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // refresh the screen if continuing
  if (continueRoutine) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function question2RoutineEnd() {
  //------Ending Routine 'question2'-------
  for (const thisComponent of question2Components) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  
  
  // check responses
  if (['', [], undefined].indexOf(key_resp_question_2.keys) >= 0) {    // No response was made
      key_resp_question_2.keys = undefined;
  }
  
  psychoJS.experiment.addData('key_resp_question_2.keys', key_resp_question_2.keys);
  if (typeof key_resp_question_2.keys !== 'undefined') {  // we had a response
      psychoJS.experiment.addData('key_resp_question_2.rt', key_resp_question_2.rt);
      routineTimer.reset();
      }
  
  // the Routine "question2" was not non-slip safe, so reset the non-slip timer
  routineTimer.reset();
  
  return Scheduler.Event.NEXT;
}

var key_resp_question_3;
var question3Components;
function question3RoutineBegin() {
  //------Prepare to start Routine 'question3'-------
  t = 0;
  question3Clock.reset(); // clock
  frameN = -1;
  // update component parameters for each repeat
  
  questionText3.setText(questionScrambler[questionCounter]);
  key_resp_question_3 = new core.BuilderKeyResponse(psychoJS);
  // keep track of which components have finished
  question3Components = [];
  question3Components.push(questionText3);
  question3Components.push(key_resp_question_3);
  
  for (const thisComponent of question3Components)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;
  
  return Scheduler.Event.NEXT;
}


function question3RoutineEachFrame() {
  //------Loop for each frame of Routine 'question3'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = question3Clock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame
  
  
  // *questionText3* updates
  if (t >= 0.0 && questionText3.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    questionText3.tStart = t;  // (not accounting for frame time here)
    questionText3.frameNStart = frameN;  // exact frame index
    questionText3.setAutoDraw(true);
  }

  
  // *key_resp_question_3* updates
  if (t >= 0.0 && key_resp_question_3.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    key_resp_question_3.tStart = t;  // (not accounting for frame time here)
    key_resp_question_3.frameNStart = frameN;  // exact frame index
    key_resp_question_3.status = PsychoJS.Status.STARTED;
    // keyboard checking is just starting
    psychoJS.window.callOnFlip(function() { key_resp_question_3.clock.reset(); }); // t = 0 on screen flip
    psychoJS.eventManager.clearEvents({eventType:'keyboard'});
  }

  if (key_resp_question_3.status === PsychoJS.Status.STARTED) {
    let theseKeys = psychoJS.eventManager.getKeys({keyList:['space', 'y', 'n', '1', '2', '3', '4', '5']});
    
    // check for quit:
    if (theseKeys.indexOf('escape') > -1) {
        psychoJS.experiment.experimentEnded = true;
    }
    if (theseKeys.length > 0) {  // at least one key was pressed
      key_resp_question_3.keys = theseKeys[theseKeys.length-1];  // just the last key pressed
      key_resp_question_3.rt = key_resp_question_3.clock.getTime();
      // a response ends the routine
      continueRoutine = false;
    }
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }
  
  continueRoutine = false;// reverts to True if at least one component still running
  for (const thisComponent of question3Components)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }
  
  // check for quit (the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // refresh the screen if continuing
  if (continueRoutine) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function question3RoutineEnd() {
  //------Ending Routine 'question3'-------
  for (const thisComponent of question3Components) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  
  
  // check responses
  if (['', [], undefined].indexOf(key_resp_question_3.keys) >= 0) {    // No response was made
      key_resp_question_3.keys = undefined;
  }
  
  psychoJS.experiment.addData('key_resp_question_3.keys', key_resp_question_3.keys);
  if (typeof key_resp_question_3.keys !== 'undefined') {  // we had a response
      psychoJS.experiment.addData('key_resp_question_3.rt', key_resp_question_3.rt);
      routineTimer.reset();
      }
  
  // the Routine "question3" was not non-slip safe, so reset the non-slip timer
  routineTimer.reset();
  
  return Scheduler.Event.NEXT;
}

var key_resp_question_4;
var question4Components;
function question4RoutineBegin() {
  //------Prepare to start Routine 'question4'-------
  t = 0;
  question4Clock.reset(); // clock
  frameN = -1;
  // update component parameters for each repeat
  
  questionText4.setText(questionScrambler[questionCounter]);
  key_resp_question_4 = new core.BuilderKeyResponse(psychoJS);
  // keep track of which components have finished
  question4Components = [];
  question4Components.push(questionText4);
  question4Components.push(key_resp_question_4);
  
  for (const thisComponent of question4Components)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;
  
  return Scheduler.Event.NEXT;
}


function question4RoutineEachFrame() {
  //------Loop for each frame of Routine 'question4'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = question4Clock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame
  
  
  // *questionText4* updates
  if (t >= 0.0 && questionText4.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    questionText4.tStart = t;  // (not accounting for frame time here)
    questionText4.frameNStart = frameN;  // exact frame index
    questionText4.setAutoDraw(true);
  }

  
  // *key_resp_question_4* updates
  if (t >= 0.0 && key_resp_question_4.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    key_resp_question_4.tStart = t;  // (not accounting for frame time here)
    key_resp_question_4.frameNStart = frameN;  // exact frame index
    key_resp_question_4.status = PsychoJS.Status.STARTED;
    // keyboard checking is just starting
    psychoJS.window.callOnFlip(function() { key_resp_question_4.clock.reset(); }); // t = 0 on screen flip
    psychoJS.eventManager.clearEvents({eventType:'keyboard'});
  }

  if (key_resp_question_4.status === PsychoJS.Status.STARTED) {
    let theseKeys = psychoJS.eventManager.getKeys({keyList:['space', 'y', 'n', '1', '2', '3', '4', '5']});
    
    // check for quit:
    if (theseKeys.indexOf('escape') > -1) {
        psychoJS.experiment.experimentEnded = true;
    }
    if (theseKeys.length > 0) {  // at least one key was pressed
      key_resp_question_4.keys = theseKeys[theseKeys.length-1];  // just the last key pressed
      key_resp_question_4.rt = key_resp_question_4.clock.getTime();
      // a response ends the routine
      continueRoutine = false;
    }
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }
  
  continueRoutine = false;// reverts to True if at least one component still running
  for (const thisComponent of question4Components)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }
  
  // check for quit (the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // refresh the screen if continuing
  if (continueRoutine) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function question4RoutineEnd() {
  //------Ending Routine 'question4'-------
  for (const thisComponent of question4Components) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  
  
  // check responses
  if (['', [], undefined].indexOf(key_resp_question_4.keys) >= 0) {    // No response was made
      key_resp_question_4.keys = undefined;
  }
  
  psychoJS.experiment.addData('key_resp_question_4.keys', key_resp_question_4.keys);
  if (typeof key_resp_question_4.keys !== 'undefined') {  // we had a response
      psychoJS.experiment.addData('key_resp_question_4.rt', key_resp_question_4.rt);
      routineTimer.reset();
      }
  
  // the Routine "question4" was not non-slip safe, so reset the non-slip timer
  routineTimer.reset();
  
  return Scheduler.Event.NEXT;
}

var key_resp_ranking;
var rankingComponents;
function rankingRoutineBegin() {
  //------Prepare to start Routine 'ranking'-------
  t = 0;
  rankingClock.reset(); // clock
  frameN = -1;
  // update component parameters for each repeat
  
  profilePic1.setImage(picScrambler[0]);
  profilePic2.setImage(picScrambler[1]);
  profilePic3.setImage(picScrambler[2]);
  profilePic4.setImage(picScrambler[3]);
  profilePic5.setImage(picScrambler[4]);
  profileResume3.setText('resumeScrambler[2]');
  key_resp_ranking = new core.BuilderKeyResponse(psychoJS);
  // keep track of which components have finished
  rankingComponents = [];
  rankingComponents.push(profilePic1);
  rankingComponents.push(profilePic2);
  rankingComponents.push(profilePic3);
  rankingComponents.push(profilePic4);
  rankingComponents.push(profilePic5);
  rankingComponents.push(profileResume3);
  rankingComponents.push(key_resp_ranking);
  
  for (const thisComponent of rankingComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;
  
  return Scheduler.Event.NEXT;
}


function rankingRoutineEachFrame() {
  //------Loop for each frame of Routine 'ranking'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = rankingClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame
  
  
  // *profilePic1* updates
  if (t >= 0.0 && profilePic1.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    profilePic1.tStart = t;  // (not accounting for frame time here)
    profilePic1.frameNStart = frameN;  // exact frame index
    profilePic1.setAutoDraw(true);
  }

  
  // *profilePic2* updates
  if (t >= 0.0 && profilePic2.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    profilePic2.tStart = t;  // (not accounting for frame time here)
    profilePic2.frameNStart = frameN;  // exact frame index
    profilePic2.setAutoDraw(true);
  }

  
  // *profilePic3* updates
  if (t >= 0.0 && profilePic3.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    profilePic3.tStart = t;  // (not accounting for frame time here)
    profilePic3.frameNStart = frameN;  // exact frame index
    profilePic3.setAutoDraw(true);
  }

  
  // *profilePic4* updates
  if (t >= 0.0 && profilePic4.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    profilePic4.tStart = t;  // (not accounting for frame time here)
    profilePic4.frameNStart = frameN;  // exact frame index
    profilePic4.setAutoDraw(true);
  }

  
  // *profilePic5* updates
  if (t >= 0.0 && profilePic5.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    profilePic5.tStart = t;  // (not accounting for frame time here)
    profilePic5.frameNStart = frameN;  // exact frame index
    profilePic5.setAutoDraw(true);
  }

  
  // *profileResume3* updates
  if (t >= 0.0 && profileResume3.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    profileResume3.tStart = t;  // (not accounting for frame time here)
    profileResume3.frameNStart = frameN;  // exact frame index
    profileResume3.setAutoDraw(true);
  }

  
  // *key_resp_ranking* updates
  if (t >= 0.0 && key_resp_ranking.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    key_resp_ranking.tStart = t;  // (not accounting for frame time here)
    key_resp_ranking.frameNStart = frameN;  // exact frame index
    key_resp_ranking.status = PsychoJS.Status.STARTED;
    // keyboard checking is just starting
    psychoJS.window.callOnFlip(function() { key_resp_ranking.clock.reset(); }); // t = 0 on screen flip
    psychoJS.eventManager.clearEvents({eventType:'keyboard'});
  }

  if (key_resp_ranking.status === PsychoJS.Status.STARTED) {
    let theseKeys = psychoJS.eventManager.getKeys({keyList:['space']});
    
    // check for quit:
    if (theseKeys.indexOf('escape') > -1) {
        psychoJS.experiment.experimentEnded = true;
    }
    if (theseKeys.length > 0) {  // at least one key was pressed
      key_resp_ranking.keys = theseKeys[theseKeys.length-1];  // just the last key pressed
      key_resp_ranking.rt = key_resp_ranking.clock.getTime();
      // a response ends the routine
      continueRoutine = false;
    }
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }
  
  continueRoutine = false;// reverts to True if at least one component still running
  for (const thisComponent of rankingComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }
  
  // check for quit (the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // refresh the screen if continuing
  if (continueRoutine) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function rankingRoutineEnd() {
  //------Ending Routine 'ranking'-------
  for (const thisComponent of rankingComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  
  
  // check responses
  if (['', [], undefined].indexOf(key_resp_ranking.keys) >= 0) {    // No response was made
      key_resp_ranking.keys = undefined;
  }
  
  psychoJS.experiment.addData('key_resp_ranking.keys', key_resp_ranking.keys);
  if (typeof key_resp_ranking.keys !== 'undefined') {  // we had a response
      psychoJS.experiment.addData('key_resp_ranking.rt', key_resp_ranking.rt);
      routineTimer.reset();
      }
  
  // the Routine "ranking" was not non-slip safe, so reset the non-slip timer
  routineTimer.reset();
  
  return Scheduler.Event.NEXT;
}

var key_resp_4;
var GoodbyeComponents;
function GoodbyeRoutineBegin() {
  //------Prepare to start Routine 'Goodbye'-------
  t = 0;
  GoodbyeClock.reset(); // clock
  frameN = -1;
  // update component parameters for each repeat
  key_resp_4 = new core.BuilderKeyResponse(psychoJS);
  // keep track of which components have finished
  GoodbyeComponents = [];
  GoodbyeComponents.push(text_3);
  GoodbyeComponents.push(key_resp_4);
  
  for (const thisComponent of GoodbyeComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;
  
  return Scheduler.Event.NEXT;
}


function GoodbyeRoutineEachFrame() {
  //------Loop for each frame of Routine 'Goodbye'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = GoodbyeClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame
  
  // *text_3* updates
  if (t >= 0.0 && text_3.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    text_3.tStart = t;  // (not accounting for frame time here)
    text_3.frameNStart = frameN;  // exact frame index
    text_3.setAutoDraw(true);
  }

  
  // *key_resp_4* updates
  if (t >= 0.0 && key_resp_4.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    key_resp_4.tStart = t;  // (not accounting for frame time here)
    key_resp_4.frameNStart = frameN;  // exact frame index
    key_resp_4.status = PsychoJS.Status.STARTED;
    // keyboard checking is just starting
    psychoJS.window.callOnFlip(function() { key_resp_4.clock.reset(); }); // t = 0 on screen flip
    psychoJS.eventManager.clearEvents({eventType:'keyboard'});
  }

  if (key_resp_4.status === PsychoJS.Status.STARTED) {
    let theseKeys = psychoJS.eventManager.getKeys({keyList:['y', 'n', 'left', 'right', 'space']});
    
    // check for quit:
    if (theseKeys.indexOf('escape') > -1) {
        psychoJS.experiment.experimentEnded = true;
    }
    if (theseKeys.length > 0) {  // at least one key was pressed
      key_resp_4.keys = theseKeys[theseKeys.length-1];  // just the last key pressed
      key_resp_4.rt = key_resp_4.clock.getTime();
      // a response ends the routine
      continueRoutine = false;
    }
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }
  
  continueRoutine = false;// reverts to True if at least one component still running
  for (const thisComponent of GoodbyeComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }
  
  // check for quit (the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // refresh the screen if continuing
  if (continueRoutine) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function GoodbyeRoutineEnd() {
  //------Ending Routine 'Goodbye'-------
  for (const thisComponent of GoodbyeComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  
  // check responses
  if (['', [], undefined].indexOf(key_resp_4.keys) >= 0) {    // No response was made
      key_resp_4.keys = undefined;
  }
  
  psychoJS.experiment.addData('key_resp_4.keys', key_resp_4.keys);
  if (typeof key_resp_4.keys !== 'undefined') {  // we had a response
      psychoJS.experiment.addData('key_resp_4.rt', key_resp_4.rt);
      routineTimer.reset();
      }
  
  // the Routine "Goodbye" was not non-slip safe, so reset the non-slip timer
  routineTimer.reset();
  
  return Scheduler.Event.NEXT;
}


function endLoopIteration(thisTrial) {
  // ------Prepare for next entry------
  return function () {
    if (typeof thisTrial === 'undefined' || !('isTrials' in thisTrial) || thisTrial.isTrials) {
      psychoJS.experiment.nextEntry();
    }
  return Scheduler.Event.NEXT;
  };
}


function importConditions(loop) {
  const trialIndex = loop.getTrialIndex();
  return function () {
    loop.setTrialIndex(trialIndex);
    psychoJS.importAttributes(loop.getCurrentTrial());
    return Scheduler.Event.NEXT;
    };
}


function quitPsychoJS(message, isCompleted) {
  psychoJS.window.close();
  psychoJS.quit({message, isCompleted});

  return Scheduler.Event.QUIT;
}
