2016/01/23
the arrow and face png files in this folder are the most recent and are being used in p9e5 in psychopy and later

the old bmps for p9e1-p9e4 are stored in two folders:
/arrows_bmps
/face_bmps

the instructions for creating the .pngs for faces and arrows are in this folder
intermediate and test images were created and saved here for archive purposes
/arrow_old_pngs: the pngs were initially made b/c psychopy rejected the arrow .bmps; but these images weren't size right (720x540) so they were edited to create new pngs; the "_small_bg.png" files were created as an intermediate step for creating the official pngs being used, which were made by adding a white bg sign around the _small_bg.png files


/face_phatch_alpha: these .pngs were created using the batch photo program that changed black to alpha across the entire image...this creates pretty good images in psychopy, but when there's overlap of images, the overlap results in some kind of blend rather than one image appearing in front of the other