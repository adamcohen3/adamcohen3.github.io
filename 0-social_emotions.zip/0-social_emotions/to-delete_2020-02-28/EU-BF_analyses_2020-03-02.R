install.packages("hypergeo")

#--------------------------
#Main analyses
#--------------------------
#Study 1 (Pride)
josineBfs <- .bfCorrieRepJosine(nOri=25, rOri=0.853, nRep=25, rRep=0.903)
josineBfs$repGivenOri$bf10
#t1 rep BF = 117,936,305 (attached is the JASP file from the original emails for Study 1; see the last note with rep BF)
#t2 rep BF = 119,526,234

#Study 2 (Shame)
josineBfs <- .bfCorrieRepJosine(nOri=29, rOri=0.718, nRep=29, rRep=0.750)
josineBfs$repGivenOri$bf10
#rep BF = 45,517.66

#--------------------------
#Priming analyses
#--------------------------
#Study 1 (Pride)
josineBfs <- .bfCorrieRepJosine(nOri=25, rOri=0.853, nRep=25, rRep=0.805)
josineBfs$repGivenOri$bf10
#rep BF = 112,307.6

#Study 2 (Shame)
josineBfs <- .bfCorrieRepJosine(nOri=29, rOri=0.718, nRep=29, rRep=0.717)
josineBfs$repGivenOri$bf10
#t1 and t2 rep BF = 11,971.17