at STAGE 2, add back in OSF link to materials, data, and analyses
see other edits, and add back in as appropriate (abstract, etc.)