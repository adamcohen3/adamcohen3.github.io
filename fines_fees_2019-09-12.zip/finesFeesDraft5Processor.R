###############################################################
# function finesFeesProcessorv2
# created on 2019/08/19 by ASC
# last updated on 2019/08/26 by ASC
###############################################################
rm(list=ls())

library(dplyr)
library(readxl)
library(readr)
library(purrr)
library(ggplot2)
library(tidyr)
library(stringr)
library(reshape2)

#---------------------------------------------------
#read in first csv separately; only file with header
#---------------------------------------------------
ffPath <- "H:\\p3_fines_and_fees\\4_fines_fees_JIMS_IT-fiscal\\"
ffPaid1 <- read_csv(paste0(ffPath,"JPS-24019 - Draft 5a.csv"), col_names = TRUE)
ffPaid2 <- read_csv(paste0(ffPath,"JPS-24019 - Draft 5a.csv"), col_names = TRUE)
colnames(ffPaid2) <- colnames(ffPaid1)
ffPaid3 <- rbind(ffPaid1,ffPaid2)

#---------------------------------------------------
#add column for violation year, use to create table with year along row
#---------------------------------------------------
ffPaid3$Violation_Year <- as.numeric(format(as.Date(ffPaid3$VIOLATION_DATE,format = "%d-%b-%y"),'%Y'))

# #---------------------------------------------------
# #search for case with multiple payments from Draft 3
# #---------------------------------------------------
# case1859390MH <- ffPaid3 %>%
#   filter(CASE_D == "1859390MH")
# 
# #---------------------------------------------------
# #count # of cases per year
# #---------------------------------------------------
# ffPerYear <- ffPaid3 %>%
#   group_by(Year) %>%
#   summarize(n=n())
# 
# #---------------------------------------------------
# #count # of cases at collection per year
# #---------------------------------------------------
# ffPaidDraft5 <- ffPaid3
# ffStatus <- ffPaidDraft5 %>%
#   filter(BALANCE > 0) %>%
#   group_by(COLLECTION_STATUS) %>%
#   summarize(n=n())

#---------------------------------------------------
#Create MSB table
# rows = Year (2006:2018)
# columns = total # F&F cases; # outstanding; % of # outstanding; total $; $ outstanding; % of $ outstanding
# UNDER CONSTRUCTION - DUPLICATE ROWS -> TROUBLESHOOT
#---------------------------------------------------
msbTable <- ffPaid3 %>%
#group_by(CASE_D,PERSON_ID,ZIP_CODE,CHARGE_CODE, COLLECTION_STATUS,STOPPER_STATUS,Violation_Year) %>%
#summarize(FINE_AMT2 = mean(as.numeric(FINE_AMT)),BALANCE2 = mean(as.numeric(BALANCE)), FEE_ADJ2 = mean(as.numeric(FEE_ADJ))) %>%
  mutate_at(c("FINE_AMT","BALANCE"),as.numeric) %>%
  filter(COLLECTION_STATUS == "COLLECTION", Violation_Year > 2005) %>%
  group_by(Violation_Year) %>%
  summarize(totalN = n(), outstandingN = sum(BALANCE > 0), percentN = 100*outstandingN/totalN, 
            totalS = sum(FINE_AMT), outstandingS = sum(BALANCE), percentS = 100*outstandingS/totalS)

#---------------------------------------------------
#Compute aggregate stats (collapsing across Year) and bind to msbTable
#---------------------------------------------------
aggregateMSB <- c(NA,colSums(msbTable[2:3]),100*colSums(msbTable[3])/colSums(msbTable[2]),
                  colSums(msbTable[5:6]),100*colSums(msbTable[6])/colSums(msbTable[5]))
msbTable1 <- rbind(msbTable,aggregateMSB)

#---------------------------------------------------
#format $ and % in msbTable, add column names, and write
#---------------------------------------------------
msbTable2<-msbTable1
msbTable2[,c(5,6)] <- paste("$",formatC(unlist(msbTable1[,c(5,6)]), format = "f", digits = 2, big.mark = ","))
msbTable2[,c(4,7)] <- paste(formatC(unlist(msbTable1[,c(4,7)]), format = "f", digits = 2, big.mark = ","),"%")
msbTable2[nrow(msbTable2),1] <- "Total"
colnames(msbTable2) <- c("Year", "Number of people at MSB", "Number of people with outstanding fines and fees at MSB",
                         "Percent of people with outstanding fines and fees at MSB", "Total $ ordered sent to MSB",
                         "Total $ collected at MSB","Percent $ collected at MSB")

msbTablePath  <- paste0(ffPath,"2-msbTable_draft5",".csv")
i <- 1
while (file.exists(msbTablePath)){
  msbTablePath <- paste0(ffPath,"2-msbTable_draft5","_",i,".csv")
  i<-i+1
}
write_csv(msbTable2,msbTablePath)


#---------------------------------------------------
#Create Fines and Fees Bins - count active cases and # of license stoppers in each bin
# rows = Year (2006:2018)
# columns = bins, counts, # of license stoppers
#---------------------------------------------------

#---------------------------------------------------
#select only case with balances ("active" cases) collapse any duplicate rows
#---------------------------------------------------
ffPaid4 <- ffPaid3 %>%
  group_by(CASE_D,PERSON_ID,ZIP_CODE,CHARGE_CODE, COLLECTION_STATUS,STOPPER_STATUS,Violation_Year) %>%
  summarize(FINE_AMT2 = mean(as.numeric(FINE_AMT)),BALANCE2 = mean(as.numeric(BALANCE)), FEE_ADJ2 = mean(as.numeric(FEE_ADJ))) 

#---------------------------------------------------
#sum each person's fines and fees
#---------------------------------------------------
ffPaid5 <- ffPaid4 %>%
  group_by(PERSON_ID,STOPPER_STATUS) %>%
  summarize(FINE_AMT3 = sum(FINE_AMT2), BALANCE3 = sum(BALANCE2), FEE_ADJ3 = sum(FEE_ADJ2))

#---------------------------------------------------
#create bins
#---------------------------------------------------
ffBins<-ffPaid5
ffBins$category <- cut(ffPaid5$FINE_AMT3, 
                       breaks=c(-Inf, 5000, 10000, 15000, 20000, 25000, Inf), 
                       labels=c("under 5K","5K-10K","10K-15K","15K-20K","20K-25K","over 25K"))

#---------------------------------------------------
#count # of people in each bin and how many have license stoppers/restricted licenses in each bin
#---------------------------------------------------
tableFFBins <- ffBins %>%
  group_by(category,STOPPER_STATUS) %>%
  summarize(n = n()) %>%
#  replace_na(R,0) %>%
  spread(STOPPER_STATUS,n) %>%
  rename(no_label = "<NA>") %>%
  mutate(n = sum(C,S,R,no_label, na.rm = TRUE)) %>%
  select(-c(C,no_label))
tableFFBins <- tableFFBins[,c(1,4,2,3)]
tableFFBins[is.na(tableFFBins)] <- 0

tableFFBins2 <- as.data.frame(tableFFBins[,-1])
row.names(tableFFBins2) <- tableFFBins$category
tableFFBins2['Total',] <- colSums(tableFFBins2)
category <- row.names(tableFFBins2)
tableFFBins3 <- data.frame(category,tableFFBins2,row.names = NULL)
colnames(tableFFBins3) <- c("$ range","Total","restricted license","license/registration stoppers")

binTablePath  <- paste0(ffPath,"3-binAndStopperTable_draft5",".csv")
i <- 1
while (file.exists(binTablePath)){
  binTablePath <- paste0(ffPath,"3-binAndStopperTable_draft5","_",i,".csv")
  i<-i+1
}
write_csv(tableFFBins3,binTablePath)

# #---------------------------------------------------
# #count # of active cases (BALANCE3 > 0) in each bin and how many have license stoppers/restricted licenses in each bin
# #---------------------------------------------------
# tableFFBinsActive <- ffBins %>%
#   filter(BALANCE3 > 0) %>%
#   group_by(category,STOPPER_STATUS) %>%
#   summarize(n = n()) %>%
#   spread(STOPPER_STATUS,n) %>%
#   select(-c(C,"<NA>"))


