#run finesFeesProcessor_vs_sys76.R up to ff2, around the following lines, then run:
ff2w <- ff2 %>%
  subset(min(PARTY_PIDM) <= PARTY_PIDM & PARTY_PIDM <=1600000)

adjustmentCollapserFilter <- function(x){
  start.time3 <- Sys.time()
  y <- x %>%
    group_by(CASE_ID,PARTY_PIDM,DETC_CODE,CHARGE_NO,CHARGE_CODE, FINE_AMT) %>% 
    filter(BALANCE == min(BALANCE))
  end.time3 <- Sys.time()
  time.taken3 <- end.time3 - start.time3
  print(dim(x))
  print(time.taken3)
  return(y)
}
ff3wFilter <- adjustmentCollapserFilter(ff2w) #1.26911 mins

ff2w <- ff2 %>%
  subset(min(PARTY_PIDM) <= PARTY_PIDM & PARTY_PIDM <=1600000)
adjustmentCollapserSlice <- function(x){
  start.time3 <- Sys.time()
  y <- x %>%
    group_by(CASE_ID,PARTY_PIDM,DETC_CODE,CHARGE_NO,CHARGE_CODE, FINE_AMT) %>% 
    slice(which.min(BALANCE))
  
  end.time3 <- Sys.time()
  time.taken3 <- end.time3 - start.time3
  print(dim(x))
  print(time.taken3)
  return(y)
}
ff3wSlice <- adjustmentCollapserSlice(ff2w) #1.836434 mins

ff2w <- ff2 %>%
  subset(min(PARTY_PIDM) <= PARTY_PIDM & PARTY_PIDM <=1600000)
adjustmentCollapserSummarize <- function(x){
  start.time3 <- Sys.time()
  y <- x %>%
    group_by(CASE_ID,PARTY_PIDM,DETC_CODE,CHARGE_NO,CHARGE_CODE, FINE_AMT) %>% 
    summarize(minBALANCE = min(BALANCE), minADJUSTMENT = min(ADJUSTMENT), STOPPER_STATUS=first(STOPPER_STATUS),
              STOPPER_TYPE=first(STOPPER_TYPE),msbStatus=first(msbStatus),sanction_type=first(sanction_type),
              VIOLATION_DATE = first(VIOLATION_DATE),Year=first(Year),nCounter=n())
  end.time3 <- Sys.time()
  time.taken3 <- end.time3 - start.time3
  print(dim(x))
  print(time.taken3)
  return(y)
}
ff3wSummarize <- adjustmentCollapserSummarize(ff2w) #2.241243 mins

ff2w <- ff2 %>%
  subset(min(PARTY_PIDM) <= PARTY_PIDM & PARTY_PIDM <=1600000)
adjustmentCollapserTopN <- function(x){
  start.time3 <- Sys.time()
  y <- x %>%
    group_by(CASE_ID,PARTY_PIDM,DETC_CODE,CHARGE_NO,CHARGE_CODE, FINE_AMT) %>% 
    top_n(-1,BALANCE)
  
  end.time3 <- Sys.time()
  time.taken3 <- end.time3 - start.time3
  print(dim(x))
  print(time.taken3)
  return(y)
}
ff3wTopN <- adjustmentCollapserTopN(ff2w) # 2.767279 mins

dim(ff2w)[1]-dim(ff3wFilter)[1] 
dim(ff2w)[1]-dim(ff3wSlice)[1]
dim(ff2w)[1]-dim(ff3wSummarize)[1]
dim(ff2w)[1]-dim(ff3wTopN)[1]

#results:
#filter = 1.26911 mins
#slice = 1.836434 mins
#summarize = 2.241243 mins
#topN = 2.767279 mins

#***filter and topN includes ties whereas slice and summarize do not keep ties
#Slice is fastest and doesn't keep ties, which is what we want