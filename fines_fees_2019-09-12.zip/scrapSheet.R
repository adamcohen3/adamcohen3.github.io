save(ff8,file=paste0(ffPath,"ff8_df.Rda"))
load(paste0(ffPath,"ff8_df.Rda"))

tmpA<-ff8 %>%
  filter(PARTY_PIDM == "1661721")
#-------------------------------------------------------

full291E62<-ff8 %>%
  filter(grepl("HRS\\s291E-62",CHARGE_CODE2))
codefull291E62 <- unique(full291E62$CHARGE_CODE)

ff8291E62<-ff8 %>%
  filter(grepl("HRS\\s291E-62.*b",CHARGE_CODE3)) %>%
  count(CHARGE_CODE3)
code291E62 <- unique(ff8291E62$CHARGE_CODE)

tmpA <-data.frame(ff8$CHARGE_CODE2[grepl("291E-62.*\\(a.*[^bc]|291E-62$",ff8$CHARGE_CODE2)])
unique(tmpA)
tmpA1 <-data.frame(ff8$CHARGE_CODE3[grepl("291E-62.*\\([bc].*3",ff8$CHARGE_CODE2)])

tmpB <-data.frame(ff8$CHARGE_CODE2[grepl("291E-62.*\\(b.*3",ff8$CHARGE_CODE2)])
tmpC <-data.frame(ff8$CHARGE_CODE2[grepl("291E-62.*\\(c.*3",ff8$CHARGE_CODE2)])
