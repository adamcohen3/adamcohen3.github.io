ff1a <- read_csv(paste0(ffPath,"JPS-23984_1a.csv"), col_names = TRUE)
colNameTMP <- colnames(ff1a)
ff1b <- read_csv(paste0(ffPath,"JPS-23984_1b.csv"), col_names = colNameTMP)
ff1c <- read_csv(paste0(ffPath,"JPS-23984_1c.csv"), col_names = colNameTMP)
ff1d <- read_csv(paste0(ffPath,"JPS-23984_1d.csv"), col_names = colNameTMP)
ff1e <- read_csv(paste0(ffPath,"JPS-23984_1e.csv"), col_names = colNameTMP)

ffFile1 <- rbind.data.frame(ff1a,
                            ff1b,
                            ff1c,
                            ff1d,
                            ff1e)
remove(ff1a,
       ff1b,
       ff1c,
       ff1d,
       ff1e)

ffFile1$PAYMENT_DATE <- as.Date(ffFile1$PAYMENT_DATE,format = "%d-%b-%y")
ffFile1$Year <- as.numeric(format(ffFile1$PAYMENT_DATE,'%Y'))
#ffFile1 <- filter(ffFile1,Year >=2010)
#---------------------------------------------------
#create two new columns by splitting CHARGE_CODE into law code and section of code
#---------------------------------------------------
ffFile1 <- ffFile1 %>%
  separate(CHRG_CODE, c("code","section"), sep = " ", remove = FALSE, extra = "merge")
#remove(ff,ff1)
#---------------------------------------------------
#filter out all charge codes besides HRS and HAR, and filter out restitution and bail cash forfeiture
#---------------------------------------------------
ffFile1 <- ffFile1 %>%
  filter(grepl("HRS",code) | grepl("HAR",code)) %>%
  filter(!grepl("REST",DETC_CODE), !grepl("\\*RES",DETC_CODE), !grepl("BCF",DETC_CODE))


#partyID_case_file1 <- unique(ffFile1[c("CBRATRN_CASE_ID","PARTY_PIDM")])
partyID_case_ff2 <- unique(ff2[c("CASE_ID","PARTY_PIDM")])

ffFile1tmp <- ffFile1
colnames(ffFile1tmp)[1] <- "CASE_ID"
commonID4 <- anti_join(ffFile1tmp,partyID_case_ff2, by = c("CASE_ID", "PARTY_PIDM"))
unique_missing_partyID_case_file1 <- unique(commonID4[c("CASE_ID","PARTY_PIDM")])

write_csv(commonID4,paste0(ffPath,"missingCases.csv"))