###############################################################
# function finesFeesHB903Processor_v1_sys76
# created new version of v2 b/c JUD machine not powerful enough to handle processing -> this one customized to sys76
# created v1 on 2019/09/07 by ASC
# last updated on 2019/09/12 by ASC
###############################################################
rm(list=ls())

library(dplyr)
library(readxl)
library(readr)
library(purrr)
library(ggplot2)
library(tidyr)
library(stringr)
library(reshape2)

start.time1 <- Sys.time()
#---------------------------------------------------
#Set path
#---------------------------------------------------
ffPath <- "/home/adam/Desktop/fines_fees/"

#---------------------------------------------------
#read in sheets separately; only first sheet has header; skip first row in subsequent sheets
#row bind non-first csv into one df, add colnames from first csv to non-first concatenated DF, then row bind first with the rest
#---------------------------------------------------
ff1a <- read_csv(paste0(ffPath,"JPS-23984_1a.csv"), col_names = TRUE)
colNameTMP <- colnames(ff1a)
# ff1b <- read_csv(paste0(ffPath,"JPS-23984_1b.csv"), col_names = colNameTMP)
# ff1c <- read_csv(paste0(ffPath,"JPS-23984_1c.csv"), col_names = colNameTMP)
# ff1d <- read_csv(paste0(ffPath,"JPS-23984_1d.csv"), col_names = colNameTMP)
ff1e <- read_csv(paste0(ffPath,"JPS-23984_1e.csv"), col_names = colNameTMP)

ffMSBPartA <- rbind.data.frame(ff1a,
                               # ff1b,
                               # ff1c,
                               # ff1d,
                               ff1e)
remove(ff1a,
       # ff1b,
       # ff1c,
       # ff1d,
       ff1e)
ffMSBPartA$msbStatus <- "yes"

ff2a <- read_csv(paste0(ffPath,"JPS-23984_2a.csv"), col_names = TRUE)
colNameTMP <- colnames(ff2a)
# ff2b <- read_csv(paste0(ffPath,"JPS-23984_2b.csv"), col_names = colNameTMP)
# ff2c <- read_csv(paste0(ffPath,"JPS-23984_2c.csv"), col_names = colNameTMP)
# ff2d <- read_csv(paste0(ffPath,"JPS-23984_2d.csv"), col_names = colNameTMP)
ff2e <- read_csv(paste0(ffPath,"JPS-23984_2e.csv"), col_names = colNameTMP)

ffMSBPartB <- rbind.data.frame(ff2a,
                            # ff2b,
                            # ff2c,
                            # ff2d,
                            ff2e)
remove(ff2a,
       # ff2b,
       # ff2c,
       # ff2d,
       ff2e)
ffMSBPartB$msbStatus <- "yes"

#---------------------------------------------------
#Bind 2 MSB blocks of data 
#---------------------------------------------------
ffMSBPartA <- ffMSBPartA %>%
  rename(CASE_ID = CBRATRN_CASE_ID)
ffMSB <- rbind(ffMSBPartA,ffMSBPartB)

#---------------------------------------------------
#check for duplicates, write to disk
#---------------------------------------------------
start.timeDup <- Sys.time()
#2,371,409 with first dup removed; 1,291,439 unique, so total should = 3,662,848
#doesn't work -> dup1aAll<-ffMSBPartA %in% ffMSBPartA[duplicated(ffMSBPartA),] 
dup1a<-ffMSBPartA[duplicated(ffMSBPartA),]
dup1aUnique<-unique(dup1a)
dup1aTotalFile1 <- rbind(dup1a,dup1a1aUnique)
end.timeDup <- Sys.time()
time.takenDup <- end.timeDup - start.timeDup
time.takenDup

start.timeDup <- Sys.time()
dup1b<-ffMSBPartB[duplicated(ffMSBPartB),]
dup1bUnique<-unique(dup1b)
end.timeDup <- Sys.time()
time.takenDup <- end.timeDup - start.timeDup
time.takenDup

#---------------------------------------------------
#reformat date columns; create a column for year; b/c dataset large and by Judge Lee's request, filter for 2010-2019 and use later to split by year
#---------------------------------------------------
ffMSB$VIOLATION_DATE <- as.Date(ffMSB$VIOLATION_DATE,format = "%d-%b-%y")
ffMSB$Year <- as.numeric(format(ffMSB$VIOLATION_DATE,'%Y'))
ffMSB1 <- filter(ffMSB, Year >= 2005)

#---------------------------------------------------
#create two new columns by splitting CHARGE_CODE into law code and section of code
#---------------------------------------------------
ffMSB2 <- ffMSB1 %>%
  separate(CHARGE_CODE, c("code","section"), sep = " ", remove = FALSE, extra = "merge")
#remove(ff,ff1)
#---------------------------------------------------
#filter out all charge codes besides HRS and HAR, and filter out restitution and bail cash forfeiture
#filter out 291E-61 and 291E-62 (2019/09/03, per meeting with Judge Lee)
#---------------------------------------------------
ffMSB3 <- ffMSB2 %>%
  filter(grepl("HRS",code) | grepl("HAR",code)) %>%
  filter(!grepl("REST",DETC_CODE), !grepl("\\*RES",DETC_CODE), !grepl("BCF",DETC_CODE)) #%>%
  #filter(!grepl("291E-61",CHARGE_CODE),!grepl("291E-62",CHARGE_CODE))

#---------------------------------------------------
#Create sanction_type column and categorize DETC_CODE as fine or fee
#if DETC_CODE begins with "F" and it does not begin with "FEES" label as "fine", otherwise label as "fee"
#---------------------------------------------------
#sort(unique(ff2$DETC_CODE)) #view all unique DETC_CODES
ffMSB3$sanction_type <- ifelse(grepl("^F",ffMSB3$DETC_CODE) & !grepl("^FEES",ffMSB3$DETC_CODE),"fine","fee")
#check codes sorted correctly
# tmpFine<-ff2 %>%
#   filter(sanction_type=="fine") %>%
#   distinct(DETC_CODE) %>%
#   arrange(DETC_CODE)
# 
# tmpFee<-ff2 %>%
#   filter(sanction_type=="fee") %>%
#   distinct(DETC_CODE) %>%
#   arrange(DETC_CODE)

end.time1 <- Sys.time()
time.taken1 <- end.time1 - start.time1
time.taken1 # 1.99 min for ff = 26 mil rows, ff1 = 17.4 mil rows, and ff2 = 12.8 mil rows

dimsff <- dim(ffMSB) #full data set
dimsff1 <- dim(ffMSB1) #filter out Year >= 2010
dimsff2 <- dim(ffMSB2) #filter by charge code and fine/fee code

remove(ffMSB,ffMSB1,ffMSB2,ffMSBPartA,ffMSBPartB)
#---------------------------------------------------
#Create MSB table
# rows = Year (2005:2019)
# columns = total # F&F cases; # outstanding; % of # outstanding; total $; $ outstanding; % of $ outstanding
# UNDER CONSTRUCTION - DUPLICATE ROWS -> TROUBLESHOOT
#---------------------------------------------------
msbTable <- ff8 %>%
  #group_by(CASE_D,PERSON_ID,ZIP_CODE,CHARGE_CODE, COLLECTION_STATUS,STOPPER_STATUS,Violation_Year) %>%
  #summarize(FINE_AMT2 = mean(as.numeric(FINE_AMT)),BALANCE2 = mean(as.numeric(BALANCE)), FEE_ADJ2 = mean(as.numeric(FEE_ADJ))) %>%
  mutate_at(c("ffTotalAmt","Balance"),as.numeric) %>%
  filter(msbStatus == "yes", Year >= 2005) %>%
  group_by(Year) %>%
  summarize(totalN = n(), outstandingN = sum(Balance > 0), percentOutstandingN = 100*outstandingN/totalN, 
            totalS = sum(ffTotalAmt), outstandingS = sum(Balance), percentOutstandingS = 100*outstandingS/totalS)

#---------------------------------------------------
#Compute aggregate stats (collapsing across Year) and bind to msbTable
#---------------------------------------------------
aggregateMSB <- c(NA,colSums(msbTable[2:3]),100*colSums(msbTable[3])/colSums(msbTable[2]),
                  colSums(msbTable[5:6]),100*colSums(msbTable[6])/colSums(msbTable[5]))
msbTable1 <- rbind(msbTable,aggregateMSB)

#---------------------------------------------------
#format $ and % in msbTable, add column names, and write
#---------------------------------------------------
msbTable2<-msbTable1
msbTable2[,c(2,3)] <- formatC(unlist(msbTable1[,c(2,3)]), format = "d", big.mark = ",")
msbTable2[,c(5,6)] <- paste("$",formatC(unlist(msbTable1[,c(5,6)]), format = "f", digits = 2, big.mark = ","))
msbTable2[,c(4,7)] <- paste(formatC(unlist(msbTable1[,c(4,7)]), format = "f", digits = 2, big.mark = ","),"%")
msbTable2[nrow(msbTable2),1] <- "Total"
colnames(msbTable2) <- c("Year", "Number of cases at MSB", "Number of cases with outstanding fines and fees at MSB",
                         "Percent of cases with outstanding fines and fees at MSB", "Total $ ordered sent to MSB",
                         "Total $ uncollected at MSB","Percent $ uncollected at MSB")

msbTablePath  <- paste0(ffPath,"2-msbTable_draft5",".csv")
i <- 1
while (file.exists(msbTablePath)){
  msbTablePath <- paste0(ffPath,"2-msbTable_draft5","_",i,".csv")
  i<-i+1
}
write_csv(msbTable2,msbTablePath)

