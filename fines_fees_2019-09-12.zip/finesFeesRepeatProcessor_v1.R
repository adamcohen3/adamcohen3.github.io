###############################################################
# function finesFeesRepeatProcessor_v1_sys76
# created v1 on 2019/09/10 by ASC
# last updated on 2019/09/10 by ASC
###############################################################
rm(list=ls())

library(dplyr)
library(readxl)
library(readr)
library(purrr)
library(ggplot2)
library(tidyr)
library(stringr)
library(reshape2)

start.time1 <- Sys.time()
#---------------------------------------------------
#Set path
#---------------------------------------------------
ffPath <- "/home/adam/Desktop/fines_fees/"

#---------------------------------------------------
#read in sheets separately; only first sheet has header; skip first row in subsequent sheets
#row bind non-first csv into one df, add colnames from first csv to non-first concatenated DF, then row bind first with the rest
#---------------------------------------------------
ff1a <- read_csv(paste0(ffPath,"JPS-23984_1a.csv"), col_names = TRUE)
colNameTMP <- colnames(ff1a)
ff1b <- read_csv(paste0(ffPath,"JPS-23984_1b.csv"), col_names = colNameTMP)
ff1c <- read_csv(paste0(ffPath,"JPS-23984_1c.csv"), col_names = colNameTMP)
ff1d <- read_csv(paste0(ffPath,"JPS-23984_1d.csv"), col_names = colNameTMP)
ff1e <- read_csv(paste0(ffPath,"JPS-23984_1e.csv"), col_names = colNameTMP)

ffMSBPartA <- rbind.data.frame(ff1a,
                               ff1b,
                               ff1c,
                               ff1d,
                               ff1e)
remove(ff1a,
       ff1b,
       ff1c,
       ff1d,
       ff1e)
ffMSBPartA$msbStatus <- "yes"

# ff2a <- read_csv(paste0(ffPath,"JPS-23984_2a.csv"), col_names = TRUE)
# colNameTMP <- colnames(ff2a)
# ff2b <- read_csv(paste0(ffPath,"JPS-23984_2b.csv"), col_names = colNameTMP)
# ff2c <- read_csv(paste0(ffPath,"JPS-23984_2c.csv"), col_names = colNameTMP)
# ff2d <- read_csv(paste0(ffPath,"JPS-23984_2d.csv"), col_names = colNameTMP)
# ff2e <- read_csv(paste0(ffPath,"JPS-23984_2e.csv"), col_names = colNameTMP)
# 
# ffMSBPartB <- rbind.data.frame(ff2a,
#                                ff2b,
#                                ff2c,
#                                ff2d,
#                                ff2e)
# remove(ff2a,
#        ff2b,
#        ff2c,
#        ff2d,
#        ff2e)
# ffMSBPartB$msbStatus <- "yes"

# ffMSBPartA <- ffMSBPartA %>%
#   rename(CASE_ID = CBRATRN_CASE_ID)
# #---------------------------------------------------
# #Bind 2 MSB blocks of data 
# #---------------------------------------------------
# ffMSB <- rbind(ffMSBPartA,ffMSBPartB)

#---------------------------------------------------
#check for duplicates, write to disk
#---------------------------------------------------
start.timeDup <- Sys.time()
#2,371,409 with first dup removed; 1,291,439 unique, so total should = 3,662,848
#doesn't work -> dup1aAll<-ffMSBPartA %in% ffMSBPartA[duplicated(ffMSBPartA),] 
dup1a<-ffMSBPartA[duplicated(ffMSBPartA),]
dup1aUnique<-unique(dup1a)
dup1aTotalFile1 <- rbind(dup1a,dup1aUnique)
end.timeDup <- Sys.time()
time.takenDup <- end.timeDup - start.timeDup
time.takenDup
write_csv(dup1aTotalFile1,paste0(ffPath,"repeats_file1.csv"))

#file 1
tmpA <- ffMSBPartA %>%
  filter(CBRATRN_CASE_ID == "1DTI-06-167879", grepl("291C",CHRG_CODE), DETC_CODE == "F105")
tmpA2 <- ffMSBPartA %>%
  filter(CBRATRN_CASE_ID == "2DTI-06-004511", grepl("249",CHRG_CODE), DETC_CODE == "F040")
tmpA3 <- ffMSBPartA %>%
  filter(CBRATRN_CASE_ID == "3DTI-06-056761", grepl("291-31",CHRG_CODE), DETC_CODE == "AFCE")
tmpB <- ffMSBPartA %>%
  filter(CBRATRN_CASE_ID == "5DTI-11-006303")

ffMSBPartAtmp <- ffMSBPartA %>%
  filter(CHRG_NO > 5)

#file 2/3?
tmpA4  <- ff2 %>%
  filter(CASE_ID == "3DTI-06-000652", grepl("286-116",CHARGE_CODE), DETC_CODE == "AFM")
#file 2/3
tmpA5  <- ff2 %>%
  filter(CASE_ID == "1DTI-14-141266", grepl("291C-102",CHARGE_CODE), DETC_CODE == "DOT4")
#file 2/3
tmpA6  <- ff2 %>%
  filter(CASE_ID == "1DTI-14-161046", grepl("291C-102",CHARGE_CODE), DETC_CODE == "DOT4")
tmpA7  <- ff2 %>%
  filter(CASE_ID == "2DTI-10-011122", grepl("249-2",CHARGE_CODE), DETC_CODE == "F040")

start.timeDup <- Sys.time()
#2,371,409 with first dup removed; 1,291,439 unique, so total should = 3,662,848
#doesn't work -> dup1aAll<-ffMSBPartA %in% ffMSBPartA[duplicated(ffMSBPartA),] 
dup1b<-ffMSBPartB[duplicated(ffMSBPartB),]
dup1bUnique<-unique(dup1b)
dup1bTotalFile2 <- rbind(dup1b,dup1bUnique)
end.timeDup <- Sys.time()
time.takenDup <- end.timeDup - start.timeDup
time.takenDup
write_csv(dupTotal,"/home/adam/Desktop/fines_fees/repeats_file2.csv")