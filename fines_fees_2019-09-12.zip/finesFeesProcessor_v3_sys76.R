###############################################################
# function finesFeesProcessor_v2_sys76
# created new version of v2 b/c JUD machine not powerful enough to handle processing -> this one customized to sys76
# created v1 on 2019/08/28 by ASC
# created v2 on 2019/08/28 by ASC
# last updated on 2019/09/12 by ASC
###############################################################
rm(list=ls())

library(dplyr)
library(readxl)
library(readr)
library(purrr)
library(ggplot2)
library(tidyr)
library(stringr)
library(reshape2)

start.time1 <- Sys.time()
#---------------------------------------------------
#Set path
#---------------------------------------------------
ffPath <- "/home/adam/Desktop/fines_fees/"

#---------------------------------------------------
#read in sheets separately; only first sheet has header; skip first row in subsequent sheets
#row bind non-first csv into one df, add colnames from first csv to non-first concatenated DF, then row bind first with the rest
#---------------------------------------------------
ff2a <- read_csv(paste0(ffPath,"JPS-23984_2a.csv"), col_names = TRUE)
colNameTMP <- colnames(ff2a)
ff2b <- read_csv(paste0(ffPath,"JPS-23984_2b.csv"), col_names = colNameTMP)
ff2c <- read_csv(paste0(ffPath,"JPS-23984_2c.csv"), col_names = colNameTMP)
ff2d <- read_csv(paste0(ffPath,"JPS-23984_2d.csv"), col_names = colNameTMP)
ff2e <- read_csv(paste0(ffPath,"JPS-23984_2e.csv"), col_names = colNameTMP)

ffPartA <- rbind.data.frame(ff2a,
                            ff2b,
                            ff2c,
                            ff2d,
                            ff2e)
remove(ff2a,
       ff2b,
       ff2c,
       ff2d,
       ff2e)

#---------------------------------------------------
#Block 2
#---------------------------------------------------
#start.time1 <- Sys.time()
ff3a <- read_csv(paste0(ffPath,"JPS-23984_3a.csv"), col_names = TRUE)
# ff3b <- read_csv(paste0(ffPath,"JPS-23984_3b.csv"), col_names = colNameTMP)
# ff3c <- read_csv(paste0(ffPath,"JPS-23984_3c.csv"), col_names = colNameTMP)
# ff3d <- read_csv(paste0(ffPath,"JPS-23984_3d.csv"), col_names = colNameTMP)
# ff3e <- read_csv(paste0(ffPath,"JPS-23984_3e.csv"), col_names = colNameTMP)
# ff3f <- read_csv(paste0(ffPath,"JPS-23984_3f.csv"), col_names = colNameTMP)
# ff3g <- read_csv(paste0(ffPath,"JPS-23984_3g.csv"), col_names = colNameTMP)
# ff3h <- read_csv(paste0(ffPath,"JPS-23984_3h.csv"), col_names = colNameTMP)
# ff3i <- read_csv(paste0(ffPath,"JPS-23984_3i.csv"), col_names = colNameTMP)
# ff3j <- read_csv(paste0(ffPath,"JPS-23984_3j.csv"), col_names = colNameTMP)
# ff3k <- read_csv(paste0(ffPath,"JPS-23984_3k.csv"), col_names = colNameTMP)
ff3l <- read_csv(paste0(ffPath,"JPS-23984_3l.csv"), col_names = colNameTMP)

ffPartB <- rbind.data.frame(ff3a,
                            # ff3b,
                            # ff3c,
                            # ff3d,
                            # ff3e,
                            # ff3f,
                            # ff3g,
                            # ff3h,
                            # ff3i,
                            # ff3j,
                            # ff3k,
                            ff3l)
remove(ff3a,
       # ff3b,
       # ff3c,
       # ff3d,
       # ff3e,
       # ff3f,
       # ff3g,
       # ff3h,
       # ff3i,
       # ff3j,
       # ff3k,
       ff3l)

#---------------------------------------------------
#Block 3
#---------------------------------------------------
#start.time1 <- Sys.time()
ff3m <- read_csv(paste0(ffPath,"JPS-23984_3m.csv"), col_names = colNameTMP)
# ff3n <- read_csv(paste0(ffPath,"JPS-23984_3n.csv"), col_names = colNameTMP)
# ff3o <- read_csv(paste0(ffPath,"JPS-23984_3o.csv"), col_names = colNameTMP)
# ff3p <- read_csv(paste0(ffPath,"JPS-23984_3p.csv"), col_names = colNameTMP)
# ff3q <- read_csv(paste0(ffPath,"JPS-23984_3q.csv"), col_names = colNameTMP)
# ff3r <- read_csv(paste0(ffPath,"JPS-23984_3r.csv"), col_names = colNameTMP)
# ff3s <- read_csv(paste0(ffPath,"JPS-23984_3s.csv"), col_names = colNameTMP)
# ff3t <- read_csv(paste0(ffPath,"JPS-23984_3t.csv"), col_names = colNameTMP)
ff3u <- read_csv(paste0(ffPath,"JPS-23984_3u.csv"), col_names = colNameTMP)

ffPartC <- rbind.data.frame(ff3m,
                            # ff3n,
                            # ff3o,
                            # ff3p,
                            # ff3q,
                            # ff3r,
                            # ff3s,
                            # ff3t,
                            ff3u)
remove(ff3m,
       # ff3n,
       # ff3o,
       # ff3p,
       # ff3q,
       # ff3r,
       # ff3s,
       # ff3t,
       ff3u)

#---------------------------------------------------
#Bind 3 blocks of data -> leaving in 3 block approach above in case processing too demanding later, can analyze by block instead
#---------------------------------------------------
ff <- rbind(ffPartA,ffPartB,ffPartC)

#---------------------------------------------------
#sanity check max amount of fine and fee
#---------------------------------------------------
# maxff2<- ff %>%
#   top_n(50,FINE_AMT) %>%
#   arrange(desc(FINE_AMT))

#---------------------------------------------------
#QUALITY ASSURANCE CHECK: check for duplicates, write to disk
#---------------------------------------------------
# start.timeDup <- Sys.time()
# dup1a<-ff[duplicated(ff),]
# dup1aUnique<-unique(dup1a)
# end.timeDup <- Sys.time()
# time.takenDup <- end.timeDup - start.timeDup
# time.takenDup
# 
# write_csv(dup1aUnique,paste0(ffPath,"JPS-23984_duplicates.csv"))

#---------------------------------------------------
#reformat date columns; create a column for year; b/c dataset large and by Judge Lee's request, filter for 2010-2019 and use later to split by year
#---------------------------------------------------
ff$VIOLATION_DATE <- as.Date(ff$VIOLATION_DATE,format = "%d-%b-%y")
ff1 <- filter(ff, as.numeric(format(ff$VIOLATION_DATE,'%Y')) >= 2010)

#---------------------------------------------------
#create two new columns by splitting CHARGE_CODE into law code and section of code
#---------------------------------------------------
ff2 <- ff1 %>%
  separate(CHARGE_CODE, c("code","section"), sep = " ", remove = FALSE, extra = "merge")
#remove(ff,ff1)
#---------------------------------------------------
#filter out all charge codes besides HRS and HAR, and filter out restitution and bail cash forfeiture
#filter out 291E-61 and 291E-62 (2019/09/03, per meeting with Judge Lee)
#---------------------------------------------------
ff2 <- ff2 %>%
  filter(grepl("HRS",code) | grepl("HAR",code)) %>%
  filter(!grepl("REST",DETC_CODE), !grepl("\\*RES",DETC_CODE), !grepl("BCF",DETC_CODE)) %>%
  select(-code,-section)
#---------------------------------------------------
#Create sanction_type column and categorize DETC_CODE as fine or fee
#if DETC_CODE begins with "F" and it does not begin with "FEES" label as "fine", otherwise label as "fee"
#---------------------------------------------------
#sort(unique(ff2$DETC_CODE)) #view all unique DETC_CODES
ff2$sanction_type <- ifelse(grepl("^F",ff2$DETC_CODE) & !grepl("^FEES",ff2$DETC_CODE),"fine","fee")
#check codes sorted correctly
# tmpFine<-ff2 %>%
#   filter(sanction_type=="fine") %>%
#   distinct(DETC_CODE) %>%
#   arrange(DETC_CODE)
# 
# tmpFee<-ff2 %>%
#   filter(sanction_type=="fee") %>%
#   distinct(DETC_CODE) %>%
#   arrange(DETC_CODE)

end.time1 <- Sys.time()
time.taken1 <- end.time1 - start.time1
time.taken1 # 1.99 min for ff = 26 mil rows, ff1 = 17.4 mil rows, and ff2 = 12.8 mil rows

dimsff <- dim(ff) #full data set
dimsff1 <- dim(ff1) #filter out Year >= 2010
dimsff2 <- dim(ff2) #filter by charge code and fine/fee code

remove(ff,ff1,ffPartA,ffPartB,ffPartC)
#---------------------------------------------------
#detect and collapse repeat rows grouped by CASE_ID,PARTY_PIDM,DETC_CODE,CHARGE_NO,CHARGE_CODE,FINE_AMT
#---------------------------------------------------
#GROUPING LOGIC - collapse repeat rows and rows where adj and balance vary but otherwise match -> take min ADJUSTMENT and min BALANCE
#group by CASE_ID b/c same PARTY_PIDM can have multiple cases
#group by PARTY_PIDM b/c same CASE_ID can have multiple PARTY_PIDMs
#group by DETC_CODE b/c charge code w/in a CASE_ID x PARTY_PIDM can have multiple fine and fee codes
#group by CHARGE_NO b/c charge code w/in a CASE_ID x PARTY_PIDM can have multiple counts
#group by CHARGE_CODE b/c same CASE_ID x PARTY_PIDM can have multiple charges
#group by FINE_AMT b/c charge code w/in a CASE_ID x PARTY_PIDM can have multiple FIN codes listed in different amounts when they're for separate/multiple fines
#Testing with subset of data suggested that STOPPER_TYPE/STATUS, VIOLATION_DATE, etc did not reduce row #, so no need to group_by or summarize
#COLLAPSING LOGIC (using filter, slice, summarize, or top_n)
#N.B. BALANCE can vary when there's an adjustment and both are listed as separate rows and when there are irregularities
#-> take the min BALANCE -> this is a rough heuristic that seems to work in most cases, either b/c of adjustment or b/c defendant has paid down balance, but it is not guaranteed to work -> need JIMS to troubleshoot why there are sometimes two rows w/different balances
#N.B. ADJUSTMENT can vary when there's an adjustment, whether or not the balance changes (e.g., if payment made before adjustment) 
#-> take the min ADJUSTMENT to get the adjustment for that particular fine/fee (summing ADJUSTMENT created negative min values, could be duplicates)
#N.B. keep record of replicates in nCounter = n() -> this could be due to collapsing across different STOPPER_STATUS, STOPPER_TYPE, Year, BALANCE, ADJUSTMENT
#investigate in the future
#THIS SCRIPT ASSUMES BALANCE IS A SUMMARY OF PAYMENTS IF THERE WERE MULTIPLE PAYMENTS; IT MAY NOT WORK IF THE DATA FILE CONTAINS MULTIPLE PAYMENTS (see finesFeesDraft3Processor.R for script that works with multiple payments)
#---------------------------------------------------
#BREAK INTO subsets b/c ff2 crashes machine

ff2w <- ff2 %>%
  subset(min(PARTY_PIDM) <= PARTY_PIDM & PARTY_PIDM <=1600000)
ff2x <- ff2 %>%
  subset(1600000 < PARTY_PIDM & PARTY_PIDM <=2080000)
ff2y <- ff2 %>%
  subset(2080000 < PARTY_PIDM & PARTY_PIDM <=3020000)
ff2z <- ff2 %>%
  subset(3020000 < PARTY_PIDM & PARTY_PIDM <=max(PARTY_PIDM))
remove(ff2)

# #STEP 1: QUALITY ASSURANCE CHECK - Detect rows that need to be collapsed: repeat rows or rows where adj and balance vary but otherwise match
# #add columns for # of repeats in each group and SD for ADJ and BAL
#       #if sdADJ = 0 and sdBAL = 0, select any 1 row from group, since rows are repeats/identical
#       #if sdADJ != 0 or sdBAL != 0, investigate -> take min for each since difference likely reflects downward adjustment
#       #general solution - take min
#
# repeatDetector <- function(x){
#   start.time3 <- Sys.time()
#   y <- x %>%
#     group_by(CASE_ID,PARTY_PIDM,DETC_CODE,CHARGE_NO,CHARGE_CODE, FINE_AMT) %>%
#     mutate(nCounter = n(), sdADJ = sd(ADJUSTMENT), sdBAL = sd(BALANCE))
#   end.time3 <- Sys.time()
#   time.taken3 <- end.time3 - start.time3
#   print(dim(x))
#   print(time.taken3)
#   return(y)
# }
# 
# ff3wRepeat <- repeatDetector(ff2w)
# # #singleton rows, don't need to be collapsed
# # ff3wSingleton <- filter(ff3w, nCounter == 1)
# #non-singletons, need to be collapsed
# # #rows that repeat but are identical and can be directly collapsed
# # ff3wCollapse <- filter(ff3wRepeat, nCounter > 1, sdADJ == 0, sdBAL == 0)
# #rows that repeat but are NOT identical at ADJ, BAL, or both and need to be carefully collapsed
# ff3wInvestigate <- filter(ff3wRepeat, nCounter > 1, sdADJ != 0 | sdBAL != 0)
# 
# ff3xRepeat <- repeatDetector(ff2x)
# ff3xInvestigate <- filter(ff3xRepeat, nCounter > 1, sdADJ != 0 | sdBAL != 0)
# 
# ff3yRepeat <- repeatDetector(ff2y)
# ff3yInvestigate <- filter(ff3yRepeat, nCounter > 1, sdADJ != 0 | sdBAL != 0)
# 
# ff3zRepeat <- repeatDetector(ff2z)
# ff3zInvestigate <- filter(ff3zRepeat, nCounter > 1, sdADJ != 0 | sdBAL != 0)

# ff3Repeats <- rbind(ff3wInvestigate,ff3xInvestigate,ff3yInvestigate,ff3zInvestigate)
# dimTotal <- dim(ff3x)[1]+dim(ff3y)[1]+dim(ff3z)[1]+dim(ff3w)[1]
# remove (ff3Repeats,ff3wRepeat,ff3wInvestigate,ff3xRepeat,ff3xInvestigate,ff3yRepeat,ff3yInvestigate,ff3zRepeat,ff3zInvestigate)

#STEP 2: COLLAPSE REPEATS - Collapse repeat rows and rows where adj and balance vary but otherwise match
repeatCollapser <- function(x){
  start.time3 <- Sys.time()
  y <- x %>%
    group_by(CASE_ID,PARTY_PIDM,DETC_CODE,CHARGE_NO,CHARGE_CODE, FINE_AMT) %>% 
    #tested filter vs slice vs summarize vs top_n; filter and slice fastest but only slice and summarize doesn't keep ties, which is what we want -> use slice
    #filter(BALANCE == min(BALANCE))
    mutate(nCounter = n()) %>% #MUST COME BEFORE SLICE TO COUNT REPEATS
    slice(which.min(BALANCE))
    # summarize(minBALANCE = min(BALANCE), minADJUSTMENT = min(ADJUSTMENT), STOPPER_STATUS=first(STOPPER_STATUS),
    #           STOPPER_TYPE=first(STOPPER_TYPE),sanction_type=first(sanction_type),
    #           VIOLATION_DATE = first(VIOLATION_DATE),nCounter=n())
    #top_n(-1,BALANCE)
  end.time3 <- Sys.time()
  time.taken3 <- end.time3 - start.time3
  print(dim(x))
  print(time.taken3)
  return(y)
}

ff3w <- repeatCollapser(ff2w)
remove(ff2w)
ff3x <- repeatCollapser(ff2x)
remove(ff2x)
ff3y <- repeatCollapser(ff2y)
remove(ff2y)
ff3z <- repeatCollapser(ff2z)
remove(ff2z)
#---------------------------------------------------
#Calculate % of rows with nCounter > 1 -> % of rows with same data except for BALANCE and ADJ 
#---------------------------------------------------
# repCounter <- function(x){
#   counter <- x %>% group_by(nCounter) %>% tally()
#   repRows <- nrow(x[x$nCounter > 1,])
#   totalRows <- nrow(x)
#   percentRepRows <-100*repRows/totalRows 
#   print(percentRepRows)
#   return(counter)
# }
# repCounter3w<- repCounter(ff3w)
# repCounter3x<- repCounter(ff3x)
# repCounter3y<- repCounter(ff3y)
# repCounter3z<- repCounter(ff3z)
# remove(repCounter3w,repCounter3x,repCounter3y,repCounter3z)
#---------------------------------------------------
#GROUPING LOGIC
#group by CASE_ID b/c same PARTY_PIDM can have multiple cases
#group by PARTY_PIDM b/c same CASE_ID can have multiple Ds
#group by CHARGE_NO b/c charge code w/in a CASE_ID x PARTY_PIDM can have multiple counts
#group by CHARGE_CODE b/c same CASE_ID x PARTY_PIDM can have multiple charges
#group by sanction_type to combine all fines together and all fees together
#SUMMARIZE LOGIC
#Do not group_by DETC_CODE, instead collpase all fine codes and all fee codes into single row (by sanction type = fine | fee), and
#use summarize to return sum amount ordered (FF_AMT_SUM), sum amount paid (PAID_AMT_SUM), and sum amount adjusted (ADJUSTMENT)
#---------------------------------------------------
fineFeeCollapser <- function(x){
  start.time4 <- Sys.time()
  y <- x %>%
    mutate(PAID_AMT = FINE_AMT-BALANCE+ADJUSTMENT) %>% #add to get PAID_AMT for fines and fees separately before aggregating
    group_by(CASE_ID,PARTY_PIDM,CHARGE_NO,CHARGE_CODE,sanction_type) %>%
    summarize(FF_AMT_SUM = sum(FINE_AMT),PAID_AMT_SUM = sum(PAID_AMT),ADJ_AMT_SUM = sum(ADJUSTMENT),
              STOPPER_STATUS=first(STOPPER_STATUS),STOPPER_TYPE=first(STOPPER_TYPE),VIOLATION_DATE = first(VIOLATION_DATE))
  end.time4 <- Sys.time()
  time.taken4 <- end.time4 - start.time4
  print(dim(x))
  print(time.taken4)
  return(y)
}

ff4w <- fineFeeCollapser(ff3w)
remove(ff3w)
ff4x <- fineFeeCollapser(ff3x)
remove(ff3x)
ff4y <- fineFeeCollapser(ff3y)
remove(ff3y)
ff4z <- fineFeeCollapser(ff3z)
remove(ff3z)

ff4 <- rbind(ff4w,ff4x,ff4y,ff4z)
remove(ff4w,ff4x,ff4y,ff4z)

#---------------------------------------------------
#reshape from long to wide, adding columns for fines and and sum of fees for that case x party
#---------------------------------------------------
start.time5 <- Sys.time()
ff5 <- ff4 %>%
  melt(id=c("CASE_ID","PARTY_PIDM","CHARGE_NO","CHARGE_CODE","sanction_type","STOPPER_STATUS","STOPPER_TYPE","VIOLATION_DATE"),
       variable.name = "status",value.name = "AMT_SUM")
ff6 <- ff5 %>%
  dcast(CASE_ID + PARTY_PIDM + CHARGE_NO + CHARGE_CODE + STOPPER_STATUS + STOPPER_TYPE + VIOLATION_DATE ~ sanction_type + status, value.var = "AMT_SUM")
ff7 <- ff6 %>%
  mutate(ffTotalAmt = replace_na(fine_FF_AMT_SUM,0) + replace_na(fee_FF_AMT_SUM,0),
         ffTotalAdj = replace_na(fine_ADJ_AMT_SUM,0) + replace_na(fee_ADJ_AMT_SUM,0),
         effTotalAmt = ffTotalAmt + ffTotalAdj, #effective total amount: removes adjusted from ordered amount
         ffTotalPaid = replace_na(fine_PAID_AMT_SUM,0) + replace_na(fee_PAID_AMT_SUM,0),
         Balance = effTotalAmt - ffTotalPaid)
end.time5 <- Sys.time()
time.taken5 <- end.time5 - start.time5
time.taken5 #sys76: 58 secs with 4.7 million rows x 12 var; 1.39 min with 6.2 mil rows x 12 var (Year >= 2010)

# #count how many F&F per year
ffPerYear <- ff7 %>%
  group_by(as.numeric(format(ff7$VIOLATION_DATE,'%Y'))) %>%
  summarize(n=n()) 

#---------------------------------------------------
#check for charge codes with * prefix; remove prefix
#create columns for sub-sections
#---------------------------------------------------
tmp2<-unique(ff7$CHARGE_CODE)
tmp2DF<-data.frame(tmp2)
tmp3<-tmp2[grepl("^\\*",tmp2)]

ff8<-ff7 %>% 
  mutate(CHARGE_CODE2 = str_replace(CHARGE_CODE,"\\*",""))

#---------------------------------------------------
#switch to turn on/off uncollapsing
#IF not collapsing on initial run, skip saving ff8 as ff8uncollapsed and skip binning charge codes
#IF collapsing, save ff8 as ff8uncollapsed and bin charge codes
#IF uncollapsing, assign ff8uncollapsed back to ff8 and skip binning charge codes
#---------------------------------------------------
ff8uncollapsed <- ff8
# ff8 <- ff8uncollapsed
#remove(ff5)
#---------------------------------------------------
#create abbreviated charge codes w/o subsections (Except for 291C-102 and 291C-105)
#---------------------------------------------------
ff8 <- ff8 %>%
  separate(CHARGE_CODE2, c("CHARGE_CODE3","subCodeExtra"), sep = "\\(", remove = FALSE, extra = "merge") %>%
  mutate(CHARGE_CODE3 = str_replace(CHARGE_CODE3,"HRS\\s249-11\\s\\[041405\\]","HRS 249-11")) %>%
  mutate(CHARGE_CODE3 = str_replace(CHARGE_CODE3,"HRS\\s286-102\\s\\[JUV\\]","HRS 286-102")) %>%
  mutate(CHARGE_CODE3 = str_replace(CHARGE_CODE3,"HRS\\s291C-197\\s\\[070108\\]","HRS 291C-197"))

#---------------------------------------------------
#bin HRS 291E-61 codes
#---------------------------------------------------
ff8$CHARGE_CODE3[grepl("291E-61.*\\(b.*4",ff8$CHARGE_CODE2)] <- "HRS 291E-61(b)(4)"
ff8$CHARGE_CODE3[grepl("291E-61.*\\(b.*3",ff8$CHARGE_CODE2)] <- "HRS 291E-61(b)(3)"
ff8$CHARGE_CODE3[grepl("291E-61.*\\(b.*2",ff8$CHARGE_CODE2)] <- "HRS 291E-61(b)(2)"
ff8$CHARGE_CODE3[grepl("291E-61.*\\(b.*1",ff8$CHARGE_CODE2)] <- "HRS 291E-61(b)(1)"
ff8$CHARGE_CODE3[grepl("291E-61.*\\(a|291E-61$|291E-61\\(b\\)$",ff8$CHARGE_CODE2)] <- "HRS 291E-61(b)(unknown)"

#---------------------------------------------------
#bin HRS 291E-62 codes - [bc] -> Act 40 (SLH 2015) changed the subsections from b to c
#---------------------------------------------------
ff8$CHARGE_CODE3[grepl("291E-62.*\\([bc].*3",ff8$CHARGE_CODE2)] <- "HRS 291E-62(b)(3)"
ff8$CHARGE_CODE3[grepl("291E-62.*\\([bc].*2",ff8$CHARGE_CODE2)] <- "HRS 291E-62(b)(2)"
ff8$CHARGE_CODE3[grepl("291E-62.*\\([bc].*1",ff8$CHARGE_CODE2)] <- "HRS 291E-62(b)(1)"
ff8$CHARGE_CODE3[grepl("291E-62.*\\(a.*[^bc]|291E-62$",ff8$CHARGE_CODE2)] <- "HRS 291E-62(b)(unknown)"

#---------------------------------------------------
#bin HRS 291C-102 codes
#---------------------------------------------------
ff8$CHARGE_CODE3[grepl("291C-102.*\\(a.[^2]*|291C-102$|291C-102\\(b|291C-102-CRT",ff8$CHARGE_CODE2)] <- "HRS 291C-102+unknown"
ff8$CHARGE_CODE3[grepl("291C-102.*\\+2[0-9]$",ff8$CHARGE_CODE2)] <- "HRS 291C-102+20-29MPH"
ff8$CHARGE_CODE3[grepl("291C-102.*\\+1[0-9]$",ff8$CHARGE_CODE2)] <- "HRS 291C-102+10-19MPH"
ff8$CHARGE_CODE3[grepl("291C-102.*\\+[0-9]$",ff8$CHARGE_CODE2)] <- "HRS 291C-102+01-09MPH"

#---------------------------------------------------
#bin HRS 291C-105 codes
#---------------------------------------------------
ff8$CHARGE_CODE3[grepl("291C-105.*[^c]*|291C-105$",ff8$CHARGE_CODE2)] <- "HRS 291C-105(c)(unknown)"
ff8$CHARGE_CODE3[grepl("291C-105.*\\(c.*3",ff8$CHARGE_CODE2)] <- "HRS 291C-105(c)(3)"
ff8$CHARGE_CODE3[grepl("291C-105.*\\(c.*2",ff8$CHARGE_CODE2)] <- "HRS 291C-105(c)(2)"
ff8$CHARGE_CODE3[grepl("291C-105.*\\(c.*1",ff8$CHARGE_CODE2)] <- "HRS 291C-105(c)(1)"

#---------------------------------------------------
#bin HRS 431:10C-104 codes
#---------------------------------------------------
ff8$CHARGE_CODE3[grepl("431:10C-104",ff8$CHARGE_CODE2)] <- "HRS 431:10C-104"

#---------------------------------------------------
#Summarize (n, mean, sd, min, max) by charge code, arrange by mean, filter for n > 150
#---------------------------------------------------
# ff9 <- ff8 %>% group_by(CHARGE_CODE3) %>% summarize(n=n(), mean = mean(ffTotalAmt, rm.na = TRUE), sd = sd(ffTotalAmt), 
#                                                     min = min(ffTotalAmt),max = max(ffTotalAmt)) %>%
#   arrange(desc(mean)) %>%
#   mutate(ranking = 1:nrow(.))
# 
# ff9eff <- ff8 %>% group_by(CHARGE_CODE3) %>% summarize(n=n(), mean = mean(effTotalAmt, rm.na = TRUE), sd = sd(effTotalAmt), 
#                                                        min = min(effTotalAmt),max = max(effTotalAmt)) %>%
#   arrange(desc(mean)) %>%
#   mutate(ranking = 1:nrow(.))
# 
# ff9paid <- ff8 %>% group_by(CHARGE_CODE3) %>% summarize(n=n(), mean = mean(ffTotalPaid, rm.na = TRUE), sd = sd(ffTotalPaid), 
#                                                         min = min(ffTotalPaid),max = max(ffTotalPaid))%>%
#   arrange(desc(mean)) %>%
#   mutate(ranking = 1:nrow(.))

ff9total <- ff8 %>% group_by(CHARGE_CODE3) %>% summarize(n=n(), mean = mean(ffTotalAmt, rm.na = TRUE), sd = sd(ffTotalAmt), 
                                                    min = min(ffTotalAmt),max = max(ffTotalAmt),
                                                    effmean = mean(effTotalAmt, rm.na = TRUE), effsd = sd(effTotalAmt), 
                                                    effmin = min(effTotalAmt),effmax = max(effTotalAmt),
                                                    paidmean = mean(ffTotalPaid, rm.na = TRUE), paidsd = sd(ffTotalPaid), 
                                                    paidmin = min(ffTotalPaid),paidmax = max(ffTotalPaid),
                                                    VIOLATION_DATE = first(VIOLATION_DATE)) %>%
  arrange(desc(mean)) %>%
  mutate(rankMean = 1:nrow(.), rankEffMean = row_number(-effmean), rankPaidMean = row_number(-paidmean))

#---------------------------------------------------
#Run code to generate fine/fee default amounts and descriptions (see end of script)
#---------------------------------------------------

#---------------------------------------------------
#attach defaults and descriptions to ff9Total
#---------------------------------------------------
defaultFF7 <- defaultFF6 %>%
  select(Ver.ID,Charge.Code,Description,fee,fine,ffTotal) 
defaultFF7 <- defaultFF7[!duplicated(defaultFF7$Charge.Code),]
ff9merge <- left_join(ff9total,defaultFF7, by = c("CHARGE_CODE3"="Charge.Code"))
ff9merge2 <- ff9merge %>%
  rename(default.fines.only = "fine", default.fees.only = "fee", default.fines.fees = "ffTotal")
ff9merge2 <- ff9merge2[,c(19,1,20,2:18,21:23)]

ff9merge2$Description[ff9merge2$CHARGE_CODE3 == "HRS 291C-102+01-09MPH"] <- "NONCOMPLIANCE-SPEED LIMIT 1-10MPH over"
ff9merge2$Description[ff9merge2$CHARGE_CODE3 == "HRS 291C-102+10-19MPH"] <- "NONCOMPLIANCE-SPEED LIMIT 11-19MPH over"
ff9merge2$Description[ff9merge2$CHARGE_CODE3 == "HRS 291C-102+20-29MPH"] <- "NONCOMPLIANCE-SPEED LIMIT 21-29MPH over"
ff9merge2$Description[ff9merge2$CHARGE_CODE3 == "HRS 291C-102+unknown"] <- "NONCOMPLIANCE-SPEED LIMIT MPH over unspecified"

ff9merge2$Description[ff9merge2$CHARGE_CODE3 == "HRS 291C-105(c)(1)"] <- "EXCESS SPEED 1ST OFF"
ff9merge2$Description[ff9merge2$CHARGE_CODE3 == "HRS 291C-105(c)(2)"] <- "EXCESS SPEED 5YRS OF PRIOR"
ff9merge2$Description[ff9merge2$CHARGE_CODE3 == "HRS 291C-105(c)(3)"] <- "EXCESS SPEED 5YRS TWO PRIOR"
ff9merge2$Description[ff9merge2$CHARGE_CODE3 == "HRS 291C-105(c)(unknown)"] <- "EXCESS SPEED OFF # unspecified"

ff9merge2$default.fees.only[ff9merge2$default.fees.only==0] <- NA
ff9merge2$default.fines.fees[ff9merge2$default.fines.fees==0] <- NA
ff9merge3 <- ff9merge2[,-1]
ff9merge3 <- ff9merge3 %>%
  rename(Charge.Code = "CHARGE_CODE3", mean.fines.fees = "mean", sd.fines.fees = "sd", min.fine.fee = "min", max.fine.fee = "max",
         mean.after.adjustments = "effmean", sd.after.adjustments = "effsd", min.after.adjustments = "effmin", max.after.adjustments = "effmax",
         mean.paid = "paidmean", sd.paid = "paidsd", min.paid = "paidmin", max.paid = "paidmax",
         rank.mean = "rankMean", rank.mean.after.adj = "rankEffMean", rank.mean.paid = "rankPaidMean")
# ff9merge3 <- ff9merge3 %>%
#   rename(Charge.Code = "CHARGE_CODE3", mean.fines.fees = "mean", sd.fines.fees = "sd",
#          mean.after.adjustments = "effmean", sd.after.adjustments = "effsd", mean.paid = "paidmean", sd.paid = "paidsd", 
#          rank.mean = "rankMean", rank.mean.after.adj = "rankEffMean", rank.mean.paid = "rankPaidMean")

#offenses where collapsing creates an NA for description and default fines and fees b/c collapsing creates new category
#not in JIMS
tmpNA <- ff9merge3 %>%
  filter(is.na(Description))
write_csv(tmpNA,paste0(ffPath,"plots_and_tables/collapsedCategories",".csv"))
#---------------------------------------------------
#Set up plotting
#---------------------------------------------------
filterCodes <- filter(ff9merge3, rank.mean <= 104, n>=150) %>%
  select(Charge.Code)

indData<-ff8 %>%
  filter(CHARGE_CODE3 %in% ff9merge3$Charge.Code[ff9merge3$rank.mean <= 104 & ff9merge3$n >= 150])
#filter(CHARGE_CODE3 %in% filterCodes)
#filter(str_detect(CHARGE_CODE,filterCodes))

sumData <- filter(ff9merge3,rank.mean <= 104, n >= 150)

#---------------------------------------------------
#plot
#---------------------------------------------------
dotplot1 <- ggplot(sumData, aes(y=reorder(Charge.Code,mean.fines.fees), x=mean.fines.fees)) +
  #dotplot1 <- ggplot(sumData, aes(y=reorder(CHARGE_CODE3,mean), x=mean, color = n)) +
  geom_point(color = "blue") +
  scale_x_continuous(breaks = seq(0,3500,by=500),limits=c(0,3500)) +
  #scale_color_continuous(name="Number of Defendants", breaks = seq(0,600,by=100), limits = c(0,600),
  #                       labels = c("0","100","200","300","400","500","600"),low = "blue", high = "red") +
  theme_bw() +
  theme(axis.text.y = element_text(size = 12)) +
  xlab("Mean fines and fees") + ylab("Charge Codes") +
  ggtitle("Charge codes by fines and fees ordered (2010-2019)")

# dotplot2 <- dotplot1 +
#   geom_errorbarh(aes(xmin=min.fine.fee, xmax=max.fine.fee), height=.5) +
#   xlab("Mean fines and fees ordered (with min and max)")

# dotplot3 <- dotplot2 +
#   geom_point(indData,mapping = aes(y=CHARGE_CODE3, x=ffTotalAmt),color = "black", alpha = .2) +
#   #geom_point(indData,mapping = aes(y=CHARGE_CODE3, x=ffTotalAmt),color = "black", pch = 3, size = .5, alpha = 1) +
#   geom_point(sumData, mapping=aes(y=reorder(Charge.Code,mean.fines.fees), x=mean.fines.fees), color = "blue") +
#   #  geom_point(sumData, mapping=aes(y=reorder(CHARGE_CODE3,mean), x=mean, color = n)) +
#   xlab("Mean fines and fees ordered (with min, max, and individual data)")

dotplot3 <- dotplot1 +
  geom_point(indData,mapping = aes(y=CHARGE_CODE3, x=ffTotalAmt),color = "black", alpha = .2) +
  #geom_point(indData,mapping = aes(y=CHARGE_CODE3, x=ffTotalAmt),color = "black", pch = 3, size = .5, alpha = 1) +
  geom_point(sumData, mapping=aes(y=reorder(Charge.Code,mean.fines.fees), x=mean.fines.fees), color = "blue") +
  #  geom_point(sumData, mapping=aes(y=reorder(CHARGE_CODE3,mean), x=mean, color = n)) +
  xlab("Mean fines and fees ordered (with individual data)")

#library(plotly)
#ggplotly(dotplot1)

#---------------------------------------------------
#Arrange and save plots
#---------------------------------------------------
# library(gridExtra)
# #put all 3 dotplots, in increasing order of complexity, in one row
# gridToSaveWide = grid.arrange(dotplot1,dotplot2,dotplot3, nrow = 1)
# ffChargeCodesWidePath  <- paste0(ffPath,"plots_and_tables/ffChargeCodesWide",".jpg")
# i <- 1
# while (file.exists(ffChargeCodesWidePath)){
#   ffChargeCodesWidePath <- paste0(ffPath,"plots_and_tables/ffChargeCodesWide","_",i,".jpg")
#   i<-i+1
# }
# ggsave(ffChargeCodesWidePath,gridToSaveWide,height=11,width=24,units="in", device = "jpeg")

# #put all 3 dotplots, in increasing order of complexity, in one column
# gridToSaveLong = grid.arrange(dotplot1,dotplot2,dotplot3, nrow = 3)
# ffChargeCodesLongPath  <- paste0(ffPath,"plots_and_tables/ffChargeCodesLong",".pdf")
# i <- 1
# while (file.exists(ffChargeCodesLongPath)){
#   ffChargeCodesLongPath <- paste0(ffPath,"plots_and_tables/ffChargeCodesLong","_",i,".pdf")
#   i<-i+1
# }
# ggsave(ffChargeCodesLongPath,gridToSaveLong,height=33,width=8,units="in")

#---------------------------------------------------
#Construct grob with plot and table ***UNDER CONSTRUCTION***
#---------------------------------------------------
sumData2 <- sumData[,c(1:5,12:13,17,19)]
sumData2[,c(4,6)] <- paste("$",formatC(as.numeric(unlist(sumData2[,c(4,6)])), format = "f", digits = 2, big.mark = ","))
sumData2[,c(5,7)] <- formatC(as.numeric(unlist(sumData2[,c(5,7)])), format = "f", digits = 2, big.mark = ",")
sumData2[,c(3)] <- formatC(unlist(sumData2[,c(3)]), format = "d", big.mark = ",")

tt <- tableGrob(filter(sumData2,rank.mean <=104),rows=NULL)
hlay <- rbind(c(1,2,NA),
              c(1,2,3),
              c(1,2,NA))
plotTable <- grid.arrange(dotplot1, dotplot3, tt, nrow = 3, as.table = TRUE,heights = unit(c(.6,13,1),c("in","in","in")),layout_matrix = hlay)
plotTablePath  <- paste0(ffPath,"plots_and_tables/ggplotAndTable",".jpg")
i <- 1
while (file.exists(plotTablePath)){
  plotTablePath <- paste0(ffPath,"plots_and_tables/ggplotAndTable","_",i,".jpg")
  i<-i+1
}
ggsave(plotTablePath,plotTable,height=16,width=40,units="in",device = "jpeg")

#---------------------------------------------------
#Construct tables specific to 291C-105, 291C-102, 431:10C-104, 286-102, and 286-132
#---------------------------------------------------
sumData291C.105 <- ff8 %>%
  filter(grepl("291C-105",CHARGE_CODE3)) %>%
  group_by(CHARGE_CODE3) %>%
  summarize(n.Repeat = n(), mean.fines.fees = mean(ffTotalAmt, rm.na = TRUE), sd.fines.fees = sd(ffTotalAmt), 
            #min.fine.fee = min(ffTotalAmt),max.fine.fee = max(ffTotalAmt), 
            #mean.after.adjustments = mean(effTotalAmt, rm.na = TRUE), sd.after.adjustments = sd(effTotalAmt), 
            #min.after.adjustments = min(effTotalAmt), max.after.adjustments = max(effTotalAmt), 
            mean.paid = mean(ffTotalPaid, rm.na = TRUE),sd.paid = sd(ffTotalPaid)) %>%
            #min.paid = min(ffTotalPaid),max.paid = max(ffTotalPaid)) %>% 
  rename(Charge.Code = "CHARGE_CODE3") %>%
  arrange(Charge.Code) 
sumData291C.105$offense.number <- as.factor(c(1:3,NA))
sumData291C.105<-sumData291C.105[,c(1,7,2:6)]

sumData291C.102 <- ff8 %>%
  filter(grepl("291C-102",CHARGE_CODE3)) %>%
  group_by(PARTY_PIDM,CHARGE_CODE3) %>%
  mutate(offenseOrder = rank(VIOLATION_DATE)) 

# sumData291C.102REP <- sumData291C.102 %>%
#   group_by(offenseOrder) %>%
#   summarize(n =n(), mean = mean(ffTotalAmt, rm.na = TRUE), sd = sd(ffTotalAmt), min = min(ffTotalAmt),
#           max = max(ffTotalAmt), effmean = mean(effTotalAmt, rm.na = TRUE), effsd = sd(effTotalAmt), 
#           effmin = min(effTotalAmt),effmax = max(effTotalAmt), paidmean = mean(ffTotalPaid, rm.na = TRUE), 
#           paidsd = sd(ffTotalPaid), paidmin = min(ffTotalPaid),paidmax = max(ffTotalPaid)) %>%
#   arrange(desc(mean)) %>%
#   mutate(rankMean = 1:nrow(.), rankEffMean = row_number(-effmean), rankPaidMean = row_number(-paidmean))

sumData291C.102$offense.number <- cut(sumData291C.102$offenseOrder, 
                        breaks=c(-Inf, 1.5, 2.5, Inf), 
                        labels=c("1st","2nd","3rd-plus"))

sumData291C.102REP <- sumData291C.102 %>%
  group_by(offense.number, CHARGE_CODE3) %>%
  summarize(n.Repeat = n(), mean.fines.fees = mean(ffTotalAmt, rm.na = TRUE), sd.fines.fees = sd(ffTotalAmt), 
            #min.fine.fee = min(ffTotalAmt),max.fine.fee = max(ffTotalAmt), 
            #mean.after.adjustments = mean(effTotalAmt, rm.na = TRUE), sd.after.adjustments = sd(effTotalAmt), 
            #min.after.adjustments = min(effTotalAmt), max.after.adjustments = max(effTotalAmt), 
            mean.paid = mean(ffTotalPaid, rm.na = TRUE),sd.paid = sd(ffTotalPaid)) %>%
            #min.paid = min(ffTotalPaid),max.paid = max(ffTotalPaid)) %>%
  #mutate(rank.mean = 1:nrow(.), rank.mean.after.adjustments = row_number(-mean.after.adjustments), rank.mean.paid = row_number(-mean.paid)) %>%
  #unite(Charge.Code,c(CHARGE_CODE3,offense.number),remove = TRUE) %>%
  rename(Charge.Code = "CHARGE_CODE3")%>%
  arrange(Charge.Code)
sumData291C.102REP <- sumData291C.102REP[,c(2,1,3:7)]
  
sumData431.10C.104 <- ff8 %>%
  filter(grepl("431:10C-104",CHARGE_CODE3)) %>%
  group_by(PARTY_PIDM) %>%
  mutate(offenseOrder = rank(VIOLATION_DATE)) 

sumData431.10C.104$offense.number <- cut(sumData431.10C.104$offenseOrder, 
                                       breaks=c(-Inf, 1.5, 2.5, Inf), 
                                       labels=c("1st","2nd","3rd-plus"))

sumData431.10C.104REP <- sumData431.10C.104 %>%
  group_by(offense.number) %>%
  summarize(CHARGE_CODE3 = first(CHARGE_CODE3), n.Repeat = n(), mean.fines.fees = mean(ffTotalAmt, rm.na = TRUE), sd.fines.fees = sd(ffTotalAmt), 
            #min.fine.fee = min(ffTotalAmt),max.fine.fee = max(ffTotalAmt), 
            #mean.after.adjustments = mean(effTotalAmt, rm.na = TRUE), sd.after.adjustments = sd(effTotalAmt), 
            #min.after.adjustments = min(effTotalAmt), max.after.adjustments = max(effTotalAmt), 
            mean.paid = mean(ffTotalPaid, rm.na = TRUE),sd.paid = sd(ffTotalPaid)) %>%
            #min.paid = min(ffTotalPaid),max.paid = max(ffTotalPaid)) %>%
  #mutate(rank.mean = 1:nrow(.), rank.mean.after.adjustments = row_number(-mean.after.adjustments), rank.mean.paid = row_number(-mean.paid)) %>%
  #unite(Charge.Code,c(CHARGE_CODE3,offense.number),remove = TRUE) %>%
  rename(Charge.Code = "CHARGE_CODE3")%>%
  arrange(Charge.Code)
sumData431.10C.104REP <- sumData431.10C.104REP[,c(2,1,3:7)]


sumData286.102 <- ff8 %>%
  filter(grepl("286-102",CHARGE_CODE3)) %>%
  group_by(PARTY_PIDM) %>%
  mutate(offenseOrder = rank(VIOLATION_DATE)) 

sumData286.102$offense.number <- cut(sumData286.102$offenseOrder, 
                                          breaks=c(-Inf, 1.5, 2.5, Inf), 
                                          labels=c("1st","2nd","3rd-plus"))

sumData286.102REP <- sumData286.102 %>%
  group_by(offense.number) %>%
  summarize(CHARGE_CODE3 = first(CHARGE_CODE3), n.Repeat = n(), mean.fines.fees = mean(ffTotalAmt, rm.na = TRUE), sd.fines.fees = sd(ffTotalAmt), 
            #min.fine.fee = min(ffTotalAmt),max.fine.fee = max(ffTotalAmt), 
            #mean.after.adjustments = mean(effTotalAmt, rm.na = TRUE), sd.after.adjustments = sd(effTotalAmt), 
            #min.after.adjustments = min(effTotalAmt), max.after.adjustments = max(effTotalAmt), 
            mean.paid = mean(ffTotalPaid, rm.na = TRUE),sd.paid = sd(ffTotalPaid)) %>%
            #min.paid = min(ffTotalPaid),max.paid = max(ffTotalPaid)) %>%
  #mutate(rank.mean = 1:nrow(.), rank.mean.after.adjustments = row_number(-mean.after.adjustments), rank.mean.paid = row_number(-mean.paid))
  #unite(Charge.Code,c(CHARGE_CODE3,offense.number),remove = TRUE) %>%
  rename(Charge.Code = "CHARGE_CODE3")%>%
  arrange(Charge.Code)
sumData286.102REP <- sumData286.102REP[,c(2,1,3:7)]

sumData286.132 <- ff8 %>%
  filter(grepl("286-132",CHARGE_CODE3)) %>%
  group_by(PARTY_PIDM) %>%
  mutate(offenseOrder = rank(VIOLATION_DATE)) 

sumData286.132$offense.number <- cut(sumData286.132$offenseOrder, 
                                      breaks=c(-Inf, 1.5, 2.5, Inf), 
                                      labels=c("1st","2nd","3rd-plus"))

sumData286.132REP <- sumData286.132 %>%
  group_by(offense.number) %>%
  summarize(CHARGE_CODE3 = first(CHARGE_CODE3), n.Repeat = n(), mean.fines.fees = mean(ffTotalAmt, rm.na = TRUE), sd.fines.fees = sd(ffTotalAmt), 
            #min.fine.fee = min(ffTotalAmt),max.fine.fee = max(ffTotalAmt), 
            #mean.after.adjustments = mean(effTotalAmt, rm.na = TRUE), sd.after.adjustments = sd(effTotalAmt), 
            #min.after.adjustments = min(effTotalAmt), max.after.adjustments = max(effTotalAmt), 
            mean.paid = mean(ffTotalPaid, rm.na = TRUE),sd.paid = sd(ffTotalPaid)) %>%
            #min.paid = min(ffTotalPaid),max.paid = max(ffTotalPaid)) %>%
 # mutate(rank.mean = 1:nrow(.), rank.mean.after.adjustments = row_number(-mean.after.adjustments), rank.mean.paid = row_number(-mean.paid))
  #unite(Charge.Code,c(CHARGE_CODE3,offense.number),remove = TRUE) %>%
  rename(Charge.Code = "CHARGE_CODE3")%>%
  arrange(Charge.Code)
sumData286.132REP <- sumData286.132REP[,c(2,1,3:7)]


multipleOffenseTable <- rbind.data.frame(sumData291C.102REP,sumData291C.105,sumData431.10C.104REP,sumData286.102REP,sumData286.132REP)

multiOffPath  <- paste0(ffPath,"plots_and_tables/fineFeeMultipleOffenseTable",".csv")
i <- 1
while (file.exists(multiOffPath)){
  multiOffPath <- paste0(ffPath,"plots_and_tables/fineFeeMultipleOffenseTable","_",i,".csv")
  i<-i+1
}
write_csv(multipleOffenseTable,multiOffPath)
#---------------------------------------------------
#format and save table
#---------------------------------------------------
# ffOwedTable <- ff9
# ffOwedTable[,c(3,5,6)] <- paste("$",formatC(as.numeric(unlist(ffOwedTable[,c(3,5,6)])), format = "f", digits = 2, big.mark = ","))
# ffOwedTable[,c(4)] <- formatC(as.numeric(unlist(ffOwedTable[,c(4)])), format = "f", digits = 2, big.mark = ",")
# tablePath  <- paste0(ffPath,"plots_and_tables/chargeCodesOwedFineFeeCodes",".csv")
# i <- 1
# while (file.exists(tablePath)){
#   tablePath <- paste0(ffPath,"plots_and_tables/chargeCodesOwedFineFeeCodes","_",i,".csv")
#   i<-i+1
# }
# write_csv(ffOwedTable,tablePath)
# 
# ffPaidTable <- ff9paid
# ffPaidTable[,c(3,5,6)] <- paste("$",formatC(as.numeric(unlist(ffPaidTable[,c(3,5,6)])), format = "f", digits = 2, big.mark = ","))
# ffPaidTable[,c(4)] <- formatC(as.numeric(unlist(ffPaidTable[,c(4)])), format = "f", digits = 2, big.mark = ",")
# tablePath  <- paste0(ffPath,"plots_and_tables/chargeCodesPaidFineFeeCodes",".csv")
# i <- 1
# while (file.exists(tablePath)){
#   tablePath <- paste0(ffPath,"plots_and_tables/chargeCodesPaidFineFeeCodes","_",i,".csv")
#   i<-i+1
# }
# write_csv(ffPaidTable,tablePath)

ff9merge3b <- ff9merge3[,c(1:5,12,13)]
ffTotalTable <- ff9merge3b %>%
  filter(n >= 150)
ffTotalTable[,c(4,6)] <- paste("$",formatC(as.numeric(unlist(ffTotalTable[,c(4,6)])), format = "f", digits = 2, big.mark = ","))
#ffTotalTable$default.fees.only[!is.na(ffTotalTable$default.fees.only)] <- paste("$",formatC(as.numeric(unlist(ffTotalTable$default.fees.only)), format = "f", digits = 2, big.mark = ","))
#ffTotalTable$default.fines.only[ffTotalTable$default.fines.only>0] <- paste("$",formatC(as.numeric(unlist(ffTotalTable$default.fines.only)), format = "f", digits = 2, big.mark = ","))
#ffTotalTable$default.fines.fees[ffTotalTable$default.fines.fees>0] <- paste("$",formatC(as.numeric(unlist(ffTotalTable$default.fines.fees)), format = "f", digits = 2, big.mark = ","))
ffTotalTable[,c(5,7)] <- formatC(as.numeric(unlist(ffTotalTable[,c(5,7)])), format = "f", digits = 2, big.mark = ",")
ffTotalTable[,c(3)] <- formatC(unlist(ffTotalTable[,c(3)]), format = "d", big.mark = ",")

tablePath  <- paste0(ffPath,"plots_and_tables/fineFeeMostCommonTable",".csv")
i <- 1
while (file.exists(tablePath)){
  tablePath <- paste0(ffPath,"plots_and_tables/fineFeeMostCommonTable","_",i,".csv")
  i<-i+1
}
write_csv(ffTotalTable,tablePath)

#---------------------------------------------------
#Create Fines and Fees Bins - count active cases and # of license stoppers in each bin
# rows = Year (2010:2019)
# columns = bins, counts, # of license stoppers
#---------------------------------------------------

#---------------------------------------------------
#sum each person's fines and fees across cases and charges, select cases with outstanding balances (BALANCE > 0)
#---------------------------------------------------
ffBins1 <- ff8 %>%
  group_by(PARTY_PIDM,STOPPER_STATUS) %>%
  summarize(FF_AMT = sum(ffTotalAmt), BALANCE = sum(Balance), FF_ADJ = sum(ffTotalAdj)) %>%
  filter(BALANCE > 0)

#---------------------------------------------------
#create bins, categorize fine amounts by bins
#---------------------------------------------------
ffBins2<-ffBins1
ffBins2$category <- cut(ffBins1$FF_AMT, 
                       breaks=c(-Inf, 5000, 10000, 15000, 20000, 25000, Inf), 
                       labels=c("under 5K","5K-10K","10K-15K","15K-20K","20K-25K","over 25K"))

#---------------------------------------------------
#count # of people in each bin and how many have license stoppers/restricted licenses in each bin
#---------------------------------------------------
tableFFBins <- ffBins2 %>%
  group_by(category,STOPPER_STATUS) %>%
  summarize(n = n()) %>%
  spread(STOPPER_STATUS,n) %>%
  rename(no_label = "<NA>") %>%
  mutate(n = sum(C,S,R,no_label, na.rm = TRUE)) %>%
  select(-c(C,no_label))
tableFFBins <- tableFFBins[,c(1,4,2,3)]
tableFFBins[is.na(tableFFBins)] <- 0

tableFFBins2 <- as.data.frame(tableFFBins[,-1])
row.names(tableFFBins2) <- tableFFBins$category
tableFFBins2['Total',] <- colSums(tableFFBins2)
category <- row.names(tableFFBins2)
tableFFBins3 <- data.frame(category,tableFFBins2,row.names = NULL)

tableFFBins3[,c(2:4)] <- formatC(unlist(tableFFBins3[,c(2:4)]), format = "d", big.mark = ",")
colnames(tableFFBins3) <- c("$ range","Number of defendants with outstanding fines/fees","restricted license","license/registration stoppers")

binTablePath  <- paste0(ffPath,"3-binAndStopperTable_draft5",".csv")
i <- 1
while (file.exists(binTablePath)){
  binTablePath <- paste0(ffPath,"3-binAndStopperTable_draft5","_",i,".csv")
  i<-i+1
}
write_csv(tableFFBins3,binTablePath)

#---------------------------------------------------
#Supplementary analyses
#---------------------------------------------------
# scatter plot of %paid by amt ordered with 80% line and smoothed line for data
#---------------------------------------------------
ffscatter <- ff8 %>%
  filter(effTotalAmt>0) %>%
  mutate(percentPaid = 100*ffTotalPaid/effTotalAmt)

#replace NA with 0
scatPlotPaid <- ggplot(filter(ffscatter,effTotalAmt>500), aes(y=percentPaid, x = effTotalAmt)) +
  geom_point(alpha = .1) +
  scale_x_continuous(breaks = seq(0,4000,by=500),limits=c(0,4000)) +
  scale_y_continuous(breaks = seq(0,100,by=10), limits=c(0,100)) +
  #scale_color_discrete(name="Stopper Status", labels = c("Cleared","Restricted","Stopped","NA")) +
  #scale_color_continuous(name="Year", breaks = seq(2010,2019,by=1), limits = c(2010,2019)) +
                       #labels = c("Cleared","Restricted","Stopped","NA")) +
  #scale_color_discrete(name="Year", breaks = seq(2010,2019,by=1), limits = c(2010,2019)) +
  theme_bw() +
  theme(axis.text = element_text(size = 12),axis.title=element_text(size=14),plot.title=element_text(size=16,face="bold")) +
  xlab("Size of fines/fees (adjusted)") + ylab("Percent paid") +
  ggtitle("% of fines/fees paid by size of fines/fees (2010-2019)") +
  annotate("text", x = 150, y = 50, label = "fines > $500", size = 5)
scatPlotPaid2 <- scatPlotPaid + geom_abline(intercept = 80, slope = 0, color = "red") +
  ggtitle("% of fines/fees paid by size of fines/fees with 80% reference line (2010-2019)")
scatPlotPaid3 <- scatPlotPaid2 +  geom_smooth(fill="purple", color = "darkorange", size = 1, method = "lm") +
  ggtitle("% of fines/fees paid by size of fines/fees with line of best fit (2010-2019)")

library(gridExtra)
#put all 3 scatPlotPaid, in increasing order of complexity, in one row
scatPlotToSaveWide = grid.arrange(scatPlotPaid,scatPlotPaid2,scatPlotPaid3, nrow = 1)
scatPlotWidePath  <- paste0(ffPath,"plots_and_tables/scatPlotWide",".pdf")
i <- 1
while (file.exists(scatPlotWidePath)){
  scatPlotWidePath <- paste0(ffPath,"plots_and_tables/scatPlotWide","_",i,".pdf")
  i<-i+1
}
ggsave(scatPlotWidePath,scatPlotToSaveWide,height=11,width=26,units="in")

#---------------------------------------------------
#default charge codes
#---------------------------------------------------
library(zoo)

defPath <- "/home/adam/Desktop/fines_fees/files_fines_fees/"
defaultFF <- read_excel(paste0(defPath,"Charge Codes with Fines-Fees - CR2016.xls"))

#---------------------------------------------------
#fix column names and remove empty columns
#---------------------------------------------------
colnames(defaultFF) <- defaultFF[4,]
colnames(defaultFF)[c(25,28)] <- c("EffectiveDate","Amount2")
# defaultFF1 <- defaultFF %>%
#   select(-starts_with("NA")) %>%
#   head(3)
defaultFF1<-defaultFF[,-which(names(defaultFF) == "NA")] 

defaultFF1<-defaultFF1[,-c(8,11,13)]
defaultFF2 <- defaultFF1 %>%
  rename_all(funs(make.names(.)))

#---------------------------------------------------
#remove rows with repeating header info and rows w/empty VER ID or DETC Code
#---------------------------------------------------
defaultFF2 <- defaultFF2 %>%
  filter(!grepl("^Ver",Ver.ID))%>%
  filter(!is.na(Ver.ID) | !is.na(DETC.Code))

#---------------------------------------------------
#repeat/fill in missing values until reaching new value
#---------------------------------------------------
defaultFF3 <- defaultFF2 %>%
  mutate(Ver.ID = na.locf(Ver.ID),Charge.Code = na.locf(Charge.Code), Description = na.locf(Description), 
         Valid.From = na.locf(Valid.From),Level = na.locf(Level), Pred_Code = na.locf(Pred_Code)) %>%
  filter(grepl("HRS",Charge.Code) | grepl("HAR",Charge.Code))


#---------------------------------------------------
#format dates
#---------------------------------------------------
defaultFF3$Valid.From <- as.Date(as.numeric(defaultFF3$Valid.From), origin = "1899-12-30")
defaultFF3$EffectiveDate <- as.Date(as.numeric(defaultFF3$EffectiveDate), origin = "1899-12-30")

#---------------------------------------------------
#view DETC Codes, label as fine or fee
#---------------------------------------------------
detcCodes <- as.data.frame(sort(unique(defaultFF3$DETC.Code)))
defaultFF3$sanction_type <- ifelse(grepl("^F",defaultFF3$DETC.Code) & !grepl("^FEES",defaultFF3$DETC.Code),"fine","fee")

#---------------------------------------------------
#collapse fines and fees, create new cols with sums
#---------------------------------------------------
defaultFF4 <- defaultFF3 %>%
  group_by(Ver.ID,sanction_type) %>%
  summarize(Charge.Code = first(Charge.Code),Description = first(Description), Valid.From = first(Valid.From), Level = first(Level),
            Pred_Code = first(Pred_Code), Amount3 = sum(Amount2,na.rm=TRUE))

#---------------------------------------------------
#reshape from long to wide format, calculate total F/F, and sort
#---------------------------------------------------
# ff5 <- ff4 %>%
#   melt(id=c("Ver.ID","Charge.Code","Description","Valid.From","sanction_type","Pred_Code"),
#        variable.name = "status",value.name = "AMT_SUM")

defaultFF5 <- defaultFF4 %>%
  dcast(Ver.ID + Charge.Code + Description + Valid.From + Level + Pred_Code ~ sanction_type, value.var = "Amount3") %>%
  mutate(ffTotal = replace_na(fee,0) + replace_na(fine,0)) %>%
  arrange(Charge.Code)

defaultFF6 <- defaultFF5 %>%
  arrange(desc(ffTotal))

#tmp6 <- defaultFF6%>%filter(ffTotal>0,grepl("^HRS",Charge.Code))

#---------------------------------------------------
#write to disk
#---------------------------------------------------
write_csv(defaultFF5,paste0(defPath,"defaultFF_by_charge_code.csv"))
write_csv(defaultFF6,paste0(defPath,"defaultFF_by_ffAmount.csv"))

#---------------------------------------------------
#SD explanation
#---------------------------------------------------
fine0 <- rep(250, 10)
label0 <- rep("dataset 1 (SD = 0)",10)
meanF0 <- mean(fine0)
sdF0 <- sd(fine0)
#when SD = 0, the mean represents the data perfectly

set.seed(100)
fine1 <- rnorm(10,250,45)
label1 <- rep("dataset 2 (SD = 25)",10)
meanF1 <- mean(fine1)
sdF1 <- sd(fine1)
#when SD is small, the mean represents the data well

set.seed(100)
fine2 <- rnorm(10,250,178)
label2 <- rep("dataset 3 (SD = 100)",10)
meanF2 <- mean(fine2)
sdF2 <- sd(fine2)
#when SD is large, the mean represents the data poorly

fine3 <- rep(c(100,400), each=5)
label3 <- rep("dataset 4 (SD = 158)",10)
meanF3 <- mean(fine3)
sdF3 <- sd(fine3)
#Sometimes the mean doesn't represent the data at all

df_SD <- data.frame(c(fine0,fine1,fine2,fine3),c(label0,label1,label2,label3))
colnames(df_SD)<-c("fine","label")
dotplot5 <- ggplot(df_SD, aes(y=reorder(label,desc(label)), x=fine, color = label)) +
  #geom_point(color = "blue") +
  geom_jitter(width = 3, height = .1) +
  scale_x_continuous(breaks = seq(0,500,by=50),limits=c(0,500)) +
  xlab("fine amount") + ylab("")  + guides(color=FALSE) +  theme_bw() +
  ggtitle("Understanding Standard Deviation (SD)", subtitle = "Four very different datasets with the same mean ($250)") +
  theme(plot.title = element_text(hjust = 0.5),plot.subtitle = element_text(hjust = 0.5), axis.text = element_text(size = 10))

dotPlot5Path  <- paste0(ffPath,"plots_and_tables/sd_explanation",".jpg")
i <- 1
while (file.exists(dotPlot5Path)){
  dotPlot5Path <- paste0(ffPath,"plots_and_tables/sd_explanation","_",i,".jpg")
  i<-i+1
}
ggsave(dotPlot5Path,dotplot5,height=11,width=11,units="in", device = "jpeg")

#---------------------------------------------------
#TO DELETE
#---------------------------------------------------
start.time1 <- Sys.time()
ff3a <- ff2 %>%
  group_by(CASE_ID,PARTY_PIDM,DETC_CODE,CHARGE_CODE) %>% 
  summarize(FINE_AMT=mean(FINE_AMT),BALANCE=first(BALANCE),ADJUSTMENT=mean(ADJUSTMENT),VIOLATION_DATE=first(VIOLATION_DATE),
            CHARGE_NO=first(CHARGE_NO),code=first(code),section=first(section),STOPPER_STATUS=first(STOPPER_STATUS), STOPPER_TYPE=first(STOPPER_TYPE),
            msbStatus=first(msbStatus),sanction_type=first(sanction_type),VIOLATION_DATE2=first(VIOLATION_DATE2),Year=first(Year))
end.time1 <- Sys.time()
time.taken1 <- end.time1 - start.time1
time.taken1
ff3a<-ff3a[,c(1:3,5:9,4,10:17)]
ffDiff <- setdiff(ff2,ff3a)

