#compared execution time of the following two group_by code blocks ***on JUD machine***:
#Block 1. group_by(CASE_ID,PARTY_PIDM,DETC_CODE,CHARGE_CODE,ADJUSTMENT,FINE_AMT) %>% 
#Block 2. group_by(CASE_ID,PARTY_PIDM,DETC_CODE,FINE_AMT,ADJUSTMENT,CHARGE_CODE,sanction_type,STOPPER_STATUS, STOPPER_TYPE,msbStatus,sanction_type,Year) %>% 
#---------------------------------------------------
#BLOCK 1
#---------------------------------------------------
# start.time1 <- Sys.time()
# ff3 <- ff2 %>%
#   group_by(CASE_ID,PARTY_PIDM,DETC_CODE,CHARGE_CODE,FINE_AMT,ADJUSTMENT) %>%
#   summarize(PAID_AMT = sum(FINE_AMT-BALANCE),STOPPER_STATUS=first(STOPPER_STATUS), STOPPER_TYPE=first(STOPPER_TYPE),msbStatus=first(msbStatus),
#             sanction_type=first(sanction_type),Year=first(Year))
# end.time1 <- Sys.time()
# time.taken1 <- end.time1 - start.time1
# time.taken1
#---------------------------------------------------
#BLOCK 2
#---------------------------------------------------
# start.time2 <- Sys.time()
# ff4 <- ff2 %>%
#   group_by(CASE_ID,PARTY_PIDM,DETC_CODE,CHARGE_CODE,FINE_AMT,ADJUSTMENT,STOPPER_STATUS, STOPPER_TYPE,msbStatus,sanction_type,Year) %>% 
#   summarize(PAID_AMT = sum(FINE_AMT-BALANCE))
# end.time2 <- Sys.time()
# time.taken2 <- end.time2 - start.time2
# time.taken2
#---------------------------------------------------
#Results ***JUD machine***
#---------------------------------------------------
#with 100,000 rows of data, BLOCK 1 finished in 1.871936 secs and BLOCK 2 finished in 3.113053 secs
#with 1,000,000 rows of data, BLOCK 1 finish in 19.36043 secs, and BLOCK 2 crashed the computer
#combinations of groups with many arguments provided to group_by becomes computationally prohibitive

