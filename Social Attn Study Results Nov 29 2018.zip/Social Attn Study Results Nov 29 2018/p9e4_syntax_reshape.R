dataFile = read.csv("socialattndata_final.csv")

dataReshape <-unite(dataFile,"soa_cong", c("soa","congruency"))

dataReshape2 <-spread(dataReshape, key = soa_cong, value = cueeffect)
coalesce_by_column <- function(df) {
  return(dplyr::coalesce(!!! as.list(df)))
}
dataReshape3 <- dataReshape2 %>% 
  group_by(subject) %>% 
  summarise_all(coalesce_by_column)
write.csv(x=dataReshape3, file = "socialattndata_ac.csv")



#aggregate(x=DF[c("v1","v2","v3","v4")], by=list(name=DF$name), min, na.rm = TRUE)