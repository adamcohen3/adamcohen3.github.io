
library(plyr)
library(afex)
library(dplyr)
library(Rmisc)
library(ggplot2)
library(glmm)
library(Rmisc)
library(tidyr)


# 5 data sets required for this analysis: 
# - european data is split into those primed by independent self (ind) 
#   and interdependent self (col) - collected by Andy
# - asian data (asndat) - collected by Ronda (2016)
# - new asian data - collected by Ronda in (2018)
# - questionnaire info (survey)



### last updated nov 29 2018




##### importing data files



# import euro data - 2 sets: ind and int
setwd("C:/Users/ronda/Google Drive/grad/projects/01 social attn/data/euro data/")
ind = read.csv("p9e4_primeIND_2015-09-22.csv")
col = read.csv("p9e4_primeINT_2015-09-22.csv")

# import asian data collected from 2015-2016
setwd("C:/Users/ronda/Google Drive/grad/projects/01 social attn/data/asian data/")
asndat = read.csv("p9e4_rawdata_asn.csv") 

# import new asian data from fall 2018
setwd("C:/Users/ronda/Google Drive/grad/projects/01 social attn/data/new asn data/")
newasndat = read.csv("new_asndat2018.csv") 

# import both full survey data +old survey data (survey data collected up to 2016)
setwd("C:/Users/ronda/Google Drive/grad/projects/01 social attn/data/survey data/")
survey = read.csv("p9e4_rawsurvey.csv")
oldsurvey = read.csv("p9e4_oldsurvey.csv")

# import new culture/prime data from pplog for 2018 asn data
setwd("C:/Users/ronda/Google Drive/grad/projects/01 social attn/data/new asn data/")
newpplog = read.csv("newpplog.csv")




#------------------    E U R O P E A N     D A T A ------------------------------



# rename RT var for easy use later

ind <- rename(ind, rt = targetSlide.RT)
col <- rename(col, rt = targetSlide.RT)

# separate both data files by only test data

ind2 <- ind[ind$TrialName == c("test"),] 
col2 <- col[col$TrialName == c("test"),] 

# separate both data files by correct only

ind3 <- ind2 %>%
  filter(targetSlide.ACC == 1) 
col3 <- col2 %>%
  filter(targetSlide.ACC == 1) 



?filter()
# checking if any of the sessions are other than "1"

table(ind3$Session)
table(col3$Session)


ind3[which.max(ind3$Session), ]
#     Subject Session cueDur targetSlide.ACC targetSlide.RT TrialName TrialTypeBG TrialTypeFG
#2711      21      21    200               1            359      test Incongruent   Congruent

# subject 21 has all of its RT sessions as 21, probably typo from RA so it's fine


# add prime info for each df
ind3$prime <- "ind"
col3$prime <- "col"

# bind both data sets and straighten up id
eurodat <- rbind(ind3, col3)
eurodat <- eurodat[order(eurodat$Subject) , ]


# remove extraneous variables
eurodat$Session <- NULL
eurodat$targetSlide.ACC <- NULL
eurodat$TrialName <- NULL


# rename variables and create new ones
eurodat <- rename(eurodat, subject = Subject)

eurodat$congruency[eurodat$TrialTypeBG == "Congruent" & eurodat$TrialTypeFG=="Congruent"] <- "match" 
eurodat$congruency[eurodat$TrialTypeBG == "Incongruent" & eurodat$TrialTypeFG=="Incongruent"] <- "match" 
eurodat$congruency[eurodat$TrialTypeBG == "Congruent" & eurodat$TrialTypeFG=="Incongruent"] <- "mismatch" 
eurodat$congruency[eurodat$TrialTypeBG == "Incongruent" & eurodat$TrialTypeFG=="Congruent"] <- "mismatch" 

eurodat$fgbg[eurodat$TrialTypeBG == "Congruent" & eurodat$TrialTypeFG=="Congruent"] <- "CC" 
eurodat$fgbg[eurodat$TrialTypeBG == "Incongruent" & eurodat$TrialTypeFG=="Incongruent"] <- "II" 
eurodat$fgbg[eurodat$TrialTypeBG == "Congruent" & eurodat$TrialTypeFG=="Incongruent"] <- "IC" 
eurodat$fgbg[eurodat$TrialTypeBG == "Incongruent" & eurodat$TrialTypeFG=="Congruent"] <- "CI" 




# remove extraneous variables

eurodat$TrialTypeBG <- NULL
eurodat$TrialTypeFG <- NULL






#---------
# remove participants who do not qualify from european data based off andy's info in email w joni
# inital N = 280

alldat <- eurodat

# ind: 2, 4, 6, 7, 21, 85, 88, 90, 107, 114, 125
# col: 3, 5, 45, 46, 106, 108, 111, 124, 138, 140

alldat  <- alldat[!(alldat$subject==2),]
alldat  <- alldat[!(alldat$subject==4),]
alldat  <- alldat[!(alldat$subject==6),]
alldat  <- alldat[!(alldat$subject==7),]
alldat  <- alldat[!(alldat$subject==21),]
alldat  <- alldat[!(alldat$subject==85),]
alldat  <- alldat[!(alldat$subject==88),]
alldat  <- alldat[!(alldat$subject==90),]
alldat  <- alldat[!(alldat$subject==107),]
alldat  <- alldat[!(alldat$subject==114),]
alldat  <- alldat[!(alldat$subject==125),]

alldat  <- alldat[!(alldat$subject==3),]
alldat  <- alldat[!(alldat$subject==5),]
alldat  <- alldat[!(alldat$subject==45),]
alldat  <- alldat[!(alldat$subject==46),]
alldat  <- alldat[!(alldat$subject==106),]
alldat  <- alldat[!(alldat$subject==108),]
alldat  <- alldat[!(alldat$subject==111),]
alldat  <- alldat[!(alldat$subject==124),]
alldat  <- alldat[!(alldat$subject==138),]
alldat  <- alldat[!(alldat$subject==140),]

# remove pps from additional concerns/comments mentioned
# 31 48 59 60 104 105
alldat  <- alldat[!(alldat$subject==31),]
alldat  <- alldat[!(alldat$subject==48),]
alldat  <- alldat[!(alldat$subject==59),]
alldat  <- alldat[!(alldat$subject==60),]
alldat  <- alldat[!(alldat$subject==104),]
alldat  <- alldat[!(alldat$subject==105),]

eurodat <- alldat








##### -----------------------------------  ANTICIPATIONS / EXPIRATIONS / OUTLIERS REMOVAL



grandN <- nrow(eurodat)
grandN


## ---- removing anticipations where RT took less than 100ms

eurodat2 <- eurodat %>%
  filter(rt > 100)

euro_anticipations <- eurodat %>%
  filter(rt < 100)




## ---- removing expirations where 2000 ms

eurodat3 <- eurodat2 %>%
  filter(rt < 2000)

euro_expirations <- eurodat2 %>%
  filter(rt > 2000)
# no expirations ?



# OUTLIERS

## ---- removing outliers > or < 2SD from 
## ---- mean for each person at each SOA 



# first compute grand mean for all trials for each participant at each SOA



# create new dfs for ind dat that aggregates means/sds for each SOA for each pp
aggmean <- aggregate(rt ~ subject + cueDur, eurodat3, mean)
aggsd <- aggregate(rt ~ subject + cueDur, eurodat3, sd)

# rename mean and sd variables
aggmean <- rename(aggmean, mean = rt)
aggsd <- rename(aggsd, sd = rt)

# add sd to mean df and rename sd var
aggdat <- cbind(aggmean, aggsd$sd)
aggdat <- rename(aggdat, sd = `aggsd$sd`)


# rename rt var with mean, and create 3 separate aggregatd dfs for each of 3 SOAs
aggdat200 <- aggdat
aggdat600 <- aggdat
aggdat1000 <- aggdat

aggdat200 <- aggdat200 %>%
  filter(cueDur == 200)
aggdat200$cueDur <- NULL #just removing cueDur so we don't get it twice when we merge these later

aggdat600 <- aggdat600 %>%
  filter(cueDur == 600)
aggdat600$cueDur <- NULL

aggdat1000 <- aggdat1000 %>%
  filter(cueDur == 1000)
aggdat1000$cueDur <- NULL



# taking original data and creating 3 separate dfs for each of SOA
dat200 <- eurodat3 %>%
  filter(cueDur == 200)
dat600 <- eurodat3 %>%
  filter(cueDur == 600)
dat1000 <- eurodat3 %>%
  filter(cueDur == 1000)

# merging the means/sds by subject id for each SOA df separately
final200 <- merge(dat200, aggdat200, by="subject")
final600 <- merge(dat600, aggdat600, by="subject")
final1000 <- merge(dat1000, aggdat1000, by="subject")




# for each SOA df, set a lower and upper bound column (2SD)

# 200 SOA
final200$lower <- final200$mean - 2*(final200$sd)
final200$upper <- final200$mean + 2*(final200$sd)

early200 <- final200 %>%
  filter(rt < lower)
late200 <- final200 %>%
  filter(rt > upper)

outliers200 <- rbind(early200, late200)

final200 <- final200 %>%
  filter(rt > lower) %>%
  filter(rt < upper)



# 600 SOA
final600$lower <- final600$mean - 2*(final600$sd)
final600$upper <- final600$mean + 2*(final600$sd)

early600 <- final600 %>%
  filter(rt < lower)
late600 <- final600 %>%
  filter(rt > upper)

outliers600 <- rbind(early600, late600)

final600 <- final600 %>%
  filter(rt > lower) %>%
  filter(rt < upper)



# 1000 SOA
final1000$lower <- final1000$mean - 2*(final1000$sd)
final1000$upper <- final1000$mean + 2*(final1000$sd)

early1000 <- final1000 %>%
  filter(rt < lower)
late1000 <- final1000 %>%
  filter(rt > upper)

outlier1000 <- rbind(early1000, late1000)

final1000 <- final1000 %>%
  filter(rt > lower) %>%
  filter(rt < upper)







# rbind the SOA dfs together

eurodat4 <- rbind(final200,final600,final1000)











# organize variables

eurodat4$culture <- "European"

eurodat4 <- rename(eurodat4, soa = cueDur)

eurodat4$mean <- NULL
eurodat4$sd <- NULL
eurodat4$lower <- NULL
eurodat4$upper <- NULL

eurodat5 <- eurodat4[c("subject","culture","prime","soa","congruency","fgbg","rt")]


finaleurodat <- aggregate(rt~subject+culture+prime+soa+congruency+fgbg, eurodat5, mean)

finaleurodat <- finaleurodat[order(finaleurodat$subject) , ]

rownames(finaleurodat) <- 1:nrow(finaleurodat) # rename rows


# setting factors and num

str(finaleurodat)
table(finaleurodat$subject)

finaleurodat$subject <- factor(finaleurodat$subject)
finaleurodat$culture <- factor(finaleurodat$culture)
finaleurodat$prime <- factor(finaleurodat$prime)
finaleurodat$congruency <- factor(finaleurodat$congruency)
finaleurodat$soa <- factor(finaleurodat$soa)
finaleurodat$fgbg <- factor(finaleurodat$fgbg)

str(finaleurodat)



# change to wide format




finaleurodat$cond[finaleurodat$fgbg == "CC" & finaleurodat$soa=="200"] <- "CC200" 
finaleurodat$cond[finaleurodat$fgbg == "CC" & finaleurodat$soa=="600"] <- "CC600" 
finaleurodat$cond[finaleurodat$fgbg == "CC" & finaleurodat$soa=="1000"] <- "CC1000" 
finaleurodat$cond[finaleurodat$fgbg == "II" & finaleurodat$soa=="200"] <- "II200" 
finaleurodat$cond[finaleurodat$fgbg == "II" & finaleurodat$soa=="600"] <- "II600"
finaleurodat$cond[finaleurodat$fgbg == "II" & finaleurodat$soa=="1000"] <- "II1000" 
finaleurodat$cond[finaleurodat$fgbg == "CI" & finaleurodat$soa=="200"] <- "CI200" 
finaleurodat$cond[finaleurodat$fgbg == "CI" & finaleurodat$soa=="600"] <- "CI600" 
finaleurodat$cond[finaleurodat$fgbg == "CI" & finaleurodat$soa=="1000"] <- "CI1000" 
finaleurodat$cond[finaleurodat$fgbg == "IC" & finaleurodat$soa=="200"] <- "IC200" 
finaleurodat$cond[finaleurodat$fgbg == "IC" & finaleurodat$soa=="600"] <- "IC600" 
finaleurodat$cond[finaleurodat$fgbg == "IC" & finaleurodat$soa=="1000"] <- "IC1000" 





dat <- finaleurodat

dat$soa <- NULL
dat$congruency <- NULL
dat$fgbg <- NULL

RT <- dat$rt

#make wide format
newdat<- spread(dat, key = cond, value = rt)


# making cueing index variables

newdat$match200 <- newdat$II200 - newdat$CC200
newdat$match600 <- newdat$II600 - newdat$CC600
newdat$match1000 <- newdat$II1000 - newdat$CC1000

newdat$mismatch200 <- newdat$IC200 - newdat$CI200
newdat$mismatch600 <- newdat$IC600 - newdat$CI600
newdat$mismatch1000 <- newdat$IC1000 - newdat$CI1000



#reshape BACK TO LONG FORM
newdat2 <- reshape(newdat, 
                   varying = list(c("match200", "mismatch200"),
                                  c("match600", "mismatch600"),
                                  c("match1000", "mismatch1000")),
                   v.names = c("soa200", "soa600", "soa1000"),
                   timevar = "congruency",
                   idvar = "subject",
                   direction = "long")



rownames(newdat2) <- 1:nrow(newdat2) # Change row names 

rownames(newdat2) <- make.names(newdat2[,1], unique = TRUE)

rownames(newdat2) <- 1:nrow(newdat2) # Change row names 

# Set IVs as factors not integers
newdat2$congruency <- factor(newdat2$congruency, 
                             labels = c("match","mismatch"))



#--------------reshape with explicit instructions since reshape keeps getting row.name errors



# create 200, 600 and 1000 vectors separately
soa200 <- newdat2$soa200
soa600 <- newdat2$soa600
soa1000 <- newdat2$soa1000

# combine the vectors together
rts <- c(soa200,soa600,soa1000)

# remove soa vars from alldat2
newdat2[,c(17:19)] <- list(NULL)

# make 2 other copies of data to rbind together
newdat2copy1 <- newdat2
newdat2copy2 <- newdat2

# rbind all of them to make 3 copies, each w 2 copies of match + mismatch
newdat3 <- rbind(newdat2,newdat2copy1,newdat2copy2)

# create SOA and rt var
newdat3$soa <- NA
newdat3$cueeffect <- NA

# create vectors of 200 600 and 1000 labels repeated for 256x
value200 <- rep(200, times = 224, length.out = NA, each = 1)
value600 <- rep(600, times = 224, length.out = NA, each = 1)
value1000 <- rep(1000, times = 224, length.out = NA, each = 1)

# combine the soa label vectors
soavalues <- c(value200,value600,value1000)

# input all vectors into alldat3
newdat3$soa <- soavalues
newdat3$cueeffect <- rts



# organize by subject id
finaleurodat <- newdat3[order(newdat3$subject) , ]


rownames(finaleurodat) <- 1:nrow(finaleurodat) # rename rows




str(finaleurodat)
finaleurodat$soa <- factor(finaleurodat$soa)




































#------------------    A S I A N     D A T A ------------------------------





# CREATE MATCH/MISMATCH FORREALS

asndat$match200 <- asndat$II200 - asndat$CC200
asndat$match600 <- asndat$II600 - asndat$CC600
asndat$match1000 <- asndat$II1000 - asndat$CC1000
asndat$mismatch200 <- asndat$IC200 - asndat$CI200
asndat$mismatch600 <- asndat$IC600 - asndat$CI600
asndat$mismatch1000 <- asndat$IC1000 - asndat$CI1000






# add culture variable
asndat$culture <- "Asian"



# remove extraneous vars
asndat[,c(3, 16:19)] <- list(NULL)



# reorder variables
asndat2 <- asndat[c("subject","culture","prime","CC1000","CC200","CC600","CI1000","CI200","CI600",
                    "IC1000","IC200","IC600","II1000","II200","II600","match200","mismatch200","match600",
                    "mismatch600","match1000","mismatch1000")]




# remove asian participants based off pp comment logs from RA's
#use (but is questionable): 501 567 588 
#maybe use: 500 511 518 519 530 549 569 582 632 635
#don't use: 573 604 

alldat <- asndat2


alldat  <- alldat[!(alldat$subject==501),]
alldat  <- alldat[!(alldat$subject==567),]
alldat  <- alldat[!(alldat$subject==588),]

alldat  <- alldat[!(alldat$subject==500),]
alldat  <- alldat[!(alldat$subject==511),] #
alldat  <- alldat[!(alldat$subject==518),] # 
alldat  <- alldat[!(alldat$subject==519),] #
alldat  <- alldat[!(alldat$subject==530),] # 
alldat  <- alldat[!(alldat$subject==549),] #
alldat  <- alldat[!(alldat$subject==569),] #
alldat  <- alldat[!(alldat$subject==582),] #
alldat  <- alldat[!(alldat$subject==632),] # 
alldat  <- alldat[!(alldat$subject==635),] #

alldat  <- alldat[!(alldat$subject==573),] 
alldat  <- alldat[!(alldat$subject==604),]



# removing based off of survey data for EA bg

alldat  <- alldat[!(alldat$subject==514),] # both parents born in philippines
alldat  <- alldat[!(alldat$subject==539),] # one parent born in brazil
alldat  <- alldat[!(alldat$subject==548),] # parent born in new brunswick
alldat  <- alldat[!(alldat$subject==550),] # pp identifies as SEA, one parent born in cambodia
alldat  <- alldat[!(alldat$subject==556),] # one parent born in indonesia
alldat  <- alldat[!(alldat$subject==581),] # pp and parents born in mauritius
alldat  <- alldat[!(alldat$subject==615),] # pp identifies as EA and carribbean, parent born in tobago
alldat  <- alldat[!(alldat$subject==621),] # pp identifies as EA and SA, both parents born in india
alldat  <- alldat[!(alldat$subject==642),] # both parents born in canada






# reshaping data ---------------------------------------

#change structures
str(alldat)
alldat$subject <- factor(alldat$subject)
alldat$culture <- factor(alldat$culture)
alldat$prime <- factor(alldat$prime)
str(alldat)



#reshape to long format 1
alldat2 <- reshape(alldat, 
                   varying = list(c("match200", "mismatch200"),
                                  c("match600", "mismatch600"),
                                  c("match1000", "mismatch1000")),
                   v.names = c("soa200", "soa600", "soa1000"),
                   timevar = "congruency",
                   idvar = "subject",
                   direction = "long")


rownames(alldat2) <- 1:nrow(alldat2) # Change row names 

rownames(alldat2) <- make.names(alldat2[,1], unique = TRUE)

rownames(alldat2) <- 1:nrow(alldat2) # Change row names 

# Set IVs as factors not integers
alldat2$congruency <- factor(alldat2$congruency, 
                             labels = c("match","mismatch"))



#--------------reshape with explicit instructions since reshape keeps getting row.name errors


# create 200, 600 and 1000 vectors separately
soa200 <- alldat2$soa200
soa600 <- alldat2$soa600
soa1000 <- alldat2$soa1000

# combine the vectors together
rts <- c(soa200,soa600,soa1000)


# make 2 other copies of data to rbind together
alldat2copy1 <- alldat2
alldat2copy2 <- alldat2

# rbind all of them to make 3 copies, each w 2 copies of match + mismatch
alldat3 <- rbind(alldat2,alldat2copy1,alldat2copy2)

# create SOA and rt var
alldat3$soa <- NA
alldat3$cueeffect <- NA

# create vectors of 200 600 and 1000 labels repeated for 256x
value200 <- rep(200, times = 238, length.out = NA, each = 1)
value600 <- rep(600, times = 238, length.out = NA, each = 1)
value1000 <- rep(1000, times = 238, length.out = NA, each = 1)

# combine the soa label vectors
soavalues <- c(value200,value600,value1000)

# input all vectors into alldat3
alldat3$soa <- soavalues
alldat3$cueeffect <- rts 



# organize by subject id
finalasndat <- alldat3[order(alldat3$subject) , ]


rownames(finalasndat) <- 1:nrow(finalasndat) # rename rows





str(finalasndat)
finalasndat$soa <- factor(finalasndat$soa)


# get rid of original soa variables
finalasndat$soa200 <- NULL
finalasndat$soa600 <- NULL
finalasndat$soa1000 <- NULL
















#------------------    S U R V E Y     D A T A ------------------------------

# nov 29 2018 update: this section is only for specifying who is newasian/oldasian 
# for the pre-2018 data using the old survey data (agearrive and borncan)

# but this secton of code is largely irrelevant
# because I add in the full demographics for everyone in the end 


# separate only asian data

surveyasn <- oldsurvey %>%
  filter(Q11 == "East Asian (e.g., China, Korea, Taiwan, Hong Kong)")

class(surveyasn$Q1)

# vectorize relevant variables
subject <- surveyasn$Q1
borncan <- surveyasn$Q17
agearrive <- surveyasn$Q20

levels(subject)
subject <- factor(subject)


levels(borncan)
borncan <- factor(borncan)

class(agearrive)
agearrive
agearrive<- replace(agearrive, agearrive=="age 7", "7")
agearrive<- replace(agearrive, agearrive=="study", "")
agearrive<- replace(agearrive, agearrive=="N/A", "")
agearrive<- replace(agearrive, agearrive=="China", "")
agearrive<- replace(agearrive, agearrive=="5?", "5")
agearrive<- replace(agearrive, agearrive=="11years old", "11")
agearrive<- replace(agearrive, agearrive=="3 years old ", "")


class(agearrive)
agearrive
agearrive <- as.character(agearrive)
agearrive <- as.numeric(agearrive)



# 






vars <- data.frame(subject,borncan,agearrive)



finalasndat <- merge(finalasndat, vars, by="subject")







# separate european data


surveyeuro <- oldsurvey %>%
  filter(Q11 == "European/White")


# only keep relevant variables
subject <- surveyeuro$Q1
momborn <- surveyeuro$Q14
dadborn <- surveyeuro$Q15

eurodf <- data.frame(subject,momborn,dadborn)


# only keep euro participants where one parent is born in canada

# 6 8 34 45 46 48 49 58 64 75 79 88 90 99 105 110 113 126 134 136

# 8 34 49 58 64 75 79 99 126 134 136 removing from dat

finaleurodat  <- finaleurodat[!(finaleurodat$subject==8),] 
finaleurodat  <- finaleurodat[!(finaleurodat$subject==34),] 
finaleurodat  <- finaleurodat[!(finaleurodat$subject==49),]
finaleurodat  <- finaleurodat[!(finaleurodat$subject==58),]
finaleurodat  <- finaleurodat[!(finaleurodat$subject==64),]
finaleurodat  <- finaleurodat[!(finaleurodat$subject==75),] 
finaleurodat  <- finaleurodat[!(finaleurodat$subject==79),]
finaleurodat  <- finaleurodat[!(finaleurodat$subject==99),]
finaleurodat  <- finaleurodat[!(finaleurodat$subject==126),]
finaleurodat  <- finaleurodat[!(finaleurodat$subject==134),]
finaleurodat  <- finaleurodat[!(finaleurodat$subject==136),] 

















#-------------------------------------------------

# binding euro and asn dat 



finaleurodat$borncan <- NA
finaleurodat$agearrive <- NA

finaldat <- rbind(finaleurodat,finalasndat)



# add in RT variables that are average of IICC and ICCI

match <- finaldat %>%
  filter(congruency == "match")

match200 <- match %>%
  filter(soa == "200")
match600 <- match %>%
  filter(soa == "600")
match1000 <- match %>%
  filter(soa == "1000")

match200$rt <- (match200$II200 + match200$CC200)/2
match600$rt <- (match600$II600 + match600$CC600)/2
match1000$rt <- (match1000$II1000 + match1000$CC1000)/2



mismatch <- finaldat %>%
  filter(congruency == "mismatch")

mismatch200 <- mismatch %>%
  filter(soa == "200")
mismatch600 <- mismatch %>%
  filter(soa == "600")
mismatch1000 <- mismatch %>%
  filter(soa == "1000")

mismatch200$rt <- (mismatch200$IC200 + mismatch200$CI200)/2
mismatch600$rt <- (mismatch600$IC600 + mismatch600$CI600)/2
mismatch1000$rt <- (mismatch1000$IC1000 + mismatch1000$CI1000)/2


finaldat2 <- rbind(match200,mismatch200,match600,mismatch600,match1000,mismatch1000)

# organize by subject id
finaldat2 <- finaldat2[order(finaldat2$subject) , ]

rownames(finaldat2) <- 1:nrow(finaldat2) # rename rows


finaldat <- finaldat2







#------------------- add in specific asian variable



# create new culture variable
finaldat$culture2[finaldat$culture == "Asian"] <- "OldAsian"
finaldat$culture2[finaldat$culture == "Asian" & finaldat$agearrive > 15] <- "NewAsian"
finaldat$culture2[finaldat$culture == "European"] <- "European"


class(finaldat$culture2)

finaldat$culture2 <- factor(finaldat$culture2)
levels(finaldat$culture2)


finaldat <- rename(finaldat, oldculture = culture)
finaldat <- rename(finaldat, culture = culture2)


finaldat$oldculture
finaldat$culture




























#--------------------- NEW ASIAN DATA W PPLOG -----------------------------------------

## UPDATED NOV 1 2018



# remove catch trials
newasndat  <- newasndat[!(newasndat$TrialTypeBG=="catch"),]


# create appropriately matching named variables

newasndat$subject <- newasndat$Subject
newasndat$soa <- newasndat$cueDur
newasndat$rt <- newasndat$targetSlide.RT
newasndat$culture <- "Asian"




##### --------------  ANTICIPATIONS / EXPIRATIONS / OUTLIERS REMOVAL



grandN <- nrow(newasndat)
grandN


## ---- removing anticipations where RT took less than 100ms

newasndat2 <- newasndat %>%
  filter(rt > 100)

newasn_anticipations <- newasndat%>%
  filter(rt < 100)



## ---- removing expirations where 2000 ms

newasndat3 <- newasndat2 %>%
  filter(rt < 2000)

newasndat_expirations <- newasndat2 %>%
  filter(rt > 2000)
# no expirations ?



# OUTLIERS

## ---- removing outliers > or < 2SD from 
## ---- mean for each person at each SOA 



# first compute grand mean for all trials for each participant at each SOA



# create new dfs for ind dat that aggregates means/sds for each SOA for each pp
aggmean <- aggregate(rt ~ subject + cueDur, newasndat3, mean)
aggsd <- aggregate(rt ~ subject + cueDur, newasndat3, sd)

# rename mean and sd variables
aggmean <- rename(aggmean, mean = rt)
aggsd <- rename(aggsd, sd = rt)

# add sd to mean df and rename sd var
aggdat <- cbind(aggmean, aggsd$sd)
aggdat <- rename(aggdat, sd = `aggsd$sd`)


# rename rt var with mean, and create 3 separate aggregatd dfs for each of 3 SOAs
aggdat200 <- aggdat
aggdat600 <- aggdat
aggdat1000 <- aggdat

aggdat200 <- aggdat200 %>%
  filter(cueDur == 200)
aggdat200$cueDur <- NULL #just removing cueDur so we don't get it twice when we merge these later

aggdat600 <- aggdat600 %>%
  filter(cueDur == 600)
aggdat600$cueDur <- NULL

aggdat1000 <- aggdat1000 %>%
  filter(cueDur == 1000)
aggdat1000$cueDur <- NULL



# taking original data and creating 3 separate dfs for each of SOA
dat200 <- newasndat3 %>%
  filter(cueDur == 200)
dat600 <- newasndat3 %>%
  filter(cueDur == 600)
dat1000 <- newasndat3 %>%
  filter(cueDur == 1000)

# merging the means/sds by subject id for each SOA df separately
final200 <- merge(dat200, aggdat200, by="subject")
final600 <- merge(dat600, aggdat600, by="subject")
final1000 <- merge(dat1000, aggdat1000, by="subject")




# for each SOA df, set a lower and upper bound column (2SD)

# 200 SOA
final200$lower <- final200$mean - 2*(final200$sd)
final200$upper <- final200$mean + 2*(final200$sd)

early200 <- final200 %>%
  filter(rt < lower)
late200 <- final200 %>%
  filter(rt > upper)

outliers200 <- rbind(early200, late200)

final200 <- final200 %>%
  filter(rt > lower) %>%
  filter(rt < upper)



# 600 SOA
final600$lower <- final600$mean - 2*(final600$sd)
final600$upper <- final600$mean + 2*(final600$sd)

early600 <- final600 %>%
  filter(rt < lower)
late600 <- final600 %>%
  filter(rt > upper)

outliers600 <- rbind(early600, late600)

final600 <- final600 %>%
  filter(rt > lower) %>%
  filter(rt < upper)



# 1000 SOA
final1000$lower <- final1000$mean - 2*(final1000$sd)
final1000$upper <- final1000$mean + 2*(final1000$sd)

early1000 <- final1000 %>%
  filter(rt < lower)
late1000 <- final1000 %>%
  filter(rt > upper)

outlier1000 <- rbind(early1000, late1000)

final1000 <- final1000 %>%
  filter(rt > lower) %>%
  filter(rt < upper)




# rbind the SOA dfs together

newasnaggdat4 <- rbind(final200,final600,final1000)





newpplog$subject <- newpplog$PP..
newasndat <- merge(newasnaggdat4, newpplog, by="subject")



newasndat$congruency[newasndat$TrialTypeBG == "Congruent" & newasndat$TrialTypeFG=="Congruent"] <- "match" 
newasndat$congruency[newasndat$TrialTypeBG == "Incongruent" & newasndat$TrialTypeFG=="Incongruent"] <- "match" 
newasndat$congruency[newasndat$TrialTypeBG == "Incongruent" & newasndat$TrialTypeFG=="Congruent"] <- "mismatch" 
newasndat$congruency[newasndat$TrialTypeBG == "Congruent" & newasndat$TrialTypeFG=="Incongruent"] <- "mismatch" 

newasndat$cond[newasndat$TrialTypeBG == "Congruent" & newasndat$TrialTypeFG=="Congruent" & newasndat$soa==200] <- "CC200" 
newasndat$cond[newasndat$TrialTypeBG == "Incongruent" & newasndat$TrialTypeFG=="Congruent" & newasndat$soa==200] <- "IC200" 
newasndat$cond[newasndat$TrialTypeBG == "Congruent" & newasndat$TrialTypeFG=="Incongruent" & newasndat$soa==200] <- "CI200" 
newasndat$cond[newasndat$TrialTypeBG == "Incongruent" & newasndat$TrialTypeFG=="Incongruent" & newasndat$soa==200] <- "II200" 

newasndat$cond[newasndat$TrialTypeBG == "Congruent" & newasndat$TrialTypeFG=="Congruent" & newasndat$soa==600] <- "CC600" 
newasndat$cond[newasndat$TrialTypeBG == "Incongruent" & newasndat$TrialTypeFG=="Congruent" & newasndat$soa==600] <- "IC600" 
newasndat$cond[newasndat$TrialTypeBG == "Congruent" & newasndat$TrialTypeFG=="Incongruent" & newasndat$soa==600] <- "CI600" 
newasndat$cond[newasndat$TrialTypeBG == "Incongruent" & newasndat$TrialTypeFG=="Incongruent" & newasndat$soa==600] <- "II600" 

newasndat$cond[newasndat$TrialTypeBG == "Congruent" & newasndat$TrialTypeFG=="Congruent" & newasndat$soa==1000] <- "CC1000" 
newasndat$cond[newasndat$TrialTypeBG == "Incongruent" & newasndat$TrialTypeFG=="Congruent" & newasndat$soa==1000] <- "IC1000" 
newasndat$cond[newasndat$TrialTypeBG == "Congruent" & newasndat$TrialTypeFG=="Incongruent" & newasndat$soa==1000] <- "CI1000" 
newasndat$cond[newasndat$TrialTypeBG == "Incongruent" & newasndat$TrialTypeFG=="Incongruent" & newasndat$soa==1000] <- "II1000" 

newasndat$prime <- newasndat$Prime


yy <- aggregate(rt ~ subject + culture + prime + cond + congruency + soa, newasndat, mean)

# sort the new data frame by subject num
yy <- yy[order(yy$subject), ]

# remove pp coz not east asian- filipino
yy  <- yy[!(yy$subject==652),] 



# making fgbg variable so we can convert to wide format
yy$fgbg[yy$cond == "CC200"] <- "CC" 
yy$fgbg[yy$cond == "CC600"] <- "CC" 
yy$fgbg[yy$cond == "CC1000"] <- "CC"

yy$fgbg[yy$cond == "CI200"] <- "CI"
yy$fgbg[yy$cond == "CI600"] <- "CI"
yy$fgbg[yy$cond == "CI1000"] <- "CI"

yy$fgbg[yy$cond == "II200"] <- "II"
yy$fgbg[yy$cond == "II600"] <- "II"
yy$fgbg[yy$cond == "II1000"] <- "II"

yy$fgbg[yy$cond == "IC200"] <- "IC"
yy$fgbg[yy$cond == "IC600"] <- "IC"
yy$fgbg[yy$cond == "IC1000"] <- "IC"

newasnaggdat2 <- yy

#change structures
str(newasnaggdat2)
newasnaggdat2$subject <- factor(newasnaggdat2$subject)
newasnaggdat2$culture <- factor(newasnaggdat2$culture)
newasnaggdat2$prime <- factor(newasnaggdat2$prime)
newasnaggdat2$cond <- factor(newasnaggdat2$cond)
newasnaggdat2$congruency <- factor(newasnaggdat2$congruency)
newasnaggdat2$soa <- factor(newasnaggdat2$soa)
newasnaggdat2$fgbg <- factor(newasnaggdat2$fgbg)
str(newasnaggdat2)


yy <- newasnaggdat2
str(yy)



#------------------- change to wide format

dat <- yy

dat$soa <- NULL
dat$congruency <- NULL 
dat$fgbg <- NULL
# 
RT <- dat$rt


#make wide format
newdat<- spread(dat, key = cond, value = rt)


# making cueing index variables

newdat$match200 <- newdat$II200 - newdat$CC200
newdat$match600 <- newdat$II600 - newdat$CC600
newdat$match1000 <- newdat$II1000 - newdat$CC1000

newdat$mismatch200 <- newdat$IC200 - newdat$CI200
newdat$mismatch600 <- newdat$IC600 - newdat$CI600
newdat$mismatch1000 <- newdat$IC1000 - newdat$CI1000



#reshape BACK TO LONG FORM
newdat2 <- reshape(newdat, 
                   varying = list(c("match200", "mismatch200"),
                                  c("match600", "mismatch600"),
                                  c("match1000", "mismatch1000")),
                   v.names = c("soa200", "soa600", "soa1000"),
                   timevar = "congruency",
                   idvar = "subject",
                   direction = "long")



rownames(newdat2) <- 1:nrow(newdat2) # Change row names 

rownames(newdat2) <- make.names(newdat2[,1], unique = TRUE)

rownames(newdat2) <- 1:nrow(newdat2) # Change row names 


str(newdat2)
# Set IVs as factors not integers
newdat2$congruency <- factor(newdat2$congruency, 
                             labels = c("match","mismatch"))
str(newdat2)




#--------------reshape with explicit instructions since reshape keeps getting row.name errors



# create 200, 600 and 1000 vectors separately
soa200 <- newdat2$soa200
soa600 <- newdat2$soa600
soa1000 <- newdat2$soa1000

# combine the vectors together
rts <- c(soa200,soa600,soa1000)

# remove soa vars from alldat2
newdat2[,c(17:19)] <- list(NULL)

# make 2 other copies of data to rbind together
newdat2copy1 <- newdat2
newdat2copy2 <- newdat2

# rbind all of them to make 3 copies, each w 2 copies of match + mismatch
newdat3 <- rbind(newdat2,newdat2copy1,newdat2copy2)

# create SOA and rt var
newdat3$soa <- NA
newdat3$cueeffect <- NA

# create vectors of 200 600 and 1000 labels repeated for 44x
value200 <- rep(200, times = 44, length.out = NA, each = 1)
value600 <- rep(600, times = 44, length.out = NA, each = 1)
value1000 <- rep(1000, times = 44, length.out = NA, each = 1)

# combine the soa label vectors
soavalues <- c(value200,value600,value1000)

# input all vectors into alldat3
newdat3$soa <- soavalues
newdat3$cueeffect <- rts



# organize by subject id
lastdat <- newdat3[order(newdat3$subject) , ]


rownames(lastdat) <- 1:nrow(lastdat) # rename rows




str(lastdat)
lastdat$soa <- factor(lastdat$soa)
str(lastdat)



# creating rt variable


# add in RT variables that are average of IICC and ICCI

match <- lastdat %>%
  filter(congruency == "match")

match200 <- match %>%
  filter(soa == "200")
match600 <- match %>%
  filter(soa == "600")
match1000 <- match %>%
  filter(soa == "1000")

match200$rt <- (match200$II200 + match200$CC200)/2
match600$rt <- (match600$II600 + match600$CC600)/2
match1000$rt <- (match1000$II1000 + match1000$CC1000)/2



mismatch <- lastdat %>%
  filter(congruency == "mismatch")

mismatch200 <- mismatch %>%
  filter(soa == "200")
mismatch600 <- mismatch %>%
  filter(soa == "600")
mismatch1000 <- mismatch %>%
  filter(soa == "1000")

mismatch200$rt <- (mismatch200$IC200 + mismatch200$CI200)/2
mismatch600$rt <- (mismatch600$IC600 + mismatch600$CI600)/2
mismatch1000$rt <- (mismatch1000$IC1000 + mismatch1000$CI1000)/2


lastdat <- rbind(match200,mismatch200,match600,mismatch600,match1000,mismatch1000)

# organize by subject id
lastdat <- lastdat[order(finaldat2$subject) , ]

rownames(lastdat) <- 1:nrow(lastdat) # rename rows








# -------------------- MERGING ALL RT DATA (FINAL: NOV 19 2018)




# rename culture variable to oldculture to keep it in same position
# then create new culture variable at end to match other data sets
lastdat <- rename(lastdat, "oldculture"="culture")

lastdat$culture <- lastdat$oldculture






# move borncan and agearrive to end of finaldat so we can create 
# the same variables in lastdat, then delete the duplicate


finaldat$borncan2 <- finaldat$borncan
finaldat$borncan <- NULL
finaldat <- rename(finaldat, "borncan"="borncan2") 

finaldat$agearrive2 <- finaldat$agearrive
finaldat$agearrive <- NULL
finaldat <- rename(finaldat, "agearrive"="agearrive2") 

# add in empty borncan and agearrive to last dat so we can cbind them
lastdat$borncan <- NA
lastdat$agearrive <- NA


realfinaldat <- rbind(finaldat,lastdat)


# select only the rows that are not NA
realfinaldat <- realfinaldat[c(1:1434),]











## ---------------- ADDING DEMOGRAPHICS DATA 
# LAST UPDATED: Nov 29 2019
# adding in AHS SCS SI indices, and adding back in demographics info



survey <- survey[-c(1:2), ] # remove first two rows



# force convert scale variables to character to recode
survey[,19:74] <- lapply(survey[,19:74], as.character) 




# recode likert scale items to numerals
survey[survey=="1 - Strongly Disagree"] <- "1"
survey[survey=="2 - Disagree"] <- "2"
survey[survey=="3 - Somewhat Disagree"] <- "3"
survey[survey=="4 - Neither Agree nor Disagree"] <- "4"
survey[survey=="5 - Somewhat Agree"] <- "5"
survey[survey=="6 - Agree"] <- "6"
survey[survey=="7 - Strongly Agree"] <- "7"


# force convert scale variables to numeric
survey[,19:74] <- lapply(survey[,19:74], as.numeric) 









# SCS coding
# no 2,5,7,12,14,24,30
#2 has original item instead

#Independent Subscale (Independence)
#Sing1, Sing2, Sing5, Sing7, Sing9, Sing10, Sing13, Sing15, Sing18, Sing20,
#Sing22, Sing24, Sing25, Sing27, Sing29



survey$independentSC = rowMeans(survey[,c("scs1","scs9","scs10","scs13","scs15","scs18",
                                "scs20","scs22","scs25","scs27","scs29")], na.rm=TRUE)

#Interdependent Subscale (Interdependence)
#Sing3, Sing4, Sing6, Sing8, Sing11, Sing12, Sing14, Sing16, Sing17, Sing19,
#Sing21, Sing23, Sing26, Sing28, Sing30

survey$interdependentSC = rowMeans(survey[,c("scs3","scs4","scs6","scs8","scs11",
                               "scs16","scs17","scs19","scs21","scs23","scs26","scs28")],
                               na.rm=TRUE)


survey$intmeasure <- survey$independentSC - survey$interdependentSC





# ahs coding

swap <- function(x) {
  f <- factor(x)
  y <- rev(levels(f))[f]
  class(y) <- class(x)
  return(y)
}

# has3, has6, has7, has9, has16, and has18 should be reverse coded

survey$has3r <- survey$has3
survey$has6r <- survey$has6
survey$has7r <- survey$has7
survey$has9r <- survey$has9
survey$has16r <- survey$has16
survey$has18r <- survey$has18



survey$ahs = rowMeans(survey[,c("has1","has2","has3r","has4","has5","has6r",
                                    "has7r","has8","has9r","has10","has11",
                                    "has12","has13","has14","has15","has16r",
                                    "has17","has18r","has19","has20","has21",
                                    "has22","has23","has24")], na.rm=TRUE)




# keeping demographics variables

# gender is ok

# some age values need to be recoded
survey$age[210] <- ""  # formerly 221
survey$age[280] <- "19"  # formerly 19*
# convert age to numeric
survey$age <- as.numeric(as.character(survey$age))


# born in canada
survey <- rename(survey, borncan = Q17)

# age of arrival
survey <- rename(survey, agearrival = Q20)
#recode bad values
survey$agearrival <- as.character(survey$agearrival)
survey$agearrival[7] <- "4"  # formerly 4-5
survey$agearrival[15] <- ""  # formerly na
survey$agearrival[33] <- ""  # formerly N/ A
survey$agearrival[54] <- ""  # formerly N/A
survey$agearrival[64] <- ""  # formerly n/a
survey$agearrival[79] <- ""  # formerly N/A
survey$agearrival[109] <- "6"  # formerly 6 years
survey$agearrival[115] <- ""  # formerly N/A
survey$agearrival[174] <- "7"  # formerly age 7
survey$agearrival[199] <- ""  # formerly study
survey$agearrival[213] <- ""  # formerly N/A
survey$agearrival[218] <- "3"  # formerly 3 years old
survey$agearrival[242] <- ""  # formerly China
survey$agearrival[246] <- "5"  # formerly 5?
survey$agearrival[262] <- "11"  # formerly 11 yearsold
survey$agearrival[280] <- ""  # formerly N/A
survey$agearrival[305] <- ""  # formerly n/a
# convert to numeric
survey$agearrival <- as.numeric(survey$agearrival)




# ses
survey <- rename(survey, ses = Q16)
survey$ses <- as.character(survey$ses)
survey[survey=="lower class"] <- "1"
survey[survey=="lower middle class"] <- "2"
survey[survey=="solidly middle class"] <- "3"
survey[survey=="upper middle class"] <- "4"
survey[survey=="upper class"] <- "5"
#convert to numeric
survey$ses <- as.numeric(survey$ses)


# religion
survey <- rename(survey, religion = Q21)


# how religious
survey <- rename(survey, religious = Q22)
survey$religious <- as.character(survey$religious)
survey[survey=="1 (Not at all)"] <- "1"
survey[survey=="7 (Extremely)"] <- "7"
survey$religious <- as.numeric(survey$religious)


# social inference measure


# rename each item for what it is
# internal attribution
# external attribution
# internal counter factual judgement
# external counter factual judgement

# for both positive and negative behaviours

survey <- rename(survey,  in_attPos = si1)
survey <- rename(survey,  ex_attPos = si2)
survey <- rename(survey,  in_couPos = si3)
survey <- rename(survey,  ex_couPos = si4)

survey <- rename(survey,  in_attNeg = si5)
survey <- rename(survey,  ex_attNeg = si6)
survey <- rename(survey,  in_couNeg = si7)
survey <- rename(survey,  ex_couNeg = si8)




# subset only the relevant variables from qualtrics survey to append


addsurvey <- subset(survey, select=c(subject,gender,age,
                                        borncan,agearrival,ses,religion,religious,ahs,
                                        independentSC,interdependentSC,intmeasure,
                                     in_attPos,ex_attPos,in_couPos,ex_couPos,
                                     in_attNeg,ex_attNeg,in_couNeg,ex_couNeg))









# add to real data set


realdat <- merge(addsurvey, realfinaldat, by="subject")


# double check if new borncan and agearrival vars are same as old for the old participants  

# remove duplicate borncan.y and agearrive

realdat$borncan.y <- NULL
realdat$agearrive <- NULL


# rename borncan.x
realdat <- rename(realdat, borncan = borncan.x)


# rename all "Asian" variable to Old Asian in newest asian dat
realdat$culture <- as.character(realdat$culture)
realdat$culture[realdat$culture=="Asian"] <- "OldAsian"
realdat$culture <- factor(realdat$culture)

str(realdat)

# rename detailed culture variable to detailculture
realdat <- rename(realdat, detailculture = culture)

# rename Asian/European culture variable to culture
realdat <- rename(realdat, culture = oldculture)


#save aggregated final data file
setwd("C:/Users/ronda/Google Drive/grad/projects/01 social attn/data/")
write.csv(x=realdat, file = "socialattndata_final.csv")










#-----------------------------------------------------------------------
# mixed anova time!
#------------------------------------------------------------------------


# subset the newly immigrated Asians and make "finaldat"
a <- realdat %>%
  filter(detailculture == "OldAsian")
e <- realdat %>%
  filter(detailculture == "European")
finaldat <- rbind(e,a)





# look at euros separately

eurodat <- finaldat %>%
  filter(culture == "European")

euromod <-aov_ez("subject", "cueeffect", eurodat, within=c("soa","congruency"), between=c("prime"))
summary(euromod)
# marginal congruency effect p = .056
# marginal soa*congruency p = .061

# histogram of residuals
rez <- residuals(euromod$lm)
hist(rez,main="Histogram of Cue Effect Residuals", xlab="Residuals")
# density plot
plot(density(rez),main="Density plot of residuals",ylab="Density",xlab="Residuals")
# QQ plot
qqnorm(rez)
qqline(rez, col = 2)
#linearity







# look at asn separately

asndat <- finaldat %>%
  filter(culture == "Asian")

asnmod <-aov_ez("subject", "cueeffect", asndat, within=c("soa","congruency"), between=c("prime"), covariate = ("ahs"))
summary(asnmod)
# congruency effect p < .01
# marginal? just sig prime*congruency effect p = .052
# marginal prime*soa*congruency effect p =.055

# histogram of residuals
rez <- residuals(asnmod$lm)
hist(rez,main="Histogram of Cue Effect Residuals", xlab="Residuals")
# density plot
plot(density(rez),main="Density plot of residuals",ylab="Density",xlab="Residuals")
# QQ plot
qqnorm(rez)
qqline(rez, col = 2)




table(finaldat$culture)
# euro = 101
# asn = 102











# PLOTTING-----------------------------------------------



# create new variable that combines culture and prime
finaldat$group[finaldat$culture == "European" & finaldat$prime == "ind"] <- "European-Independent"
finaldat$group[finaldat$culture == "European" & finaldat$prime == "col"] <- "European-Interdependent"
finaldat$group[finaldat$culture == "Asian" & finaldat$prime == "ind"] <- "Asian-Independent"
finaldat$group[finaldat$culture == "Asian" & finaldat$prime == "col"] <- "Asian-Interdependent"

# create new variable that combines congruency and prime
finaldat$group2[finaldat$congruency == "match" & finaldat$prime == "ind"] <- "Match-Independent"
finaldat$group2[finaldat$congruency == "match" & finaldat$prime == "col"] <- "Match-Interdependent"
finaldat$group2[finaldat$congruency == "mismatch" & finaldat$prime == "ind"] <- "Mismatch-Independent"
finaldat$group2[finaldat$congruency == "mismatch" & finaldat$prime == "col"] <- "Mismatch-Interdependent"


dev.off()
pd <- position_dodge(width = 0.2)





eurodat <- finaldat %>% 
  filter(culture == "European")
  
asndat <- finaldat %>%
  filter(culture == "Asian")


# OVERALL EFFECTS: european plot
sum <- summarySE(eurodat, measurevar="cueeffect", groupvars=c("group2","soa"))
plot <- ggplot(sum, aes(x=soa, y=cueeffect, group=group2, colour=group2)) +
  geom_line(size=1, position = pd) +
  geom_point(size=2, position = pd) +
  geom_errorbar(aes(ymin=cueeffect-se, ymax=cueeffect+se), width=.4, position = pd) +
  ylim(-20,25) +
  scale_color_manual(values = c("blue", "lightskyblue","red3","indianred1")) +
  ggtitle("European Cue Effect")
plot

# OVERALL EFFECTS: asian plot
sum <- summarySE(asndat, measurevar="cueeffect", groupvars=c("group2","soa"))
plot <- ggplot(sum, aes(x=soa, y=cueeffect, group=group2, colour=group2)) +
  geom_line(size=1, position = pd) +
  geom_point(size=2, position = pd) +
  geom_errorbar(aes(ymin=cueeffect-se, ymax=cueeffect+se), width=.4, position = pd) +
  ylim(-20,25) +
  scale_color_manual(values = c("blue", "lightskyblue","red3","indianred1")) +
  ggtitle("Asian Cue Effect")
plot








#--------------------- at short SOA


### short SOA euro
shorteuro <- shortsoa %>%
  filter(culture == "European")
mod <-aov_ez("subject", "cueeffect", shorteuro, within=c("congruency"), between=c("prime"))
summary(mod) # NOTHING

sum <- summarySE(shorteuro, measurevar="cueeffect", groupvars=c("prime", "congruency"))
plot <- ggplot(sum, aes(x=congruency, y=cueeffect, group=prime, colour=prime)) +
  geom_line(size=1, position = pd) +
  geom_point(size=2, position = pd) +
  geom_errorbar(aes(ymin=cueeffect-se, ymax=cueeffect+se), width=.4, position = pd) +
  ylim(-20,25) +
  scale_color_manual(labels = c("Interdependent", "Independent"), values = c("blue","red")) +
  ggtitle("European Cue Effect - Short SOA")
plot



### short SOA asian
shortasn <- shortsoa %>%
  filter(culture == "Asian")
mod <-aov_ez("subject", "cueeffect", shortasn, within=c("congruency"), between=c("prime"))
summary(mod) # prime*congruency effect

sum <- summarySE(shortasn, measurevar="cueeffect", groupvars=c("prime", "congruency"))
plot <- ggplot(sum, aes(x=congruency, y=cueeffect, group=prime, colour=prime)) +
  geom_line(size=1, position = pd) +
  geom_point(size=2, position = pd) +
  geom_errorbar(aes(ymin=cueeffect-se, ymax=cueeffect+se), width=.4, position = pd) +
  ylim(-20,25) +
  scale_color_manual(labels = c("Interdependent", "Independent"), values = c("blue","red")) +
  ggtitle("Asian Cue Effect - Short SOA")
plot




match <- shortasn %>%
  filter(congruency =="match")
mismatch <- shortasn %>%
  filter(congruency == "mismatch")
matchind <- match %>%
  filter(prime == "ind")
matchcol <- match %>%
  filter(prime == "col")
mismatchind <- mismatch %>%
  filter(prime == "ind")
mismatchcol <- mismatch %>%
  filter(prime == "col")


# are there prime effects under mismatching condition?
t.test(mismatchind$cueeffect, mismatchcol$cueeffect, paired=FALSE) # sig

#are there congruency effects for those with interdependent prime?
t.test(matchcol$cueeffect, mismatchcol$cueeffect, paired=TRUE) # sig



# are the independent prime effects non-zero effects?
indmatch <- matchind$cueeffect # changing to vectors coz i keep getting errors
indmismatch <- mismatchind$cueeffect
t.test(indmatch, mu=0, alternative = "two.sided") #ns
t.test(indmismatch, mu=0, alternative = "two.sided") #sig




#----------------------- at med SOA


### med SOA euro
medeuro <- medsoa %>%
  filter(culture == "European")
mod <-aov_ez("subject", "cueeffect", medeuro, within=c("congruency"), between=c("prime"))
summary(mod) # congruency effect

sum <- summarySE(medeuro, measurevar="cueeffect", groupvars=c("prime", "congruency"))
plot <- ggplot(sum, aes(x=congruency, y=cueeffect, group=prime, colour=prime)) +
  geom_line(size=1, position = pd) +
  geom_point(size=2, position = pd) +
  geom_errorbar(aes(ymin=cueeffect-se, ymax=cueeffect+se), width=.4, position = pd) +
  ylim(-20,25) +
  scale_color_manual(labels = c("Interdependent", "Independent"), values = c("blue","red")) +
  ggtitle("European Cue Effect - Medium SOA")
plot




### med SOA asian 
medasn <- medsoa %>%
  filter(culture == "Asian")
mod <-aov_ez("subject", "cueeffect", medasn, within=c("congruency"), between=c("prime"))
summary(mod) # congruency effect

sum <- summarySE(medasn, measurevar="cueeffect", groupvars=c("prime", "congruency"))
plot <- ggplot(sum, aes(x=congruency, y=cueeffect, group=prime, colour=prime)) +
  geom_line(size=1, position = pd) +
  geom_point(size=2, position = pd) +
  geom_errorbar(aes(ymin=cueeffect-se, ymax=cueeffect+se), width=.4, position = pd) +
  ylim(-20,25) +
  scale_color_manual(labels = c("Interdependent", "Independent"), values = c("blue","red")) +
  ggtitle("Asian Cue Effect - Medium SOA")
plot




match <- medasn %>%
  filter(congruency =="match")
mismatch <- medasn %>%
  filter(congruency == "mismatch")
matchind <- match %>%
  filter(prime == "ind")
matchcol <- match %>%
  filter(prime == "col")
mismatchind <- mismatch %>%
  filter(prime == "ind")
mismatchcol <- mismatch %>%
  filter(prime == "col")


# seeing if sig diff between congruency conditions for those under independent prime
t.test(matchind$cueeffect, mismatchind$cueeffect, paired=TRUE) # sig


# testing non-zero effect under matching
indmatch <- matchind$cueeffect # changing to vectors coz i keep getting errors
colmatch <- matchcol$cueeffect
t.test(indmatch, mu=0, alternative = "two.sided") #sig
t.test(colmatch, mu=0, alternative = "two.sided") #sig

# testing non-zero effect under mismatching
indmismatch <- mismatchind$cueeffect # changing to vectors coz i keep getting errors
colmismatch <- mismatchcol$cueeffect
t.test(indmismatch, mu=0, alternative = "two.sided") #ns
t.test(colmismatch, mu=0, alternative = "two.sided") #ns












#----------------------- at long SOA



### long SOA euro
longeuro <- longsoa %>%
  filter(culture == "European")
mod <-aov_ez("subject", "cueeffect", longeuro, within=c("congruency"), between=c("prime"))
summary(mod) # no effect

sum <- summarySE(longeuro, measurevar="cueeffect", groupvars=c("prime", "congruency"))
plot <- ggplot(sum, aes(x=congruency, y=cueeffect, group=prime, colour=prime)) +
  geom_line(size=1, position = pd) +
  geom_point(size=2, position = pd) +
  geom_errorbar(aes(ymin=cueeffect-se, ymax=cueeffect+se), width=.4, position = pd) +
  ylim(-20,25) +
  scale_color_manual(labels = c("Interdependent", "Independent"), values = c("blue","red")) +
  ggtitle("European Cue Effect - Long SOA")
plot






### long SOA asn
longasn <- longsoa %>%
  filter(culture == "Asian")
mod <-aov_ez("subject", "cueeffect", longasn, within=c("congruency"), between=c("prime"))
summary(mod) # congruency effect

sum <- summarySE(longasn, measurevar="cueeffect", groupvars=c("prime", "congruency"))
plot <- ggplot(sum, aes(x=congruency, y=cueeffect, group=prime, colour=prime)) +
  geom_line(size=1, position = pd) +
  geom_point(size=2, position = pd) +
  geom_errorbar(aes(ymin=cueeffect-se, ymax=cueeffect+se), width=.4, position = pd) +
  ylim(-20,25) +
  scale_color_manual(labels = c("Interdependent", "Independent"), values = c("blue","red")) +
  ggtitle("Asian Cue Effect - Long SOA")
plot


match <- longasn %>%
  filter(congruency =="match")
mismatch <- longasn %>%
  filter(congruency == "mismatch")
matchind <- match %>%
  filter(prime == "ind")
matchcol <- match %>%
  filter(prime == "col")
mismatchind <- mismatch %>%
  filter(prime == "ind")
mismatchcol <- mismatch %>%
  filter(prime == "col")


# seeing if sig diff between congruency conditions for those under interdependent prime
t.test(matchcol$cueeffect, mismatchcol$cueeffect, paired=TRUE) # sig


# testing non-zero effect under matching
indmatch <- matchind$cueeffect # changing to vectors coz i keep getting errors
colmatch <- matchcol$cueeffect
t.test(indmatch, mu=0, alternative = "two.sided") #sig
t.test(colmatch, mu=0, alternative = "two.sided") #sig

# testing non-zero effect under mismatching
indmismatch <- mismatchind$cueeffect # changing to vectors coz i keep getting errors
colmismatch <- mismatchcol$cueeffect
t.test(indmismatch, mu=0, alternative = "two.sided") #ns
t.test(colmismatch, mu=0, alternative = "two.sided") #ns




 


